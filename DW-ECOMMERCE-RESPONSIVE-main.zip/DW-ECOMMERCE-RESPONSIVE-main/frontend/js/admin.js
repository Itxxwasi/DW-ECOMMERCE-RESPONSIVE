 $(document).ready(function() {
    // Sidebar toggle functionality - unified handler
    function toggleSidebar() {
        const sidebar = $('.sidebar');
        const overlay = $('#sidebarOverlay');
        
        if (sidebar.hasClass('active')) {
            sidebar.removeClass('active');
            overlay.removeClass('active');
            $('body').css('overflow', '');
        } else {
            sidebar.addClass('active');
            overlay.addClass('active');
            $('body').css('overflow', 'hidden');
        }
    }
    
    // Sidebar toggle button - use event delegation to prevent conflicts
    $(document).off('click', '#sidebarToggle').on('click', '#sidebarToggle', function(e) {
        e.preventDefault();
        e.stopPropagation();
        e.stopImmediatePropagation();
        toggleSidebar();
    });
    
    // Close sidebar when overlay is clicked
    $(document).off('click', '#sidebarOverlay').on('click', '#sidebarOverlay', function(e) {
        e.preventDefault();
        e.stopPropagation();
        $('.sidebar').removeClass('active');
        $(this).removeClass('active');
        $('body').css('overflow', '');
    });
    
    // Close sidebar on window resize if desktop
    $(window).on('resize', function() {
        if ($(window).width() > 991) {
            $('.sidebar').removeClass('active');
            $('#sidebarOverlay').removeClass('active');
            $('body').css('overflow', '');
        }
    });
    
    // Check if user is logged in
    const token = localStorage.getItem('token');
    if (!token) {
        window.location.href = 'login.html';
        return;
    }
    
    // Set token for all AJAX requests
    $.ajaxSetup({
        headers: {
            'x-auth-token': token
        }
    });
    
    // Fix aria-hidden accessibility issue for Bootstrap 5 modals
    // Ensure aria-hidden is properly managed when modals are shown/hidden
    $(document).on('show.bs.modal', '.modal', function(event) {
        const modal = event.target;
        if (modal) {
            // Remove aria-hidden before modal is shown
            $(modal).removeAttr('aria-hidden');
        }
    });
    
    $(document).on('shown.bs.modal', '.modal', function(event) {
        const modal = event.target;
        if (modal) {
            // Ensure aria-hidden is false when modal is fully shown
            $(modal).removeAttr('aria-hidden');
            $(modal).attr('aria-hidden', 'false');
        }
    });
    
    $(document).on('hide.bs.modal', '.modal', function(event) {
        const modal = event.target;
        if (modal) {
            // Keep modal accessible during hide transition
            // Don't set aria-hidden until fully hidden
        }
    });
    
    $(document).on('hidden.bs.modal', '.modal', function(event) {
        const modal = event.target;
        if (modal) {
            // Set aria-hidden to true only after modal is fully hidden
            $(modal).attr('aria-hidden', 'true');
        }
    });
    
    // Verify user is admin before loading dashboard
    verifyAdminAccess();
    
    // Sidebar navigation
    $('.sidebar-menu a').click(function(e) {
        e.preventDefault();
        
        // Remove active class from all links and sections
        $('.sidebar-menu li').removeClass('active');
        
        // Hide all sections and clear any inline styles that might interfere
        $('.content-section').each(function() {
            $(this).removeClass('active');
            $(this).css({
                'display': 'none',
                'visibility': 'hidden',
                'opacity': '0'
            });
        });
        
        // Add active class to clicked link
        $(this).parent().addClass('active');
        
        // Show corresponding section
        const sectionId = $(this).attr('href').substring(1) + '-section';
        const targetSection = $(`#${sectionId}`);
        
        // Ensure target section is visible
        if (targetSection.length) {
            targetSection.addClass('active');
            targetSection.css({
                'display': 'block',
                'visibility': 'visible',
                'opacity': '1'
            });
        }

        // On small screens, close the sidebar after selecting a menu item
        if (window.innerWidth <= 991) {
            $('.sidebar').removeClass('active');
            $('#sidebarOverlay').removeClass('active');
            $('body').css('overflow', '');
        }
        
        // Load data for the section
        loadSectionData(sectionId);
    });
    
    // Load footer data if footer settings section is active on page load
    if ($('#footer-settings-section').hasClass('active')) {
        // Initialize image fields for footer logo and payment methods
        initImageField({ urlInput: '#footerLogo', fileInput: '#footerLogoFile', preview: '#footerLogoPreview' });
        initImageField({ urlInput: '#footerPaymentMethodsImage', fileInput: '#footerPaymentMethodsImageFile', preview: '#footerPaymentMethodsImagePreview' });
        
        loadFooter();
        // Attach update button handler
        $('#updateFooter').off('click.updateFooter').on('click.updateFooter', function(e) {
            e.preventDefault();
            e.stopPropagation();
            console.log('Page load: Update Footer button clicked');
            updateFooter();
            return false;
        });
    }

    // Note: Sidebar toggle is now handled at the top of the document ready function
    // This prevents duplicate handlers
    
    // Close sidebar when clicking outside on mobile - improved logic
    $(document).off('click.sidebarClose').on('click.sidebarClose', function(e) {
        // Only handle on mobile/tablet
        if ($(window).width() > 991) {
            return;
        }
        
        // Don't close if clicking on toggle button or sidebar itself
        if ($(e.target).closest('#sidebarToggle').length || 
            $(e.target).closest('.sidebar').length) {
            return;
        }
        
        // Only close if sidebar is currently open
        if ($('.sidebar').hasClass('active')) {
            $('.sidebar').removeClass('active');
            $('#sidebarOverlay').removeClass('active');
        }
    });
    
    // Logout
    $('#logout, #logoutLink').click(function(e) {
        e.preventDefault();
        localStorage.removeItem('token');
        window.location.href = 'login.html';
    });
    
    // Department handlers
    $('#add-department-btn').click(function() {
        resetDepartmentForm();
        $('#departmentModalTitle').text('Add Department');
        $('#departmentModal').modal('show');
    });
    
    $('#saveDepartment').click(function() {
        saveDepartment();
    });
    
    // Category handlers
    $('#add-category-btn').click(function() {
        resetCategoryForm();
        loadDepartmentsToSelect('#categoryDepartment');
        $('#categoryModalTitle').text('Add Category');
        $('#categoryModal').modal('show');
    });
    
    $('#saveCategory').click(function() {
        saveCategory();
    });
    
    // Subcategory handlers
    $('#add-subcategory-btn').click(function() {
        resetSubcategoryForm();
        loadCategoriesToSelect('#subcategoryCategory');
        $('#subcategoryModalTitle').text('Add Subcategory');
        $('#subcategoryModal').modal('show');
    });
    
    $('#saveSubcategory').click(function() {
        saveSubcategory();
    });
    
    // Product handlers
    $('#add-product-btn').click(function() {
        resetProductForm();
        loadDepartmentsToSelect('#productDepartment');
        loadBrandSectionsToSelect('#productBrandSection');
        $('#productModalTitle').text('Add Product');
        $('#productModal').modal('show');
        updateFieldRequirements();
    });
    
    // Brand selection change handler - make department/category optional when brand is selected
    $(document).on('change', '#productBrandSection', function() {
        updateFieldRequirements();
    });
    
    $('#saveProduct').click(function() {
        saveProduct();
    });
    
    // Toggle custom collection name input
    $('#toggleCustomCollection').click(function() {
        const customInput = $('#productCollectionCustom');
        const selectInput = $('#productCollection');
        if (customInput.is(':visible')) {
            customInput.hide();
            selectInput.show();
            $(this).text('Use custom collection name');
        } else {
            customInput.show();
            selectInput.hide();
            $(this).text('Use preset collections');
        }
    });
    
    // Sync custom collection to select when typing
    $('#productCollectionCustom').on('input', function() {
        if ($(this).val()) {
            $('#productCollection').val('');
        }
    });
    
    // Sync select to custom when changed
    $('#productCollection').change(function() {
        if ($(this).val()) {
            $('#productCollectionCustom').val('');
        }
    });
    
    // Product type filter dropdown handler (replaces filter buttons)
    $('#filter-type').on('change', function() {
        currentProductFilter = $(this).val() || '';
        console.log('Product type filter changed to:', currentProductFilter);
        loadProducts(1);
    });
    
    // Product search handler
    let searchTimeout;
    $('#product-search-input').on('input', function() {
        clearTimeout(searchTimeout);
        const searchValue = $(this).val().trim();
        searchTimeout = setTimeout(function() {
            currentProductSearch = searchValue;
            loadProducts(1);
        }, 500); // Debounce search by 500ms
    });
    
    // Apply advanced filters
    $('#apply-filters-btn').click(function() {
        // Get product type filter
        currentProductFilter = $('#filter-type').val() || '';
        // Get other filters
        currentProductFilters.category = $('#filter-category').val() || '';
        currentProductFilters.department = $('#filter-department').val() || '';
        currentProductFilters.subcategory = $('#filter-subcategory').val() || '';
        currentProductFilters.brand = $('#filter-brand').val() || '';
        currentProductFilters.minPrice = $('#filter-min-price').val() || '';
        currentProductFilters.maxPrice = $('#filter-max-price').val() || '';
        currentProductFilters.minDiscount = $('#filter-min-discount').val() || '';
        currentProductFilters.section = $('#filter-section').val() || '';
        console.log('Applied filters:', {
            type: currentProductFilter,
            ...currentProductFilters
        });
        loadProducts(1);
    });
    
    // Also apply section filter when dropdown changes directly
    $('#filter-section').on('change', function() {
        currentProductFilters.section = $(this).val() || '';
        console.log('Section filter changed to:', currentProductFilters.section);
        loadProducts(1);
    });
    
    // Clear all filters
    $('#clear-filters-btn').click(function() {
        currentProductFilter = '';
        currentProductSearch = '';
        currentProductFilters = {
            category: '',
            department: '',
            subcategory: '',
            brand: '',
            minPrice: '',
            maxPrice: '',
            minDiscount: '',
            section: ''
        };
        
        // Reset UI
        $('#product-search-input').val('');
        $('#filter-type').val('');
        $('#filter-category').val('');
        $('#filter-department').val('');
        $('#filter-subcategory').val('');
        $('#filter-brand').val('');
        $('#filter-min-price').val('');
        $('#filter-max-price').val('');
        $('#filter-min-discount').val('');
        $('#filter-section').val('');
        
        loadProducts(1);
    });
    
    // Load subcategories when category filter changes
    $('#filter-category').change(function() {
        const categoryId = $(this).val();
        if (categoryId) {
            loadSubcategoriesToSelect('#filter-subcategory', categoryId);
        } else {
            $('#filter-subcategory').html('<option value="">All Subcategories</option>');
        }
    });
    
    // Load categories when department filter changes
    $('#filter-department').change(function() {
        const departmentId = $(this).val();
        if (departmentId) {
            loadCategoriesToSelect('#filter-category', departmentId);
        } else {
            $('#filter-category').html('<option value="">All Categories</option>');
            $('#filter-subcategory').html('<option value="">All Subcategories</option>');
        }
    });
    
    // Slider handlers
    $('#add-slider-btn').click(function() {
        resetSliderForm();
        $('#sliderModalTitle').text('Add Slider');
        $('#sliderModal').modal('show');
    });
    
    $('#saveSlider').click(function() {
        saveSlider();
    });
    
    // Banner handlers
    $('#add-banner-btn').click(function() {
        resetBannerForm();
        $('#bannerModalTitle').text('Add Banner');
        loadBannerPositions(); // Load dynamic positions from homepage sections
        $('#bannerModal').modal('show');
    });
    
    $('#saveBanner').click(function() {
        saveBanner();
    });
    
    // Show/hide custom dimensions based on size selection
    $('#bannerSize').change(function() {
        const sizeValue = $(this).val();
        if (sizeValue === 'custom') {
            $('#customBannerDimensions').slideDown();
        } else {
            $('#customBannerDimensions').slideUp();
        }
    });
    
// Video Banner handlers
$('#add-video-banner-btn').click(function() {
    resetVideoBannerForm();
    $('#videoBannerModalTitle').text('Add Video Banner');
    $('#videoBannerModal').modal('show');
});

$('#add-video-banner-to-homepage-btn').click(async function() {
    try {
        // First check if there are any active video banners
        const response = await $.get('/api/admin/video-banners');
        console.log('Video banners response for homepage:', response);
        
        // Handle different response formats
        const videoBanners = Array.isArray(response) ? response : (response.videoBanners || response.data || []);
        
        if (!Array.isArray(videoBanners)) {
            console.error('Invalid video banners response format:', response);
            showAlert('Error: Invalid response format from server. Please check console for details.', 'danger');
            return;
        }
        
        const activeBanners = videoBanners.filter(b => b.isActive);
        
        if (activeBanners.length === 0) {
            showAlert('No active video banners found. Please create and activate a video banner first.', 'warning');
            return;
        }
        
        // Check if a video banner homepage section already exists
        const existingSections = await $.get('/api/homepage-sections');
        const videoBannerSection = existingSections.find(s => s.type === 'videoBanner' && s.isActive);
        
        if (videoBannerSection) {
            if (confirm('A video banner homepage section already exists. Do you want to activate and publish it instead?')) {
                // Activate and publish existing section
                await $.ajax({
                    url: `/api/homepage-sections/${videoBannerSection._id}`,
                    method: 'PUT',
                    contentType: 'application/json',
                    data: JSON.stringify({
                        isActive: true,
                        isPublished: true
                    })
                });
                showAlert('Video banner section activated and published! It will now appear on the homepage.', 'success');
                loadHomepageSections();
                // Switch to homepage sections tab
                $('.sidebar-menu a[href="#homepage-sections"]').click();
                return;
            }
        }
        
        // Create new homepage section for video banner
        const firstBanner = activeBanners[0];
        const sectionName = firstBanner.title || 'Video Banner';
        
        const sectionPayload = {
            name: sectionName,
            type: 'videoBanner',
            title: firstBanner.title || undefined,
            description: firstBanner.description || undefined,
            config: {
                videoBannerId: firstBanner._id
            },
            ordering: 0,
            isActive: true,
            isPublished: true,
            displayOn: {
                desktop: true,
                tablet: true,
                mobile: true
            }
        };
        
        await $.ajax({
            url: '/api/homepage-sections',
            method: 'POST',
            contentType: 'application/json',
            data: JSON.stringify(sectionPayload)
        });
        
        showAlert('Video banner section added to homepage successfully! It will appear on the main page.', 'success');
        loadHomepageSections();
        
        // Switch to homepage sections tab to show the new section
        setTimeout(function() {
            $('.sidebar-menu a[href="#homepage-sections"]').click();
        }, 500);
        
    } catch (error) {
        console.error('Error adding video banner to homepage:', error);
        let errorMessage = 'Error adding video banner to homepage';
        if (error.responseJSON && error.responseJSON.message) {
            errorMessage = error.responseJSON.message;
        }
        showAlert(errorMessage, 'danger');
    }
});

$('#videoBannerType').change(function() {
    const type = $(this).val();
    if (type === 'file') {
        $('#videoBannerFileUploadDiv').show();
        $('#videoBannerUrl').prop('required', false);
    } else {
        $('#videoBannerFileUploadDiv').hide();
        $('#videoBannerUrl').prop('required', true);
    }
});

$('#saveVideoBanner').click(function() {
    saveVideoBanner();
});

// Setup video banner poster preview
initImageField({
    urlInput: '#videoBannerPoster',
    fileInput: '#videoBannerPosterFile',
    preview: '#videoBannerPosterPreview'
});

// Brand handlers
$('#add-brand-btn').click(function() {
    resetBrandForm();
    $('#brandModalTitle').text('Add Brand');
    $('#brandModal').modal('show');
});
    
    $('#saveBrand').click(function() {
        saveBrand();
    });
    
    // Setup brand image preview
    initImageField({ urlInput: '#brandImage', fileInput: '#brandImageFile', preview: '#brandImagePreview' });
    
    // Homepage Section handlers
    $('#add-homepage-section-btn').click(function() {
        resetHomepageSectionForm();
        $('#homepageSectionModalTitle').text('Add Homepage Section');
        $('#homepageSectionModal').modal('show');
    });
    
    $('#saveHomepageSection').click(function() {
        saveHomepageSection();
    });
    
    $('#homepageSectionType').change(function() {
        loadHomepageSectionConfig($(this).val());
    });
    
    $('#reorder-homepage-sections-btn').click(function() {
        toggleHomepageSectionReorder();
    });
    
    // Prevent footer form from submitting
    $(document).on('submit', '#footerForm', function(e) {
        e.preventDefault();
        e.stopPropagation();
        console.log('Footer form submit prevented, calling updateFooter instead');
        updateFooter();
        return false;
    });
    
    // Footer update button handler - use event delegation for dynamically loaded content
    $(document).on('click', '#updateFooter', function(e) {
        e.preventDefault();
        e.stopPropagation();
        console.log('Update Footer button clicked');
        console.log('Button element:', this);
        console.log('Button ID:', $(this).attr('id'));
        console.log('Button type:', $(this).attr('type'));
        
        // Double check button exists
        if (!$(this).length) {
            console.error('Button element not found in click handler!');
            return false;
        }
        
        try {
            updateFooter();
        } catch (error) {
            console.error('Error in updateFooter:', error);
            console.error('Error stack:', error.stack);
            showAlert('Error updating footer: ' + error.message, 'danger');
        }
        
        return false;
    });
    
    // Also attach directly as backup when footer section is shown
    $(document).on('shown.bs.tab', 'a[href="#footer-settings"]', function() {
        console.log('Footer settings tab shown, attaching direct handler');
        $('#updateFooter').off('click.updateFooter').on('click.updateFooter', function(e) {
            e.preventDefault();
            e.stopPropagation();
            console.log('Direct handler: Update Footer button clicked');
            updateFooter();
            return false;
        });
    });
    
    // LEGACY SECTIONS - NO LONGER USED
    // $('#add-section-btn').click(function() {
    //     resetSectionForm();
    //     $('#sectionModalTitle').text('Add Section');
    //     $('#sectionModal').modal('show');
    // });
    
    // $('#saveSection').click(function() {
    //     saveSection();
    // });
    
    // Order handlers
    $('#orderStatusFilter').change(function() {
        loadOrders(1);
    });
    
    $('#confirmOrderBtn').click(function() {
        const orderId = $(this).data('order-id');
        confirmOrder(orderId);
    });
    
    $('#updateOrderStatusBtn').click(function() {
        const orderId = $(this).data('order-id');
        const currentStatus = $(this).data('current-status');
        showOrderStatusModal(orderId, currentStatus);
    });
    
    $('#orderStatusSelect').change(function() {
        if ($(this).val() === 'cancelled') {
            $('#cancelledReasonDiv').show();
        } else {
            $('#cancelledReasonDiv').hide();
        }
    });
    
    $('#saveOrderStatus').click(function() {
        updateOrderStatus();
    });
    
    // Report handlers
    $('#reportPeriod').change(function() {
        if ($(this).val() === 'custom') {
            $('#customDateRange').show();
            $('#customDateRangeEnd').show();
        } else {
            $('#customDateRange').hide();
            $('#customDateRangeEnd').hide();
        }
    });
    
    $('#reportDepartment').change(function() {
        const departmentId = $(this).val();
        loadReportCategories(departmentId);
        loadReportProducts(null, departmentId);
    });
    
    $('#reportCategory').change(function() {
        const categoryId = $(this).val();
        const departmentId = $('#reportDepartment').val();
        loadReportProducts(categoryId, departmentId);
    });
    
    $('#generateReport').click(function() {
        generateSalesReport();
    });
    
    $('#exportReport').click(function() {
        exportReport();
    });
    
    // Department change handler for product form
    $('#productDepartment').change(function() {
        const departmentId = $(this).val();
        loadCategoriesToSelect('#productCategory', departmentId);
        // Clear subcategory when department changes
        $('#productSubcategory').html('<option value="">Select Category First</option>');
    });
    
    // Load subcategories when category changes
    $('#productCategory').change(function() {
        const categoryId = $(this).val();
        if (categoryId) {
            loadSubcategoriesToSelect('#productSubcategory', categoryId);
        } else {
            $('#productSubcategory').html('<option value="">Select Category First</option>');
        }
    });

    // Setup image previews
    initImageField({ urlInput: '#departmentImage', fileInput: '#departmentImageFile', preview: '#departmentImagePreview' });
    initImageField({ urlInput: '#categoryImage', fileInput: '#categoryImageFile', preview: '#categoryImagePreview' });
    initImageField({ urlInput: '#subcategoryImage', fileInput: '#subcategoryImageFile', preview: '#subcategoryImagePreview' });
    initImageField({ urlInput: '#productImage', fileInput: '#productImageFile', preview: '#productImagePreview' });
    initImageField({ urlInput: '#sliderImage', fileInput: '#sliderImageFile', preview: '#sliderImagePreview' });
    
    // Initialize video URL field for slider (with preview)
    $('#sliderVideoUrl').on('input paste', function() {
        setTimeout(() => {
            const value = $(this).val().trim();
            if (value) {
                const videoType = detectVideoTypeFromUrl(value);
                if (videoType === 'youtube' || videoType === 'vimeo') {
                    showVideoEmbedPreview('#sliderImagePreview', value, videoType);
                } else if (videoType) {
                    // Direct video file - show video preview
                    const $preview = $('#sliderImagePreview');
                    if ($preview.is('img')) {
                        const $video = $('<video>').attr({
                            src: value,
                            controls: true,
                            preload: 'metadata',
                            style: 'max-width: 100%; max-height: 100%; object-fit: contain; display: block; width: 100%;'
                        });
                        $preview.replaceWith($video);
                    } else {
                        $preview.empty().html(`<video src="${value}" controls preload="metadata" style="max-width: 100%; max-height: 100%; object-fit: contain; display: block;" alt="Video preview"></video>`);
                    }
                } else {
                    // Not a video URL, show image preview if image URL is set
                    const imageUrl = $('#sliderImage').val().trim();
                    if (imageUrl) {
                        setImagePreview('#sliderImagePreview', imageUrl);
                    }
                }
            } else {
                // No video URL, show image preview if available
                const imageUrl = $('#sliderImage').val().trim();
                if (imageUrl) {
                    setImagePreview('#sliderImagePreview', imageUrl);
                } else {
                    setImagePreview('#sliderImagePreview', null);
                }
            }
        }, 100);
    });
    initImageField({ urlInput: '#bannerImage', fileInput: '#bannerImageFile', preview: '#bannerImagePreview' });

    setImagePreview('#departmentImagePreview', null);
    setImagePreview('#categoryImagePreview', null);
    setImagePreview('#productImagePreview', null);
    setImagePreview('#sliderImagePreview', null);
    setImagePreview('#bannerImagePreview', null);
});

// Verify admin access
function verifyAdminAccess() {
    $.get('/api/admin/dashboard')
        .done(function(data) {
            // User is admin, load dashboard
            loadDashboardData();
        })
        .fail(function(xhr) {
            if (xhr.status === 403) {
                // User is not admin
                const response = xhr.responseJSON || {};
                showAlert('Access denied. Admin privileges required. You are logged in as a regular user.', 'danger');
                
                // Clear token and redirect after 3 seconds
                setTimeout(function() {
                    localStorage.removeItem('token');
                    window.location.href = '/';
                }, 3000);
            } else if (xhr.status === 401) {
                // Token is invalid
                showAlert('Session expired. Please login again.', 'warning');
                setTimeout(function() {
                    localStorage.removeItem('token');
                    window.location.href = 'login.html';
                }, 2000);
            } else {
                showAlert('Error accessing admin dashboard. Please try again.', 'danger');
            }
        });
}

// Functions to load data
function loadDashboardData() {
    $.get('/api/admin/dashboard')
        .done(function(data) {
            $('#departments-count').text(data.departments);
            $('#categories-count').text(data.categories);
            $('#products-count').text(data.products);
            $('#users-count').text(data.users);
            $('#orders-count').text(data.orders || 0);
            // Format revenue with commas and 2 decimal places
            const revenue = data.revenue || 0;
            $('#revenue-count').text('Rs. ' + revenue.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 }));
        })
        .fail(function(xhr) {
            const message = xhr.responseJSON?.message || 'Error loading dashboard data';
            if (xhr.status === 403) {
                showAlert('Access denied. Admin privileges required.', 'danger');
            } else {
                showAlert(message, 'danger');
            }
        });
}

function loadSectionData(sectionId) {
    switch(sectionId) {
        case 'departments-section':
            loadAdminDepartments();
            break;
        case 'categories-section':
            loadCategories();
            break;
        case 'subcategories-section':
            loadSubcategories();
            break;
        case 'products-section':
            loadProducts(1);
            loadFilterCategories();
            loadFilterDepartments();
            loadFilterBrands();
            // Sections filter is static - no need to load
            break;
        case 'sliders-section':
            loadSliders();
            break;
        case 'banners-section':
            loadBanners();
            break;
        case 'video-banners-section':
            loadVideoBanners();
            break;
        case 'brands-section':
            loadBrands();
            break;
        case 'homepage-sections-section':
            loadHomepageSections();
            break;
        case 'footer-settings-section':
            console.log('Loading footer settings section...');
            // Small delay to ensure DOM is ready
            setTimeout(function() {
                // Initialize image fields for footer logo and payment methods
                initImageField({ urlInput: '#footerLogo', fileInput: '#footerLogoFile', preview: '#footerLogoPreview' });
                initImageField({ urlInput: '#footerPaymentMethodsImage', fileInput: '#footerPaymentMethodsImageFile', preview: '#footerPaymentMethodsImagePreview' });
                
                loadFooter();
                // Attach update button handler when section is shown
                $('#updateFooter').off('click.updateFooter').on('click.updateFooter', function(e) {
                    e.preventDefault();
                    e.stopPropagation();
                    console.log('Footer settings handler: Update Footer button clicked');
                    updateFooter();
                    return false;
                });
                console.log('Update button handler attached to footer-settings-section');
            }, 300);
            break;
        // LEGACY SECTIONS - NO LONGER USED
        // case 'sections-section':
        //     loadSections();
        //     break;
        case 'users-section':
            loadUsers(1);
            break;
        case 'orders-section':
            loadOrders(1);
            break;
        case 'reports-section':
            loadReportFilters();
            break;
    }
}

function loadAdminDepartments() {
    $.get('/api/admin/departments')
        .done(function(departments) {
            let html = '';
            
            departments.forEach(function(dept) {
                const imageUrl = resolveItemImage(dept) || IMAGE_PLACEHOLDER;
                html += `
                    <tr>
                        <td>${dept.name}</td>
                        <td>${dept.description || ''}</td>
                        <td><img src="${imageUrl}" alt="${dept.name}" class="table-thumb"></td>
                        <td>
                            <span class="badge ${dept.isActive ? 'bg-success' : 'bg-danger'}">
                                ${dept.isActive ? 'Active' : 'Inactive'}
                            </span>
                        </td>
                        <td>
                            <button class="btn btn-sm btn-primary btn-action edit-department" data-id="${dept._id}">
                                <i class="fas fa-edit"></i>
                            </button>
                            <button class="btn btn-sm btn-danger btn-action delete-department" data-id="${dept._id}">
                                <i class="fas fa-trash"></i>
                            </button>
                        </td>
                    </tr>
                `;
            });
            
            $('#departments-table').html(html);
            
            // Add event handlers
            $('.edit-department').click(function() {
                const id = $(this).data('id');
                editDepartment(id);
            });
            
            $('.delete-department').click(function() {
                const id = $(this).data('id');
                deleteDepartment(id);
            });
        })
        .fail(function() {
            showAlert('Error loading departments', 'danger');
        });
}

function loadCategories() {
    $.get('/api/admin/categories')
        .done(function(categories) {
            let html = '';
            
            categories.forEach(function(cat) {
                const imageUrl = resolveItemImage(cat) || IMAGE_PLACEHOLDER;
                const departmentName = cat.department ? cat.department.name : 'N/A';
                const sequenceNo = cat.ordering !== undefined ? cat.ordering : 0;
                html += `
                    <tr>
                        <td>${cat.name}</td>
                        <td>${departmentName}</td>
                        <td>${cat.description || ''}</td>
                        <td><img src="${imageUrl}" alt="${cat.name}" class="table-thumb"></td>
                        <td>
                            <span class="badge bg-info">${sequenceNo}</span>
                        </td>
                        <td>
                            <span class="badge ${cat.isFeatured ? 'bg-primary' : 'bg-secondary'}">
                                ${cat.isFeatured ? 'Featured' : 'Regular'}
                            </span>
                        </td>
                        <td>
                            <span class="badge ${cat.isActive ? 'bg-success' : 'bg-danger'}">
                                ${cat.isActive ? 'Active' : 'Inactive'}
                            </span>
                        </td>
                        <td>
                            <button class="btn btn-sm btn-primary btn-action edit-category" data-id="${cat._id}">
                                <i class="fas fa-edit"></i>
                            </button>
                            <button class="btn btn-sm btn-danger btn-action delete-category" data-id="${cat._id}">
                                <i class="fas fa-trash"></i>
                            </button>
                        </td>
                    </tr>
                `;
            });
            
            $('#categories-table').html(html);
            
            // Add event handlers
            $('.edit-category').click(function() {
                const id = $(this).data('id');
                editCategory(id);
            });
            
            $('.delete-category').click(function() {
                const id = $(this).data('id');
                deleteCategory(id);
            });
        })
        .fail(function() {
            showAlert('Error loading categories', 'danger');
        });
}

function loadSubcategories() {
    $.ajax({
        url: '/api/admin/subcategories',
        method: 'GET',
        dataType: 'json',
        contentType: 'application/json',
        error: function(xhr, status, error) {
            console.error('Error loading subcategories:', status, error);
            console.error('Response:', xhr.responseText);
            
            // Check if we got HTML instead of JSON (likely auth redirect or 404)
            if (xhr.responseText && xhr.responseText.trim().startsWith('<!DOCTYPE')) {
                showAlert('Authentication required. Please log in again.', 'warning');
                // Optionally redirect to login
                // window.location.href = '/login.html';
            } else if (xhr.status === 404) {
                showAlert('Subcategories API endpoint not found. Please check backend routes.', 'danger');
            } else {
                showAlert('Error loading subcategories: ' + (xhr.responseJSON?.message || error), 'danger');
            }
            $('#subcategories-table').html('<tr><td colspan="7" class="text-center text-danger">Error loading subcategories</td></tr>');
        }
    })
        .done(function(response) {
            // Handle both array response and object with array
            let subcategories = response;
            if (response && !Array.isArray(response)) {
                if (response.subcategories && Array.isArray(response.subcategories)) {
                    subcategories = response.subcategories;
                } else if (response.data && Array.isArray(response.data)) {
                    subcategories = response.data;
                } else {
                    console.error('Unexpected response format:', response);
                    showAlert('Error: Invalid response format from server', 'danger');
                    $('#subcategories-table').html('<tr><td colspan="7" class="text-center text-danger">Invalid response format</td></tr>');
                    return;
                }
            }
            
            // Ensure subcategories is an array
            if (!Array.isArray(subcategories)) {
                console.error('Subcategories is not an array:', subcategories);
                showAlert('Error: Subcategories data is not in the expected format', 'danger');
                $('#subcategories-table').html('<tr><td colspan="7" class="text-center">No subcategories found</td></tr>');
                return;
            }
            
            let html = '';
            
            if (subcategories.length === 0) {
                html = '<tr><td colspan="7" class="text-center text-muted">No subcategories found. Click "Add Subcategory" to create one.</td></tr>';
            } else {
                subcategories.forEach(function(subcat) {
                const imageUrl = resolveItemImage(subcat) || IMAGE_PLACEHOLDER;
                const categoryName = subcat.category ? subcat.category.name : 'N/A';
                html += `
                    <tr>
                        <td>${subcat.name}</td>
                        <td>${categoryName}</td>
                        <td>${subcat.description || ''}</td>
                        <td><img src="${imageUrl}" alt="${subcat.name}" class="table-thumb"></td>
                        <td>${subcat.ordering || 0}</td>
                        <td>
                            <span class="badge ${subcat.isActive ? 'bg-success' : 'bg-danger'}">
                                ${subcat.isActive ? 'Active' : 'Inactive'}
                            </span>
                        </td>
                        <td>
                            <button class="btn btn-sm btn-primary btn-action edit-subcategory" data-id="${subcat._id}">
                                <i class="fas fa-edit"></i>
                            </button>
                            <button class="btn btn-sm btn-danger btn-action delete-subcategory" data-id="${subcat._id}">
                                <i class="fas fa-trash"></i>
                            </button>
                        </td>
                    </tr>
                `;
                });
            }
            
            $('#subcategories-table').html(html);
            
            // Add event handlers
            $('.edit-subcategory').click(function() {
                const id = $(this).data('id');
                editSubcategory(id);
            });
            
            $('.delete-subcategory').click(function() {
                const id = $(this).data('id');
                deleteSubcategory(id);
            });
        })
        .fail(function() {
            showAlert('Error loading subcategories', 'danger');
        });
}

// Product filter state
let currentProductFilter = '';
let currentProductSearch = '';
let currentProductFilters = {
    category: '',
    department: '',
    subcategory: '',
    brand: '',
    minPrice: '',
    maxPrice: '',
    minDiscount: '',
    collection: ''
};

// Load categories for filter dropdown
function loadFilterCategories() {
    $.get('/api/admin/categories')
        .done(function(categories) {
            const select = $('#filter-category');
            select.html('<option value="">All Categories</option>');
            categories.forEach(function(category) {
                select.append(`<option value="${category._id}">${category.name}</option>`);
            });
        })
        .fail(function() {
            console.error('Error loading categories for filter');
        });
}

// Load departments for filter dropdown
function loadFilterDepartments() {
    $.get('/api/admin/departments')
        .done(function(departments) {
            const select = $('#filter-department');
            select.html('<option value="">All Departments</option>');
            departments.forEach(function(department) {
                select.append(`<option value="${department._id}">${department.name}</option>`);
            });
        })
        .fail(function() {
            console.error('Error loading departments for filter');
        });
}

// Load brands for filter dropdown
function loadFilterBrands() {
    $.ajax({
        url: '/api/admin/brands',
        method: 'GET',
        headers: {
            'x-auth-token': localStorage.getItem('token') || ''
        }
    })
        .done(function(response) {
            const brands = Array.isArray(response) ? response : (response.brands || response.data || []);
            const select = $('#filter-brand');
            select.html('<option value="">All Brands</option>');
            brands.forEach(function(brand) {
                if (brand.isActive !== false) {
                    select.append(`<option value="${brand._id}">${brand.name}</option>`);
                }
            });
        })
        .fail(function() {
            console.error('Error loading brands for filter');
        });
}

// Sections filter is now static dropdown - no need to load dynamically

function loadProducts(page = 1) {
    // Prevent multiple simultaneous requests
    if (window.loadingProducts) {
        console.log('Products already loading, skipping...');
        return;
    }
    window.loadingProducts = true;
    
    // Build query parameters
    const params = {
        page: page,
        limit: 10
    };
    
    if (currentProductFilter) {
        params.filter = currentProductFilter;
    }
    
    if (currentProductSearch) {
        params.search = currentProductSearch;
    }
    
    if (currentProductFilters.category) {
        params.category = currentProductFilters.category;
    }
    
    if (currentProductFilters.department) {
        params.department = currentProductFilters.department;
    }
    
    if (currentProductFilters.minPrice) {
        params.minPrice = currentProductFilters.minPrice;
    }
    
    if (currentProductFilters.maxPrice) {
        params.maxPrice = currentProductFilters.maxPrice;
    }
    
    if (currentProductFilters.minDiscount) {
        params.minDiscount = currentProductFilters.minDiscount;
    }
    
    if (currentProductFilters.section) {
        params.section = currentProductFilters.section;
    }
    
    // Add timestamp to prevent caching
    params._t = Date.now();
    const queryString = new URLSearchParams(params).toString();
    console.log('Loading products with params:', params);
    console.log('Query string:', queryString);
    
    $.ajax({
        url: `/api/admin/products?${queryString}`,
        method: 'GET',
        cache: false,
        headers: {
            'Cache-Control': 'no-cache',
            'Pragma': 'no-cache'
        }
    })
        .done(function(data) {
            window.loadingProducts = false; // Reset loading flag
            console.log('Products loaded:', data.products?.length || 0, 'products');
            if (currentProductFilters.section) {
                console.log('Filtered by section:', currentProductFilters.section);
            }
            let html = '';
            
            if (!data.products || data.products.length === 0) {
                html = '<tr><td colspan="13" class="text-center text-muted py-4">No products found. Try adjusting your filters.</td></tr>';
            } else {
                data.products.forEach(function(product) {
                const departmentName = product.department ? product.department.name : 'N/A';
                const categoryName = product.category ? product.category.name : 'N/A';
                const subcategoryName = product.subcategory ? (product.subcategory.name || product.subcategory) : '-';
                const brandName = product.brand ? (product.brand.name || product.brand) : '-';
                // Show sections as badges
                const sections = product.sections && Array.isArray(product.sections) ? product.sections : [];
                const sectionsDisplay = sections.length > 0 
                    ? sections.map(s => `<span class="badge bg-info me-1">${s}</span>`).join('')
                    : '<span class="text-muted">-</span>';
                const finalPrice = product.discount > 0 
                    ? product.price * (1 - product.discount / 100) 
                    : product.price;
                const imageUrl = resolveItemImage(product) || IMAGE_PLACEHOLDER;
                
                html += `
                    <tr>
                        <td><img src="${imageUrl}" alt="${product.name}" class="table-thumb"></td>
                        <td>${product.name}</td>
                        <td>${departmentName}</td>
                        <td>${categoryName}</td>
                        <td>${subcategoryName}</td>
                        <td>${brandName}</td>
                        <td>${sectionsDisplay}</td>
                        <td>Rs. ${finalPrice.toFixed(2)}</td>
                        <td>${product.discount}%</td>
                        <td>${product.stock}</td>
                        <td>
                            <span class="badge ${product.isFeatured ? 'bg-primary' : 'bg-secondary'}">
                                ${product.isFeatured ? 'Featured' : 'Regular'}
                            </span>
                        </td>
                        <td>
                            <!-- Backend already filters only active products, so always show Active here -->
                            <span class="badge bg-success">
                                Active
                            </span>
                        </td>
                        <td>
                            <button class="btn btn-sm btn-primary btn-action edit-product" data-id="${product._id}">
                                <i class="fas fa-edit"></i>
                            </button>
                            <button class="btn btn-sm btn-danger btn-action delete-product" data-id="${product._id}">
                                <i class="fas fa-trash"></i>
                            </button>
                        </td>
                    </tr>
                `;
                });
            }
            
            $('#products-table').html(html);
            
            // Update result count
            const resultCount = data.total || data.products.length;
            const resultText = resultCount === 1 ? 'product' : 'products';
            let filterInfo = '';
            if (currentProductFilter || currentProductSearch || currentProductFilters.category || currentProductFilters.department) {
                filterInfo = ` (filtered)`;
            }
            $('#products-result-count').text(`Showing ${data.products.length} of ${resultCount} ${resultText}${filterInfo}`);
            
            // Add pagination
            let paginationHtml = '';
            
            if (data.currentPage > 1) {
                paginationHtml += `<li class="page-item"><a class="page-link" href="#" data-page="${data.currentPage - 1}">Previous</a></li>`;
            }
            
            for (let i = 1; i <= data.totalPages; i++) {
                paginationHtml += `
                    <li class="page-item ${i === data.currentPage ? 'active' : ''}">
                        <a class="page-link" href="#" data-page="${i}">${i}</a>
                    </li>
                `;
            }
            
            if (data.currentPage < data.totalPages) {
                paginationHtml += `<li class="page-item"><a class="page-link" href="#" data-page="${data.currentPage + 1}">Next</a></li>`;
            }
            
            $('#products-pagination').html(paginationHtml);
            
            // Add event handlers
            $('.edit-product').click(function() {
                const id = $(this).data('id');
                editProduct(id);
            });
            
            $('.delete-product').click(function() {
                const id = $(this).data('id');
                deleteProduct(id);
            });
            
            $('.page-link').click(function(e) {
                e.preventDefault();
                const page = $(this).data('page');
                loadProducts(page);
            });
        })
        .fail(function(xhr, status, error) {
            window.loadingProducts = false; // Reset loading flag
            console.error('Error loading products:', {
                status: xhr.status,
                statusText: xhr.statusText,
                error: error,
                responseText: xhr.responseText
            });
            
            // Handle cache errors specifically (304 Not Modified)
            if (xhr.status === 304 || (error && error.toString().includes('CACHE'))) {
                console.warn('Cache error detected, retrying without cache...');
                // Clear browser cache for this URL and retry
                if (!window.cacheRetryCount) {
                    window.cacheRetryCount = 0;
                }
                window.cacheRetryCount++;
                
                if (window.cacheRetryCount < 3) {
                    // Retry with a new timestamp
                    setTimeout(function() {
                        params._t = Date.now() + Math.random();
                        const retryQueryString = new URLSearchParams(params).toString();
                        $.ajax({
                            url: `/api/admin/products?${retryQueryString}`,
                            method: 'GET',
                            cache: false,
                            headers: {
                                'Cache-Control': 'no-cache',
                                'Pragma': 'no-cache'
                            }
                        })
                        .done(function(data) {
                            window.cacheRetryCount = 0; // Reset on success
                            // Manually trigger the success handler
                            loadProducts(page);
                        })
                        .fail(function() {
                            window.cacheRetryCount = 0;
                            showAlert('Error loading products. Please refresh the page.', 'danger');
                        });
                    }, 100);
                } else {
                    window.cacheRetryCount = 0;
                    showAlert('Cache error. Please clear your browser cache or refresh the page.', 'warning');
                }
            } else {
                showAlert('Error loading products: ' + (error || xhr.statusText || 'Unknown error'), 'danger');
            }
        });
}

function loadSliders() {
    $.get('/api/admin/sliders')
        .done(function(sliders) {
            let html = '';
            
            sliders.forEach(function(slider) {
                const imageUrl = resolveItemImage(slider) || IMAGE_PLACEHOLDER;
                html += `
                    <tr>
                        <td>${slider.title}</td>
                        <td>${slider.description}</td>
                        <td><img src="${imageUrl}" alt="${slider.title}" class="table-thumb"></td>
                        <td>${slider.link}</td>
                        <td>${slider.order}</td>
                        <td>
                            <span class="badge ${slider.isActive ? 'bg-success' : 'bg-danger'}">
                                ${slider.isActive ? 'Active' : 'Inactive'}
                            </span>
                        </td>
                        <td>
                            <button class="btn btn-sm btn-primary btn-action edit-slider" data-id="${slider._id}">
                                <i class="fas fa-edit"></i>
                            </button>
                            <button class="btn btn-sm btn-danger btn-action delete-slider" data-id="${slider._id}">
                                <i class="fas fa-trash"></i>
                            </button>
                        </td>
                    </tr>
                `;
            });
            
            $('#sliders-table').html(html);
            
            // Add event handlers
            $('.edit-slider').click(function() {
                const id = $(this).data('id');
                editSlider(id);
            });
            
            $('.delete-slider').click(function() {
                const id = $(this).data('id');
                deleteSlider(id);
            });
        })
        .fail(function() {
            showAlert('Error loading sliders', 'danger');
        });
}

function loadBanners() {
    $.get('/api/admin/banners')
        .done(function(banners) {
            let html = '';
            
            banners.forEach(function(banner) {
                const imageUrl = resolveItemImage(banner) || IMAGE_PLACEHOLDER;
                const bannerType = banner.banner_type || 'image';
                const isVideo = bannerType === 'video';
                const typeBadge = isVideo 
                    ? '<span class="badge bg-info"><i class="fas fa-video"></i> Video</span>'
                    : '<span class="badge bg-primary"><i class="fas fa-image"></i> Image</span>';
                
                // Use video element for video banners, img for images
                const mediaElement = isVideo
                    ? `<video src="${imageUrl}" class="table-thumb" style="max-width: 100px; max-height: 60px; object-fit: cover;" muted></video>`
                    : `<img src="${imageUrl}" alt="${banner.title}" class="table-thumb">`;
                
                html += `
                    <tr>
                        <td>${banner.title || '<span class="text-muted fst-italic">No title</span>'}</td>
                        <td>${banner.description || '<span class="text-muted fst-italic">No description</span>'}</td>
                        <td>${mediaElement}</td>
                        <td>${typeBadge}</td>
                        <td>${banner.position}</td>
                        <td>
                            <span class="badge ${banner.isActive ? 'bg-success' : 'bg-danger'}">
                                ${banner.isActive ? 'Active' : 'Inactive'}
                            </span>
                        </td>
                        <td>
                            <button class="btn btn-sm btn-primary btn-action edit-banner" data-id="${banner._id}">
                                <i class="fas fa-edit"></i>
                            </button>
                            <button class="btn btn-sm btn-danger btn-action delete-banner" data-id="${banner._id}">
                                <i class="fas fa-trash"></i>
                            </button>
                        </td>
                    </tr>
                `;
            });
            
            $('#banners-table').html(html);
            
            // Add event handlers
            $('.edit-banner').click(function() {
                const id = $(this).data('id');
                editBanner(id);
            });
            
            $('.delete-banner').click(function() {
                const id = $(this).data('id');
                deleteBanner(id);
            });
        })
        .fail(function() {
            showAlert('Error loading banners', 'danger');
        });
}

// LEGACY SECTIONS - NO LONGER USED
/*
function loadSections() {
    console.log('Loading sections...');
    $.get('/api/admin/sections')
        .done(function(sections) {
            console.log('Sections loaded:', sections);
            let html = '';
            
            if (!sections || sections.length === 0) {
                html = '<tr><td colspan="7" class="text-center">No sections found</td></tr>';
            } else {
                sections.forEach(function(section) {
                    const sectionId = section._id || section.id;
                    html += `
                        <tr>
                            <td>${section.name || 'Unnamed'}</td>
                            <td><span class="badge bg-info">${section.type || 'N/A'}</span></td>
                            <td>${section.title || '-'}</td>
                            <td>${section.ordering !== undefined ? section.ordering : 0}</td>
                            <td>
                                <span class="badge ${section.isActive ? 'bg-success' : 'bg-danger'}">
                                    ${section.isActive ? 'Active' : 'Inactive'}
                                </span>
                            </td>
                            <td>
                                <span class="badge ${section.isPublished ? 'bg-primary' : 'bg-secondary'}">
                                    ${section.isPublished ? 'Published' : 'Draft'}
                                </span>
                            </td>
                            <td>
                                <button class="btn btn-sm btn-primary btn-action edit-section" data-id="${sectionId}">
                                    <i class="fas fa-edit"></i>
                                </button>
                                <button class="btn btn-sm btn-danger btn-action delete-section" data-id="${sectionId}">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </td>
                        </tr>
                    `;
                });
            }
            
            $('#sections-table').html(html);
            
            // Add event handlers
            $('.edit-section').click(function() {
                const id = $(this).data('id');
                console.log('Edit section clicked:', id);
                editSection(id);
            });
            
            $('.delete-section').click(function() {
                const id = $(this).data('id');
                console.log('Delete section clicked:', id);
                deleteSection(id);
            });
            
            console.log('Sections table updated');
        })
        .fail(function(error) {
            console.error('Error loading sections:', error);
            const errorMsg = error?.responseJSON?.message || 'Error loading sections';
            showAlert(errorMsg, 'danger');
            $('#sections-table').html('<tr><td colspan="7" class="text-center text-danger">Error loading sections</td></tr>');
        });
}
*/

function loadUsers(page) {
    $.get(`/api/admin/users?page=${page}`)
        .done(function(data) {
            let html = '';
            
            data.users.forEach(function(user) {
                html += `
                    <tr>
                        <td>${user.name}</td>
                        <td>${user.email}</td>
                        <td>${user.phone || 'N/A'}</td>
                        <td>
                            <span class="badge ${user.role === 'admin' ? 'bg-danger' : 'bg-primary'}">
                                ${user.role}
                            </span>
                        </td>
                        <td>
                            <span class="badge ${user.isActive ? 'bg-success' : 'bg-danger'}">
                                ${user.isActive ? 'Active' : 'Inactive'}
                            </span>
                        </td>
                        <td>
                            <button class="btn btn-sm btn-primary btn-action edit-user" data-id="${user._id}">
                                <i class="fas fa-edit"></i>
                            </button>
                            <button class="btn btn-sm btn-danger btn-action delete-user" data-id="${user._id}">
                                <i class="fas fa-trash"></i>
                            </button>
                        </td>
                    </tr>
                `;
            });
            
            $('#users-table').html(html);
            
            // Add pagination
            let paginationHtml = '';
            
            if (data.currentPage > 1) {
                paginationHtml += `<li class="page-item"><a class="page-link" href="#" data-page="${data.currentPage - 1}">Previous</a></li>`;
            }
            
            for (let i = 1; i <= data.totalPages; i++) {
                paginationHtml += `
                    <li class="page-item ${i === data.currentPage ? 'active' : ''}">
                        <a class="page-link" href="#" data-page="${i}">${i}</a>
                    </li>
                `;
            }
            
            if (data.currentPage < data.totalPages) {
                paginationHtml += `<li class="page-item"><a class="page-link" href="#" data-page="${data.currentPage + 1}">Next</a></li>`;
            }
            
            $('#users-pagination').html(paginationHtml);
            
            // Add event handlers
            $('.edit-user').click(function() {
                const id = $(this).data('id');
                editUser(id);
            });
            
            $('.delete-user').click(function() {
                const id = $(this).data('id');
                deleteUser(id);
            });
            
            $('.page-link').click(function(e) {
                e.preventDefault();
                const page = $(this).data('page');
                loadUsers(page);
            });
        })
        .fail(function() {
            showAlert('Error loading users', 'danger');
        });
}

function loadOrders(page) {
    const status = $('#orderStatusFilter').val() || '';
    const url = `/api/orders/admin/all?page=${page}&limit=20${status ? '&status=' + status : ''}`;
    
    $.get(url)
        .done(function(data) {
            // Update summary cards
            if (data.totalOrders !== undefined) {
                $('#orders-tab-total-orders').text(data.totalOrders || 0);
            }
            if (data.totalRevenue !== undefined) {
                const revenue = data.totalRevenue || 0;
                $('#orders-tab-total-revenue').text('Rs. ' + revenue.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 }));
            }
            
            let html = '';
            
            if (!data.orders || data.orders.length === 0) {
                html = '<tr><td colspan="7" class="text-center">No orders found</td></tr>';
            } else {
                data.orders.forEach(function(order) {
                    // Handle both user orders and guest orders
                    const customerName = order.customer ? order.customer.name : (order.user ? order.user.name : (order.guestCustomer ? order.guestCustomer.name : 'Unknown'));
                    const customerEmail = order.customer ? order.customer.email : (order.user ? order.user.email : (order.guestCustomer ? order.guestCustomer.email : ''));
                    const customerType = order.customer ? order.customer.type : (order.user ? 'user' : 'guest');
                    const date = new Date(order.createdAt).toLocaleDateString();
                    const itemCount = order.items ? order.items.reduce((sum, item) => sum + (item.quantity || 0), 0) : 0;
                    const statusClass = getStatusClass(order.status);
                    
                    html += `
                        <tr>
                            <td>${order.orderNumber || order._id}</td>
                            <td>${customerName}<br><small class="text-muted">${customerEmail}</small></td>
                            <td>${date}</td>
                            <td>${itemCount}</td>
                            <td>Rs. ${order.total.toFixed(2)}</td>
                            <td>
                                <span class="badge ${statusClass}">${order.status}</span>
                            </td>
                            <td>
                                <button class="btn btn-sm btn-primary btn-action view-order" data-id="${order._id}" title="View Order">
                                    <i class="fas fa-eye"></i>
                                </button>
                                <button class="btn btn-sm btn-success btn-action update-status-btn" data-id="${order._id}" data-status="${order.status}" title="Update Status">
                                    <i class="fas fa-edit"></i>
                                </button>
                            </td>
                        </tr>
                    `;
                });
            }
            
            $('#orders-table').html(html);
            
            // Add pagination
            let paginationHtml = '';
            if (data.totalPages > 1) {
                if (data.currentPage > 1) {
                    paginationHtml += `<li class="page-item"><a class="page-link" href="#" data-page="${data.currentPage - 1}">Previous</a></li>`;
                }
                
                for (let i = 1; i <= data.totalPages; i++) {
                    paginationHtml += `
                        <li class="page-item ${i === data.currentPage ? 'active' : ''}">
                            <a class="page-link" href="#" data-page="${i}">${i}</a>
                        </li>
                    `;
                }
                
                if (data.currentPage < data.totalPages) {
                    paginationHtml += `<li class="page-item"><a class="page-link" href="#" data-page="${data.currentPage + 1}">Next</a></li>`;
                }
            }
            
            $('#orders-pagination').html(paginationHtml);
            
            // Add event handlers
            $('.view-order').click(function() {
                const id = $(this).data('id');
                viewOrder(id);
            });
            
            $('.update-status-btn').click(function() {
                const id = $(this).data('id');
                const status = $(this).data('status');
                showOrderStatusModal(id, status);
            });
            
            $('.page-link').click(function(e) {
                e.preventDefault();
                const page = $(this).data('page');
                loadOrders(page);
            });
        })
        .fail(function() {
            showAlert('Error loading orders', 'danger');
        });
}

function getStatusClass(status) {
    const classes = {
        'pending': 'bg-warning',
        'confirmed': 'bg-info',
        'processing': 'bg-primary',
        'shipped': 'bg-secondary',
        'delivered': 'bg-success',
        'cancelled': 'bg-danger'
    };
    return classes[status] || 'bg-secondary';
}

async function viewOrder(id) {
    try {
        const order = await $.get(`/api/orders/${id}`);
        
        let itemsHtml = '';
        order.items.forEach(item => {
            const productName = item.product ? item.product.name : 'Unknown Product';
            const itemTotal = item.subtotal || (item.price * item.quantity * (1 - (item.discount || 0) / 100));
            itemsHtml += `
                <tr>
                    <td>${productName}</td>
                    <td>${item.quantity}</td>
                    <td>Rs. ${item.price.toFixed(2)}</td>
                    <td>${item.discount || 0}%</td>
                    <td>Rs. ${itemTotal.toFixed(2)}</td>
                </tr>
            `;
        });
        
        // Handle both user orders and guest orders
        let customerName = 'Unknown';
        let customerEmail = 'N/A';
        let customerPhone = 'N/A';
        
        if (order.customer) {
            // Order from admin route (formatted)
            customerName = order.customer.name || 'Unknown';
            customerEmail = order.customer.email || 'N/A';
            customerPhone = order.customer.phone || 'N/A';
        } else if (order.user) {
            // User order
            customerName = order.user.name || 'Unknown';
            customerEmail = order.user.email || 'N/A';
            customerPhone = order.user.phone || 'N/A';
        } else if (order.guestCustomer) {
            // Guest order
            customerName = order.guestCustomer.name || 'Unknown';
            customerEmail = order.guestCustomer.email || 'N/A';
            customerPhone = order.guestCustomer.phone || 'N/A';
        }
        
        // Also check shipping address for phone number if not found
        if (customerPhone === 'N/A' && order.shippingAddress && order.shippingAddress.phone) {
            customerPhone = order.shippingAddress.phone;
        }
        
        const customerInfo = `
            <p><strong>Name:</strong> ${customerName}</p>
            <p><strong>Email:</strong> ${customerEmail}</p>
            <p><strong>Phone:</strong> ${customerPhone}</p>
        `;
        
        const shippingAddress = order.shippingAddress ? `
            <p>${order.shippingAddress.street || ''}</p>
            <p>${order.shippingAddress.city || ''}, ${order.shippingAddress.state || ''} ${order.shippingAddress.zipCode || ''}</p>
            <p>${order.shippingAddress.country || ''}</p>
        ` : '<p>No shipping address provided</p>';
        
        const orderHtml = `
            <div class="row">
                <div class="col-md-6">
                    <h6>Order Information</h6>
                    <p><strong>Order Number:</strong> ${order.orderNumber}</p>
                    <p><strong>Date:</strong> ${new Date(order.createdAt).toLocaleString()}</p>
                    <p><strong>Status:</strong> <span class="badge ${getStatusClass(order.status)}">${order.status}</span></p>
                    <p><strong>Payment Method:</strong> ${order.paymentMethod || 'N/A'}</p>
                    <p><strong>Payment Status:</strong> ${order.paymentStatus || 'N/A'}</p>
                </div>
                <div class="col-md-6">
                    <h6>Customer Information</h6>
                    ${customerInfo}
                    <h6 class="mt-3">Shipping Address</h6>
                    ${shippingAddress}
                </div>
            </div>
            <hr>
            <h6>Order Items</h6>
            <table class="table table-sm">
                <thead>
                    <tr>
                        <th>Product</th>
                        <th>Quantity</th>
                        <th>Price</th>
                        <th>Discount</th>
                        <th>Subtotal</th>
                    </tr>
                </thead>
                <tbody>
                    ${itemsHtml}
                </tbody>
            </table>
            <div class="text-end">
                <p><strong>Subtotal:</strong> Rs. ${order.subtotal.toFixed(2)}</p>
                <p><strong>Shipping:</strong> Rs. ${(order.shippingCost || 0).toFixed(2)}</p>
                <p><strong>Tax:</strong> Rs. ${(order.tax || 0).toFixed(2)}</p>
                <h5><strong>Total: Rs. ${order.total.toFixed(2)}</strong></h5>
            </div>
        `;
        
        $('#orderModalBody').html(orderHtml);
        $('#confirmOrderBtn').data('order-id', order._id);
        $('#updateOrderStatusBtn').data('order-id', order._id).data('current-status', order.status);
        
        if (order.status === 'pending') {
            $('#confirmOrderBtn').show();
        } else {
            $('#confirmOrderBtn').hide();
        }
        
        $('#orderModal').modal('show');
    } catch (error) {
        console.error('Error loading order', error);
        showAlert('Error loading order', 'danger');
    }
}

function showOrderStatusModal(orderId, currentStatus) {
    $('#orderStatusId').val(orderId);
    $('#orderStatusSelect').val(currentStatus);
    $('#cancelledReason').val('');
    if (currentStatus === 'cancelled') {
        $('#cancelledReasonDiv').show();
    } else {
        $('#cancelledReasonDiv').hide();
    }
    $('#orderStatusModal').modal('show');
}

async function confirmOrder(orderId) {
    try {
        await $.ajax({
            url: `/api/orders/${orderId}/confirm`,
            method: 'POST'
        });
        
        $('#orderModal').modal('hide');
        showAlert('Order confirmed successfully', 'success');
        loadOrders(1);
    } catch (error) {
        console.error('Error confirming order', error);
        showAlert('Error confirming order', 'danger');
    }
}

async function updateOrderStatus() {
    const orderId = $('#orderStatusId').val();
    const status = $('#orderStatusSelect').val();
    const cancelledReason = $('#cancelledReason').val();
    
    try {
        await $.ajax({
            url: `/api/orders/${orderId}/status`,
            method: 'PUT',
            contentType: 'application/json',
            data: JSON.stringify({ status, cancelledReason })
        });
        
        $('#orderStatusModal').modal('hide');
        $('#orderModal').modal('hide');
        showAlert('Order status updated successfully', 'success');
        loadOrders(1);
    } catch (error) {
        console.error('Error updating order status', error);
        showAlert('Error updating order status', 'danger');
    }
}

function loadReportFilters() {
    // Load departments
    $.get('/api/admin/reports/departments')
        .done(function(departments) {
            let html = '<option value="">All Departments</option>';
            departments.forEach(dept => {
                html += `<option value="${dept._id}">${dept.name}</option>`;
            });
            $('#reportDepartment').html(html);
        });
    
    // Load categories
    loadReportCategories();
}

function loadReportCategories(departmentId) {
    const url = departmentId 
        ? `/api/admin/reports/categories?departmentId=${departmentId}`
        : '/api/admin/reports/categories';
    
    $.get(url)
        .done(function(categories) {
            let html = '<option value="">All Categories</option>';
            categories.forEach(cat => {
                html += `<option value="${cat._id}">${cat.name}</option>`;
            });
            $('#reportCategory').html(html);
        });
}

function loadReportProducts(categoryId, departmentId) {
    let url = '/api/admin/reports/products?';
    if (categoryId) url += `categoryId=${categoryId}&`;
    if (departmentId) url += `departmentId=${departmentId}`;
    
    $.get(url)
        .done(function(products) {
            let html = '<option value="">All Products</option>';
            products.forEach(prod => {
                html += `<option value="${prod._id}">${prod.name}</option>`;
            });
            $('#reportProduct').html(html);
        });
}

async function generateSalesReport() {
    const period = $('#reportPeriod').val();
    const departmentId = $('#reportDepartment').val() || undefined;
    const categoryId = $('#reportCategory').val() || undefined;
    const productId = $('#reportProduct').val() || undefined;
    const status = $('#reportStatus').val() || undefined;
    const startDate = $('#reportStartDate').val() || undefined;
    const endDate = $('#reportEndDate').val() || undefined;
    
    let url = '/api/admin/reports/sales?';
    if (period) url += `period=${period}&`;
    if (departmentId) url += `departmentId=${departmentId}&`;
    if (categoryId) url += `categoryId=${categoryId}&`;
    if (productId) url += `productId=${productId}&`;
    if (status) url += `status=${status}&`;
    if (startDate) url += `startDate=${startDate}&`;
    if (endDate) url += `endDate=${endDate}&`;
    
    try {
        const report = await $.get(url);
        
        // Update summary
        $('#reportTotalSales').text('Rs. ' + report.summary.totalSales.toFixed(2));
        $('#reportTotalOrders').text(report.summary.totalOrders);
        $('#reportTotalItems').text(report.summary.totalItems);
        $('#reportAvgOrder').text('Rs. ' + report.summary.averageOrderValue.toFixed(2));
        
        // Update by department
        let deptHtml = '';
        if (report.byDepartment.length === 0) {
            deptHtml = '<tr><td colspan="4" class="text-center">No data</td></tr>';
        } else {
            report.byDepartment.forEach(dept => {
                deptHtml += `
                    <tr>
                        <td>${dept.name}</td>
                        <td>Rs. ${dept.sales.toFixed(2)}</td>
                        <td>${dept.orders}</td>
                        <td>${dept.items}</td>
                    </tr>
                `;
            });
        }
        $('#reportByDepartment').html(deptHtml);
        
        // Update by category
        let catHtml = '';
        if (report.byCategory.length === 0) {
            catHtml = '<tr><td colspan="3" class="text-center">No data</td></tr>';
        } else {
            report.byCategory.forEach(cat => {
                catHtml += `
                    <tr>
                        <td>${cat.name}</td>
                        <td>Rs. ${cat.sales.toFixed(2)}</td>
                        <td>${cat.items}</td>
                    </tr>
                `;
            });
        }
        $('#reportByCategory').html(catHtml);
        
        // Update by product
        let prodHtml = '';
        if (report.byProduct.length === 0) {
            prodHtml = '<tr><td colspan="4" class="text-center">No data</td></tr>';
        } else {
            // Sort by sales descending and take top 20
            const topProducts = report.byProduct.sort((a, b) => b.sales - a.sales).slice(0, 20);
            topProducts.forEach(prod => {
                prodHtml += `
                    <tr>
                        <td>${prod.name}</td>
                        <td>Rs. ${prod.sales.toFixed(2)}</td>
                        <td>${prod.items}</td>
                        <td>Rs. ${prod.price.toFixed(2)}</td>
                    </tr>
                `;
            });
        }
        $('#reportByProduct').html(prodHtml);
        
        $('#reportResults').show();
    } catch (error) {
        console.error('Error generating report', error);
        showAlert('Error generating report', 'danger');
    }
}

function exportReport() {
    // Simple CSV export implementation
    const csv = [];
    csv.push(['Metric', 'Value']);
    csv.push(['Total Sales', $('#reportTotalSales').text()]);
    csv.push(['Total Orders', $('#reportTotalOrders').text()]);
    csv.push(['Total Items', $('#reportTotalItems').text()]);
    csv.push(['Average Order Value', $('#reportAvgOrder').text()]);
    
    const csvContent = csv.map(row => row.join(',')).join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `sales-report-${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    window.URL.revokeObjectURL(url);
}

// Helper functions
function loadDepartmentsToSelect(selectId, options = {}) {
    const { includeInactive = false, selectedId } = options;
    const url = includeInactive ? '/api/admin/departments' : '/api/departments';

    return $.get(url).then(
        function (departments = []) {
            let html = '<option value="">Select Department</option>';

            departments.forEach(function (dept) {
                const isActive = dept.isActive !== false;
                const label = isActive ? dept.name : `${dept.name} (inactive)`;
                html += `<option value="${dept._id}">${label}</option>`;
            });

            $(selectId).html(html);

            if (selectedId) {
                $(selectId).val(String(selectedId));
            }

            return departments;
        },
        function () {
            $(selectId).html('<option value="">Unable to load departments</option>');
            showAlert('Error loading departments', 'danger');
            return [];
        }
    );
}

function loadSubcategoriesToSelect(selectId, categoryId, options = {}) {
    const { selectedId } = options;

    if (!categoryId) {
        $(selectId).html('<option value="">Select Category First</option>');
        return $.Deferred().resolve([]).promise();
    }

    return $.get(`/api/subcategories/category/${categoryId}`).then(
        function (subcategories = []) {
            let html = '<option value="">No Subcategory</option>';

            subcategories.forEach(function (subcat) {
                const isActive = subcat.isActive !== false;
                const label = isActive ? subcat.name : `${subcat.name} (inactive)`;
                html += `<option value="${subcat._id}">${label}</option>`;
            });

            $(selectId).html(html);

            if (selectedId) {
                $(selectId).val(String(selectedId));
            }

            return subcategories;
        },
        function () {
            $(selectId).html('<option value="">Unable to load subcategories</option>');
            return [];
        }
    );
}

function loadBrandSectionsToSelect(selectId, options = {}) {
    const { selectedId } = options;
    const token = localStorage.getItem('token');
    
    console.log('Loading brands for selector:', selectId);
    console.log('Token present:', !!token);
    
    return $.ajax({
        url: '/api/admin/brand-sections',
        method: 'GET',
        dataType: 'json',
        headers: {
            'x-auth-token': token || ''
        }
    }).done(function(response) {
        console.log('Brands AJAX response:', response);
        console.log('Response type:', typeof response);
        console.log('Is Array:', Array.isArray(response));
        
        const brands = Array.isArray(response) ? response : (response.sections || response.data || []);
        console.log('Processed brands count:', brands.length);
        console.log('Processed brands:', brands);
        
        let html = '<option value="">-- No Brand --</option>';
        
        // Group brands by section for better organization
        let groupedBySection = {};
        brands.forEach(brand => {
            if (brand && brand.name) {
                const sectionName = brand.sectionName || 'Other';
                if (!groupedBySection[sectionName]) {
                    groupedBySection[sectionName] = [];
                }
                groupedBySection[sectionName].push(brand);
            }
        });
        
        // Add options grouped by section
        Object.keys(groupedBySection).sort().forEach(sectionName => {
            const brandsList = groupedBySection[sectionName];
            brandsList.forEach(brand => {
                console.log(`Adding brand option: ${brand.name} from ${sectionName} (ID: ${brand._id})`);
                html += `<option value="${brand._id}">${brand.name}</option>`;
            });
        });
        
        console.log('Final HTML for dropdown:', html);
        $(selectId).html(html);
        
        if (selectedId) {
            $(selectId).val(String(selectedId));
        }
        
        return brands;
    }).fail(function(error) {
        console.error('Error loading brands - AJAX failed:', error);
        console.error('Status:', error.status);
        console.error('StatusText:', error.statusText);
        console.error('ResponseText:', error.responseText);
        $(selectId).html('<option value="">Unable to load brands</option>');
        return [];
    });
}

function loadCategoriesToSelect(selectId, departmentId, options = {}) {
    const { selectedId } = options;

    if (!departmentId) {
        // If no department, load all categories
        return $.get('/api/categories').then(
            function (categories = []) {
                let html = '<option value="">Select Category</option>';
                categories.forEach(function (cat) {
                    const isActive = cat.isActive !== false;
                    const label = isActive ? cat.name : `${cat.name} (inactive)`;
                    html += `<option value="${cat._id}">${label}</option>`;
                });
                $(selectId).html(html);
                if (selectedId) {
                    $(selectId).val(String(selectedId));
                }
                return categories;
            },
            function () {
                $(selectId).html('<option value="">Unable to load categories</option>');
                showAlert('Error loading categories', 'danger');
                return [];
            }
        );
    }

    return $.get(`/api/categories/department/${departmentId}`).then(
        function (categories = []) {
            let html = '<option value="">Select Category</option>';

            categories.forEach(function (cat) {
                const isActive = cat.isActive !== false;
                const label = isActive ? cat.name : `${cat.name} (inactive)`;
                html += `<option value="${cat._id}">${label}</option>`;
            });

            $(selectId).html(html);

            if (selectedId) {
                $(selectId).val(String(selectedId));
            }

            return categories;
        },
        function () {
            $(selectId).html('<option value="">Unable to load categories</option>');
            showAlert('Error loading categories', 'danger');
            return [];
        }
    );
}

// Form reset functions
function resetDepartmentForm() {
    $('#departmentForm')[0].reset();
    $('#departmentId').val('');
    $('#departmentImageFile').val('');
    $('#departmentImageFileId').val('');
    setImagePreview('#departmentImagePreview', null);
}

function resetCategoryForm() {
    $('#categoryForm')[0].reset();
    $('#categoryId').val('');
    $('#categoryImageFile').val('');
    $('#categoryImageFileId').val('');
    setImagePreview('#categoryImagePreview', null);
    $('#categoryDepartment').html('<option value="">Select Department</option>');
}

function resetSubcategoryForm() {
    $('#subcategoryForm')[0].reset();
    $('#subcategoryId').val('');
    $('#subcategoryImageFile').val('');
    $('#subcategoryImageFileId').val('');
    $('#subcategoryOrdering').val('0');
    setImagePreview('#subcategoryImagePreview', null);
    $('#subcategoryCategory').html('<option value="">Select Category</option>');
}

function resetProductForm() {
    $('#productForm')[0].reset();
    $('#productId').val('');
    $('#productImageFile').val('');
    $('#productImageFileId').val('');
    // Clear section checkboxes
    $('#productSections').val([]);
    setImagePreview('#productImagePreview', null);
    $('#productDepartment').html('<option value="">Select Department</option>');
    $('#productCategory').html('<option value="">Select Department First</option>');
    $('#productSubcategory').html('<option value="">Select Category First</option>');
    // Load brand sections
    loadBrandSectionsToSelect('#brand');
    // Update field requirements based on brand selection
    updateFieldRequirements();
}

function updateFieldRequirements() {
    const hasBrand = $('#brand').val();
    
    if (hasBrand) {
        // Brand selected - make department/category optional
        $('#productDepartment').prop('required', false).css('border-color', '');
        $('#productCategory').prop('required', false).css('border-color', '');
        $('#deptRequiredBadge').hide();
        $('#catRequiredBadge').hide();
    } else {
        // No brand - make department/category required
        $('#productDepartment').prop('required', true);
        $('#productCategory').prop('required', true);
        $('#deptRequiredBadge').show();
        $('#catRequiredBadge').show();
    }
}

function resetSliderForm() {
    $('#sliderForm')[0].reset();
    $('#sliderId').val('');
    $('#sliderImageFile').val('');
    $('#sliderImageFileId').val('');
    $('#sliderVideoUrl').val('');
    setImagePreview('#sliderImagePreview', null);
}

function resetBannerForm() {
    $('#bannerForm')[0].reset();
    $('#bannerId').val('');
    $('#bannerImageFile').val('');
    $('#bannerImageFileId').val('');
    $('#bannerSize').val('medium');
    $('#customBannerDimensions').hide();
    $('#bannerCustomWidth').val('');
    $('#bannerCustomHeight').val('');
    setImagePreview('#bannerImagePreview', null);
}

// LEGACY SECTIONS - NO LONGER USED
/*
function resetSectionForm() {
    $('#sectionForm')[0].reset();
    $('#sectionId').val('');
    $('#sectionOrdering').val('0');
    $('#sectionActive').prop('checked', true);
    $('#sectionPublished').prop('checked', false);
}
*/

// Save functions
async function saveDepartment() {
    const id = $('#departmentId').val();
    const method = id ? 'PUT' : 'POST';
    const url = id ? `/api/departments/${id}` : '/api/departments';

    try {
        const uploadedMedia = await uploadImageIfNeeded('#departmentImageFile', 'departments');
        const imageUrl = ($('#departmentImage').val() || '').trim();
        const existingFileId = normaliseFileId($('#departmentImageFileId').val());

    const payload = {
            name: $('#departmentName').val(),
            description: $('#departmentDescription').val(),
            isActive: $('#departmentActive').is(':checked')
        };

        if (!uploadedMedia && !imageUrl && !existingFileId) {
            showAlert('Please provide an image via URL or by uploading a file.', 'warning');
            return;
        }

        if (uploadedMedia) {
            payload.image = uploadedMedia.url;
            payload.imageFileId = uploadedMedia._id;
            $('#departmentImageFileId').val(uploadedMedia._id);
            $('#departmentImage').val(uploadedMedia.url);
            setImagePreview('#departmentImagePreview', uploadedMedia.url);
        } else {
            if (imageUrl) {
                payload.image = imageUrl;
            }
            if (existingFileId) {
                payload.imageFileId = existingFileId;
            }
        }

        await $.ajax({
            url,
            method,
            contentType: 'application/json',
            data: JSON.stringify(payload)
        });

        $('#departmentModal').modal('hide');
        showAlert(id ? 'Department updated successfully' : 'Department added successfully', 'success');
        loadAdminDepartments();
        loadDashboardData();
    } catch (error) {
        console.error('Error saving department', error);
        
        // Extract and display the actual error message
        let errorMessage = 'Error saving department';
        if (error.message) {
            errorMessage = error.message;
        } else if (error.responseJSON && error.responseJSON.message) {
            errorMessage = error.responseJSON.message;
        } else if (typeof error === 'string') {
            errorMessage = error;
        }
        
        showAlert(errorMessage, 'danger');
    }
}

async function saveCategory() {
    const id = $('#categoryId').val();
    const method = id ? 'PUT' : 'POST';
    const url = id ? `/api/categories/${id}` : '/api/categories';

    try {
        // Validate required fields
        const name = $('#categoryName').val()?.trim();
        const department = $('#categoryDepartment').val();
        const description = $('#categoryDescription').val()?.trim();

        if (!name) {
            showAlert('Category name is required', 'warning');
            return;
        }

        if (!department) {
            showAlert('Please select a department', 'warning');
            return;
        }

        if (!description) {
            showAlert('Category description is required', 'warning');
            return;
        }

        const uploadedMedia = await uploadImageIfNeeded('#categoryImageFile', 'categories');
        const imageUrl = ($('#categoryImage').val() || '').trim();
        const existingFileId = normaliseFileId($('#categoryImageFileId').val());

    const payload = {
            name: name,
            department: department,
            description: description,
            ordering: parseInt($('#categoryOrdering').val() || '0', 10) || 0,
            isFeatured: $('#categoryFeatured').is(':checked'),
            isActive: $('#categoryActive').is(':checked')
        };

        // Image is optional for updates, required for new categories
        if (!id && !uploadedMedia && !imageUrl && !existingFileId) {
            showAlert('Please provide an image via URL or by uploading a file.', 'warning');
            return;
        }

        if (uploadedMedia) {
            payload.image = uploadedMedia.url;
            payload.imageFileId = uploadedMedia._id;
            $('#categoryImageFileId').val(uploadedMedia._id);
            $('#categoryImage').val(uploadedMedia.url);
            setImagePreview('#categoryImagePreview', uploadedMedia.url);
        } else {
            if (imageUrl) {
                payload.image = imageUrl;
            }
            if (existingFileId) {
                payload.imageFileId = existingFileId;
            }
        }

        const response = await $.ajax({
            url,
            method,
            contentType: 'application/json',
            data: JSON.stringify(payload)
        });

        $('#categoryModal').modal('hide');
        showAlert(id ? 'Category updated successfully' : 'Category added successfully', 'success');
        loadCategories();
        loadDashboardData();
    } catch (error) {
        console.error('Error saving category', error);
        
        // Extract error message from response
        let errorMessage = 'Error saving category';
        if (error.responseJSON && error.responseJSON.message) {
            errorMessage = error.responseJSON.message;
        } else if (error.responseText) {
            try {
                const errorData = JSON.parse(error.responseText);
                errorMessage = errorData.message || errorMessage;
            } catch (e) {
                errorMessage = error.responseText || errorMessage;
            }
        } else if (error.message) {
            errorMessage = error.message;
        }
        
        showAlert(errorMessage, 'danger');
    }
}

async function saveSubcategory() {
    const id = $('#subcategoryId').val();
    const method = id ? 'PUT' : 'POST';
    const url = id ? `/api/subcategories/${id}` : '/api/subcategories';

    try {
        const name = $('#subcategoryName').val()?.trim();
        const category = $('#subcategoryCategory').val();

        if (!name) {
            showAlert('Subcategory name is required', 'warning');
            return;
        }

        if (!category) {
            showAlert('Please select a category', 'warning');
            return;
        }

        const uploadedMedia = await uploadImageIfNeeded('#subcategoryImageFile', 'subcategories');
        const imageUrl = ($('#subcategoryImage').val() || '').trim();
        const existingFileId = normaliseFileId($('#subcategoryImageFileId').val());

        const payload = {
            name: name,
            category: category,
            description: $('#subcategoryDescription').val() || '',
            ordering: parseInt($('#subcategoryOrdering').val()) || 0,
            isActive: $('#subcategoryActive').is(':checked')
        };

        if (uploadedMedia) {
            payload.image = uploadedMedia.url;
            payload.imageFileId = uploadedMedia._id;
            $('#subcategoryImageFileId').val(uploadedMedia._id);
            $('#subcategoryImage').val(uploadedMedia.url);
            setImagePreview('#subcategoryImagePreview', uploadedMedia.url);
        } else {
            if (imageUrl) {
                payload.image = imageUrl;
            }
            if (existingFileId) {
                payload.imageFileId = existingFileId;
            }
        }

        const response = await $.ajax({
            url,
            method,
            contentType: 'application/json',
            data: JSON.stringify(payload)
        });

        $('#subcategoryModal').modal('hide');
        showAlert(id ? 'Subcategory updated successfully' : 'Subcategory added successfully', 'success');
        loadSubcategories();
        loadDashboardData();
    } catch (error) {
        console.error('Error saving subcategory', error);
        
        let errorMessage = 'Error saving subcategory';
        if (error.responseJSON && error.responseJSON.message) {
            errorMessage = error.responseJSON.message;
        } else if (error.message) {
            errorMessage = error.message;
        }
        
        showAlert(errorMessage, 'danger');
    }
}

function editSubcategory(id) {
    $.get(`/api/subcategories/${id}`)
        .done(function(subcat) {
            $('#subcategoryId').val(subcat._id);
            $('#subcategoryName').val(subcat.name);
            $('#subcategoryDescription').val(subcat.description || '');
            $('#subcategoryOrdering').val(subcat.ordering || 0);
            $('#subcategoryActive').prop('checked', subcat.isActive !== false);
            
            // Load categories and select the current one
            const categoryId = subcat.category._id || subcat.category;
            loadCategoriesToSelect('#subcategoryCategory', null, { selectedId: categoryId });
            
            // Handle image
            if (subcat.image) {
                $('#subcategoryImage').val(subcat.image);
                setImagePreview('#subcategoryImagePreview', subcat.image);
            } else {
                setImagePreview('#subcategoryImagePreview', null);
            }
            
            if (subcat.imageUpload) {
                $('#subcategoryImageFileId').val(subcat.imageUpload._id);
            }
            
            $('#subcategoryModalTitle').text('Edit Subcategory');
            $('#subcategoryModal').modal('show');
        })
        .fail(function() {
            showAlert('Error loading subcategory', 'danger');
        });
}

function deleteSubcategory(id) {
    if (!confirm('Are you sure you want to delete this subcategory?')) {
        return;
    }
    
    $.ajax({
        url: `/api/subcategories/${id}`,
        method: 'DELETE'
    })
        .done(function() {
            showAlert('Subcategory deleted successfully', 'success');
            loadSubcategories();
            loadDashboardData();
        })
        .fail(function() {
            showAlert('Error deleting subcategory', 'danger');
        });
}

async function saveProduct() {
    const id = $('#productId').val();
    const method = id ? 'PUT' : 'POST';
    const url = id ? `/api/products/${id}` : '/api/products';

    try {
        // Debug: Log all form elements
        console.log('All form elements:', 
            Array.from(document.querySelectorAll('select, input, textarea'))
                .map(el => ({
                    id: el.id,
                    name: el.name,
                    value: el.value,
                    tagName: el.tagName,
                    selected: el.selected,
                    options: el.options ? Array.from(el.options).map(opt => ({
                        value: opt.value,
                        text: opt.text,
                        selected: opt.selected
                    })) : []
                }))
        );

        // Get form values with debug logging
        const name = $('#productName').val()?.trim();
        const category = $('#productCategory').val();
        const department = $('#productDepartment').val();
        
        // Get brand select element and its value
        const brandSelect = document.getElementById('brand');
        console.log('Brand select element:', brandSelect);
        
        let brand = null;
        if (brandSelect) {
            brand = brandSelect.value || null;
            console.log('Brand select value:', brand);
            console.log('Selected brand option:', brandSelect.options[brandSelect.selectedIndex]);
            
            // Log all brand options with their values and selected state
            console.log('All brand options:', 
                Array.from(brandSelect.options).map(opt => ({
                    value: opt.value,
                    text: opt.text,
                    selected: opt.selected
                }))
            );
        } else {
            console.error('Brand select element not found!');
        }
        
        const description = $('#productDescription').val()?.trim();
        const priceInput = $('#productPrice').val()?.trim();
        const stockInput = $('#productStock').val()?.trim();
        
        console.log('Form values:', { 
            name, 
            category, 
            department, 
            brand, 
            description,
            brandSelectExists: !!brandSelect,
            brandSelectValue: brandSelect ? brandSelect.value : 'No select found'
        });
        
        // Basic validation
        if (!name) {
            showAlert('Product name is required', 'warning');
            return;
        }
        
        // Either brand OR (category AND department) is required
        if (!brand && (!category || !department)) {
            console.log('Validation failed:', {
                brandValue: brand,
                categoryValue: category,
                departmentValue: department,
                brandSelectExists: !!brandSelect,
                brandSelectOptions: brandSelect ? Array.from(brandSelect.options).map(opt => opt.value) : 'No select found'
            });
            showAlert('Please either select a Brand OR select both Category and Department', 'warning');
            return;
        }
        
        if (!description) {
            showAlert('Product description is required', 'warning');
            return;
        }
        
        if (!priceInput) {
            showAlert('Product price is required', 'warning');
            return;
        }
        
        const price = parseFloat(priceInput);
        if (Number.isNaN(price) || price < 0) {
            showAlert('Product price must be a valid number greater than or equal to 0', 'warning');
            return;
        }
        
        if (!stockInput) {
            showAlert('Stock quantity is required', 'warning');
            return;
        }
        
        const stock = parseInt(stockInput, 10);
        if (Number.isNaN(stock) || stock < 0) {
            showAlert('Stock quantity must be a valid number greater than or equal to 0', 'warning');
            return;
        }
        
        const discountInput = $('#productDiscount').val()?.trim();
        const discount = discountInput ? parseFloat(discountInput) : 0;
        if (Number.isNaN(discount) || discount < 0 || discount > 100) {
            showAlert('Discount must be a number between 0 and 100', 'warning');
            return;
        }
        
        const uploadedMedia = await uploadImageIfNeeded('#productImageFile', 'products');
        const imageUrl = ($('#productImage').val() || '').trim();
        const existingFileId = normaliseFileId($('#productImageFileId').val());

        // Collect selected sections from dropdown
        const selectedSections = [];
        $('#productSections option:selected').each(function() {
            selectedSections.push($(this).val());
        });

        const subcategory = $('#productSubcategory').val();
        
        // Log the brand value for debugging
        console.log('Saving product with brand ID:', brand);
        
        const payload = {
            name: name,
            price: price,
            description: description,
            stock: stock,
            discount: discount,
            isFeatured: $('#productFeatured').is(':checked'),
            isTrending: $('#productTrending').is(':checked'),
            isNewArrival: $('#productNewArrival').is(':checked'),
            isBestSelling: $('#productBestSelling').is(':checked'),
            isTopSelling: $('#productTopSelling').is(':checked'),
            sections: selectedSections,
            brand: brand || null,  // Use the brand value we already retrieved
            isActive: $('#productActive').is(':checked')
        };
        
        console.log('Payload with brand:', payload);
        
        // Add category/department only if provided (optional for brand-only products)
        if (category) {
            payload.category = category;
        }
        if (department) {
            payload.department = department;
        }
        if (subcategory) {
            payload.subcategory = subcategory;
        }

        if (!uploadedMedia && !imageUrl && !existingFileId) {
            showAlert('Please provide an image via URL or by uploading a file.', 'warning');
            return;
        }

        if (uploadedMedia) {
            payload.image = uploadedMedia.url;
            payload.imageFileId = uploadedMedia._id;
            $('#productImageFileId').val(uploadedMedia._id);
            $('#productImage').val(uploadedMedia.url);
            setImagePreview('#productImagePreview', uploadedMedia.url);
        } else {
            if (imageUrl) {
                payload.image = imageUrl;
            }
            if (existingFileId) {
                payload.imageFileId = existingFileId;
            }
        }

        await $.ajax({
            url,
            method,
            contentType: 'application/json',
            data: JSON.stringify(payload)
        });

        $('#productModal').modal('hide');
        showAlert(id ? 'Product updated successfully' : 'Product added successfully', 'success');
        loadProducts(1);
        loadDashboardData();
    } catch (error) {
        console.error('🔴 Error saving product:');
        console.error('  Status:', error.status);
        console.error('  StatusText:', error.statusText);
        console.error('  ResponseText:', error.responseText);
        console.error('  ResponseJSON:', error.responseJSON);
        console.error('  Full error object:', error);
        
        // Extract error message from response
        let errorMessage = 'Error saving product';
        if (error.responseJSON && error.responseJSON.message) {
            errorMessage = error.responseJSON.message;
        } else if (error.responseText) {
            try {
                const errorData = JSON.parse(error.responseText);
                errorMessage = errorData.message || errorMessage;
            } catch (e) {
                errorMessage = error.responseText || errorMessage;
            }
        } else if (error.message) {
            errorMessage = error.message;
        }
        
        showAlert(errorMessage, 'danger');
    }
}

async function saveSlider() {
    const id = $('#sliderId').val();
    const method = id ? 'PUT' : 'POST';
    const url = id ? `/api/sliders/${id}` : '/api/sliders';
    const isEdit = Boolean(id);

    const titleInput = $('#sliderTitle').val().trim();
    const descriptionInput = $('#sliderDescription').val().trim();
    const linkInput = $('#sliderLink').val().trim();
    const orderInput = $('#sliderOrder').val().trim();

    const uploadedMedia = await uploadImageIfNeeded('#sliderImageFile', 'sliders');
    const imageUrl = ($('#sliderImage').val() || '').trim();
    const existingFileId = normaliseFileId($('#sliderImageFileId').val());

    if (!uploadedMedia && !imageUrl && !existingFileId) {
        showAlert('Please provide an image via URL or by uploading a file.', 'warning');
        return;
    }

    let orderValue = undefined;
    if (orderInput) {
        orderValue = parseInt(orderInput, 10);
        if (Number.isNaN(orderValue)) {
            showAlert('Order must be a number.', 'warning');
            return;
        }
    } else if (!isEdit) {
        orderValue = 0;
    }

    let titleValue = titleInput;
    if (!titleValue) {
        if (uploadedMedia?.originalName) {
            titleValue = uploadedMedia.originalName.replace(/\.[^/.]+$/, '').trim();
        } else if (!isEdit) {
            titleValue = 'Untitled Slider';
        }
    }

    let descriptionValue = descriptionInput;
    if (!descriptionValue && !isEdit) {
        descriptionValue = 'Slider description';
    }

    let linkValue = linkInput;
    if (!linkValue && !isEdit) {
        linkValue = '/';
    }

    const videoUrlValue = ($('#sliderVideoUrl').val() || '').trim();

    const payload = {
        isActive: $('#sliderActive').is(':checked')
    };

    if (titleValue !== undefined) payload.title = titleValue;
    if (descriptionValue !== undefined) payload.description = descriptionValue;
    if (linkValue !== undefined) payload.link = linkValue;
    if (orderValue !== undefined) payload.order = orderValue;
    
    // Add video URL if provided
    if (videoUrlValue) {
        payload.videoUrl = videoUrlValue;
    } else {
        payload.videoUrl = ''; // Clear video URL if empty
    }

    if (uploadedMedia) {
        payload.image = uploadedMedia.url;
        payload.imageFileId = uploadedMedia._id;
        $('#sliderImageFileId').val(uploadedMedia._id);
        $('#sliderImage').val(uploadedMedia.url);
        setImagePreview('#sliderImagePreview', uploadedMedia.url);
    } else {
        if (imageUrl) {
            payload.image = imageUrl;
        }
        if (existingFileId) {
            payload.imageFileId = existingFileId;
        }
    }

    try {
        await $.ajax({
            url,
            method,
            contentType: 'application/json',
            data: JSON.stringify(payload)
        });

        $('#sliderModal').modal('hide');
        showAlert(id ? 'Slider updated successfully' : 'Slider added successfully', 'success');
        loadSliders();
    } catch (error) {
        console.error('Error saving slider', error);
        
        // Extract and display the actual error message
        let errorMessage = 'Error saving slider';
        if (error.message) {
            errorMessage = error.message;
        } else if (error.responseJSON && error.responseJSON.message) {
            errorMessage = error.responseJSON.message;
        } else if (typeof error === 'string') {
            errorMessage = error;
        }
        
        showAlert(errorMessage, 'danger');
    }
}

async function uploadBannerFile(fileInputSelector) {
    const input = $(fileInputSelector)[0];
    if (!input || !input.files || !input.files.length) {
        return null;
    }

    const file = input.files[0];
    const maxSize = 100 * 1024 * 1024; // 100MB
    const fileSizeMB = (file.size / (1024 * 1024)).toFixed(2);
    
    // Client-side file size validation
    if (file.size > maxSize) {
        const errorMsg = `File size (${fileSizeMB} MB) exceeds maximum limit of 100 MB. Please compress the file or use a smaller one.`;
        throw new Error(errorMsg);
    }

    try {
        const formData = new FormData();
        formData.append('file', file);
        
        // Add optional form fields
        const titleValue = ($('#bannerTitle').val() || '').trim();
        const descriptionValue = ($('#bannerDescription').val() || '').trim();
        const linkValue = ($('#bannerLink').val() || '').trim();
        const positionValue = $('#bannerPosition').val() || 'middle';
        const sizeValue = $('#bannerSize').val() || 'medium';
        
        // Always send title and description, even if empty
        formData.append('title', titleValue || '');
        formData.append('description', descriptionValue || '');
        if (linkValue) formData.append('link', linkValue);
        if (positionValue) formData.append('position', positionValue);
        if (sizeValue) formData.append('size', sizeValue);
        formData.append('isActive', $('#bannerActive').is(':checked') ? 'true' : 'false');

        console.log('Uploading banner file:', {
            filename: file.name,
            size: file.size,
            sizeMB: fileSizeMB,
            type: file.type
        });

        const response = await $.ajax({
            url: '/api/banners/upload',
            method: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            headers: {
                'x-auth-token': localStorage.getItem('token')
            }
        });

        console.log('Banner uploaded successfully:', response);

        // Clear the file input
        input.value = '';
        return response;
    } catch (error) {
        console.error('Banner upload error:', error);
        
        let errorMessage = 'Error uploading banner file';
        if (error.responseJSON && error.responseJSON.message) {
            errorMessage = error.responseJSON.message;
        } else if (error.responseText) {
            try {
                const errorData = JSON.parse(error.responseText);
                errorMessage = errorData.message || errorMessage;
            } catch (e) {
                errorMessage = error.responseText || errorMessage;
            }
        } else if (error.message) {
            errorMessage = error.message;
        }
        
        throw new Error(errorMessage);
    }
}

async function saveBanner() {
    const id = $('#bannerId').val();
    
    // If editing existing banner, use the old flow
    if (id) {
        const method = 'PUT';
        const url = `/api/banners/${id}`;

        try {
            const uploadedMedia = await uploadImageIfNeeded('#bannerImageFile', 'banners');
            const imageUrl = ($('#bannerImage').val() || '').trim();
            const existingFileId = normaliseFileId($('#bannerImageFileId').val());
            const titleValue = ($('#bannerTitle').val() || '').trim();
            const descriptionValue = ($('#bannerDescription').val() || '').trim();
            const linkValue = ($('#bannerLink').val() || '').trim();
            const positionValue = $('#bannerPosition').val() || 'middle';
            const sizeValue = $('#bannerSize').val() || 'medium';

            console.log('Saving banner with position:', positionValue);

            const payload = {
                title: titleValue || '',
                description: descriptionValue || '',
                link: linkValue || '/',
                position: positionValue,
                size: sizeValue,
                isActive: $('#bannerActive').is(':checked')
            };
            
            // Add custom dimensions if size is custom
            if (sizeValue === 'custom') {
                const customWidth = parseInt($('#bannerCustomWidth').val(), 10);
                const customHeight = parseInt($('#bannerCustomHeight').val(), 10);
                if (customWidth && customWidth >= 100 && customWidth <= 5000) {
                    payload.customWidth = customWidth;
                }
                if (customHeight && customHeight >= 50 && customHeight <= 2000) {
                    payload.customHeight = customHeight;
                }
            }
            
            console.log('Banner payload:', payload);

            if (uploadedMedia) {
                payload.image = uploadedMedia.url;
                payload.imageFileId = uploadedMedia._id;
                $('#bannerImageFileId').val(uploadedMedia._id);
                $('#bannerImage').val(uploadedMedia.url);
                setImagePreview('#bannerImagePreview', uploadedMedia.url);
            } else {
                if (imageUrl) {
                    payload.image = imageUrl;
                }
                if (existingFileId) {
                    payload.imageFileId = existingFileId;
                }
            }

            await $.ajax({
                url,
                method,
                contentType: 'application/json',
                data: JSON.stringify(payload)
            });

            $('#bannerModal').modal('hide');
            showAlert('Banner updated successfully', 'success');
            loadBanners();
        } catch (error) {
            console.error('Error saving banner', error);
            console.error('Error details:', {
                status: error.status,
                statusText: error.statusText,
                responseText: error.responseText,
                responseJSON: error.responseJSON,
                message: error.message
            });
            
            let errorMessage = 'Error saving banner';
            if (error.responseJSON && error.responseJSON.message) {
                errorMessage = error.responseJSON.message;
            } else if (error.responseText) {
                try {
                    const errorData = JSON.parse(error.responseText);
                    errorMessage = errorData.message || errorMessage;
                } catch (e) {
                    errorMessage = error.responseText || errorMessage;
                }
            } else if (error.message) {
                errorMessage = error.message;
            } else if (typeof error === 'string') {
                errorMessage = error;
            }
            
            showAlert(errorMessage, 'danger');
        }
        return;
    }

    // For new banners, check if file is uploaded
    const fileInput = $('#bannerImageFile')[0];
    const hasFile = fileInput && fileInput.files && fileInput.files.length > 0;
    const imageUrl = ($('#bannerImage').val() || '').trim();

    // If file is uploaded, use new upload endpoint (which saves to MongoDB automatically)
    if (hasFile) {
        try {
            const uploadResult = await uploadBannerFile('#bannerImageFile');
            
            if (uploadResult && uploadResult.url) {
                // Update form with returned URL for preview
                $('#bannerImage').val(uploadResult.url);
                
                // Check if it's a video based on the type returned
                const isVideo = uploadResult.type === 'video' || uploadResult.url.includes('/video/upload');
                console.log('Banner upload result:', { url: uploadResult.url, type: uploadResult.type, isVideo });
                
                // Set preview - ensure it handles videos correctly
                setImagePreview('#bannerImagePreview', uploadResult.url);
                
                // Force a small delay to ensure DOM is updated
                setTimeout(() => {
                    const $preview = $('#bannerImagePreview');
                    if (isVideo && !$preview.find('video').length && !$preview.is('video')) {
                        // If video preview didn't render, force it
                        console.log('Forcing video preview render');
                        $preview.empty();
                        $preview.html(`<video src="${uploadResult.url}" controls preload="metadata" style="max-width: 100%; max-height: 100%; object-fit: contain; display: block;" alt="Video preview"></video>`);
                    }
                }, 100);
                
                // Banner is already saved by the upload endpoint
                $('#bannerModal').modal('hide');
                showAlert('Banner uploaded and saved successfully', 'success');
                loadBanners();
            }
        } catch (error) {
            console.error('Error uploading banner', error);
            
            let errorMessage = 'Error uploading banner';
            if (error.message) {
                errorMessage = error.message;
            } else if (error.responseJSON && error.responseJSON.message) {
                errorMessage = error.responseJSON.message;
            } else if (typeof error === 'string') {
                errorMessage = error;
            }
            
            showAlert(errorMessage, 'danger');
        }
        return;
    }

    // Fallback to old flow if no file uploaded (URL only)
    const method = 'POST';
    const url = '/api/banners';

    try {
        const titleValue = ($('#bannerTitle').val() || '').trim();
        const descriptionValue = ($('#bannerDescription').val() || '').trim();
        const linkValue = ($('#bannerLink').val() || '').trim();
        const positionValue = $('#bannerPosition').val() || 'middle';
        const sizeValue = $('#bannerSize').val() || 'medium';

        if (!imageUrl) {
            showAlert('Please provide an image/video via URL or by uploading a file.', 'warning');
            return;
        }

        const payload = {
            title: titleValue || '',
            description: descriptionValue || '',
            image: imageUrl,
            link: linkValue || '/',
            position: positionValue,
            size: sizeValue,
            isActive: $('#bannerActive').is(':checked')
        };
        
        // Add custom dimensions if size is custom
        if (sizeValue === 'custom') {
            const customWidth = parseInt($('#bannerCustomWidth').val(), 10);
            const customHeight = parseInt($('#bannerCustomHeight').val(), 10);
            if (customWidth && customWidth >= 100 && customWidth <= 5000) {
                payload.customWidth = customWidth;
            }
            if (customHeight && customHeight >= 50 && customHeight <= 2000) {
                payload.customHeight = customHeight;
            }
        }

        await $.ajax({
            url,
            method,
            contentType: 'application/json',
            data: JSON.stringify(payload)
        });

        $('#bannerModal').modal('hide');
        showAlert('Banner added successfully', 'success');
        loadBanners();
    } catch (error) {
        console.error('Error saving banner', error);
        
        let errorMessage = 'Error saving banner';
        if (error.message) {
            errorMessage = error.message;
        } else if (error.responseJSON && error.responseJSON.message) {
            errorMessage = error.responseJSON.message;
        } else if (typeof error === 'string') {
            errorMessage = error;
        }
        
        showAlert(errorMessage, 'danger');
    }
}

// LEGACY SECTIONS - NO LONGER USED
/*
async function saveSection() {
    const id = $('#sectionId').val();
    const method = id ? 'PUT' : 'POST';
    const url = id ? `/api/admin/sections/${id}` : '/api/admin/sections';

    try {
        let config = {};
        const configText = ($('#sectionConfig').val() || '').trim();
        if (configText) {
            try {
                config = JSON.parse(configText);
            } catch (e) {
                showAlert('Invalid JSON in config field', 'warning');
                return;
            }
        }

        const payload = {
            name: $('#sectionName').val(),
            type: $('#sectionType').val(),
            title: $('#sectionTitle').val() || undefined,
            subtitle: $('#sectionSubtitle').val() || undefined,
            description: $('#sectionDescription').val() || undefined,
            ordering: parseInt($('#sectionOrdering').val(), 10) || 0,
            isActive: $('#sectionActive').is(':checked'),
            isPublished: $('#sectionPublished').is(':checked'),
            config: config
        };

        await $.ajax({
            url,
            method,
            contentType: 'application/json',
            data: JSON.stringify(payload)
        });

        $('#sectionModal').modal('hide');
        showAlert(id ? 'Section updated successfully' : 'Section added successfully', 'success');
        loadSections();
        // Note: Main page will show new/updated sections on next page load or refresh
    } catch (error) {
        console.error('Error saving section', error);
        const message = error?.responseJSON?.message || 'Error saving section';
        showAlert(message, 'danger');
    }
}
*/

// Edit functions
async function editDepartment(id) {
    try {
        const dept = await $.get(`/api/departments/${id}`);
        $('#departmentId').val(dept._id);
        $('#departmentName').val(dept.name);
        $('#departmentDescription').val(dept.description);
        $('#departmentImage').val(dept.image || '');
        $('#departmentImageFileId').val(dept.imageUpload ? dept.imageUpload._id : '');
        $('#departmentActive').prop('checked', dept.isActive);
        setImagePreview('#departmentImagePreview', resolveItemImage(dept));

        $('#departmentModalTitle').text('Edit Department');
        $('#departmentModal').modal('show');
    } catch (error) {
        console.error('Error loading department', error);
        showAlert('Error loading department', 'danger');
    }
}

async function editCategory(id) {
    try {
        const cat = await $.get(`/api/categories/${id}`);
        $('#categoryId').val(cat._id);
        $('#categoryName').val(cat.name);
        $('#categoryDescription').val(cat.description || '');
        $('#categoryImage').val(cat.image || '');
        $('#categoryImageFileId').val(cat.imageUpload ? cat.imageUpload._id : '');
        $('#categoryOrdering').val(cat.ordering !== undefined ? cat.ordering : 0);
        $('#categoryFeatured').prop('checked', cat.isFeatured);
        $('#categoryActive').prop('checked', cat.isActive);
        setImagePreview('#categoryImagePreview', resolveItemImage(cat));

        await loadDepartmentsToSelect('#categoryDepartment', { includeInactive: true, selectedId: cat.department ? cat.department._id : '' });
        $('#categoryDepartment').val(cat.department ? cat.department._id : '');

        $('#categoryModalTitle').text('Edit Category');
        $('#categoryModal').modal('show');
    } catch (error) {
        console.error('Error loading category', error);
        showAlert('Error loading category', 'danger');
    }
}

async function editProduct(id) {
    try {
        const product = await $.get(`/api/products/${id}`);
        
        // Reset form first
        resetProductForm();
        
        // Debug log
        console.log('Editing product with data:', {
            id: product._id,
            name: product.name,
            brand: product.brand,
            category: product.category,
            department: product.department
        });
        
        // Populate form fields
        $('#productId').val(product._id);
        $('#productName').val(product.name);
        $('#productDescription').val(product.description);
        $('#productPrice').val(product.price);
        $('#productStock').val(product.stock);
        $('#productDiscount').val(product.discount || '');
        $('#productFeatured').prop('checked', product.isFeatured);
        $('#productTrending').prop('checked', product.isTrending);
        $('#productNewArrival').prop('checked', product.isNewArrival);
        $('#productBestSelling').prop('checked', product.isBestSelling);
        $('#productTopSelling').prop('checked', product.isTopSelling);
        $('#productActive').prop('checked', product.isActive !== false);
        
        // Set brand if exists
        if (product.brand) {
            $('#productBrand').val(product.brand._id || product.brand);
            console.log('Set product brand to:', product.brand._id || product.brand);
        }
        
        // Set image if exists
        if (product.image) {
            $('#productImage').val(product.image);
            setImagePreview('#productImagePreview', product.image);
        }
        
        // Load brands for the brand dropdown
        await loadFilterBrands();
        
        // Set category and department if they exist
        if (product.category) {
            // First load the department for this category
            const category = await $.get(`/api/categories/${product.category._id || product.category}`);
            if (category && category.department) {
                // Load departments and then set the selected one
                await loadDepartmentsToSelect('#productDepartment', { 
                    selected: category.department._id || category.department 
                });
                
                // Then load categories for the selected department
                await loadCategoriesToSelect('#productCategory', category.department._id || category.department, {
                    selected: product.category._id || product.category
                });
                
                // Load subcategories for the selected category
                if (product.subcategory) {
                    await loadSubcategoriesToSelect('#productSubcategory', product.category._id || product.category, {
                        selected: product.subcategory._id || product.subcategory
                    });
                }
            }
        } else if (product.department) {
            // If we only have department but no category
            await loadDepartmentsToSelect('#productDepartment', { 
                selected: product.department._id || product.department 
            });
        }
        
        // Populate sections dropdown
        $('#productSections').val([]);
        if (product.sections && Array.isArray(product.sections)) {
            $('#productSections').val(product.sections);
        }
        
        // Load brand sections
        const brandSectionId = product.brandSection ? (product.brandSection._id || product.brandSection) : '';
        await loadBrandSectionsToSelect('#productBrandSection', { selectedId: brandSectionId });
        
        // Initialize subcategory dropdown
        $('#productSubcategory').html('<option value="">Select Category First</option>');

        $('#productModalTitle').text('Edit Product');
        updateFieldRequirements();
        $('#productModal').modal('show');
    } catch (error) {
        console.error('Error loading product', error);
        showAlert('Error loading product', 'danger');
    }
}

async function editSlider(id) {
    try {
        const slider = await $.get(`/api/sliders/${id}`);
        $('#sliderId').val(slider._id);
        $('#sliderTitle').val(slider.title);
        $('#sliderDescription').val(slider.description || '');
        $('#sliderImage').val(slider.image || '');
        $('#sliderImageFileId').val(slider.imageUpload ? slider.imageUpload._id : '');
        $('#sliderVideoUrl').val(slider.videoUrl || '');
        $('#sliderLink').val(slider.link || '');
        $('#sliderOrder').val(slider.order || 0);
        $('#sliderActive').prop('checked', slider.isActive);
        
        // Check if slider has a video URL and show preview
        const videoUrl = slider.videoUrl || '';
        const videoType = slider.videoType || detectVideoTypeFromUrl(videoUrl);
        if (videoType === 'youtube' || videoType === 'vimeo') {
            showVideoEmbedPreview('#sliderImagePreview', videoUrl, videoType);
        } else {
            setImagePreview('#sliderImagePreview', resolveItemImage(slider));
        }

        $('#sliderModalTitle').text('Edit Slider');
        $('#sliderModal').modal('show');
    } catch (error) {
        console.error('Error loading slider', error);
        showAlert('Error loading slider', 'danger');
    }
}

async function editBanner(id) {
    try {
        const banner = await $.get(`/api/banners/detail/${id}`);
        
        // Load dynamic positions first, passing the banner's position to preserve it
        await loadBannerPositions(banner.position || 'middle');
        
        $('#bannerId').val(banner._id);
        $('#bannerTitle').val(banner.title);
        $('#bannerDescription').val(banner.description || '');
        $('#bannerImage').val(banner.image || '');
        $('#bannerImageFileId').val(banner.imageUpload ? banner.imageUpload._id : '');
        $('#bannerLink').val(banner.link || '');
        
        // Set size and preserve custom dimensions
        $('#bannerSize').val(banner.size || 'medium');
        $('#bannerActive').prop('checked', banner.isActive);
        
        // Always load custom dimensions if they exist, even if size is not currently 'custom'
        // This preserves the values when user changes size temporarily
        // Use !== undefined to handle 0 values correctly
        if (banner.customWidth !== undefined && banner.customWidth !== null) {
            $('#bannerCustomWidth').val(banner.customWidth);
        } else {
            $('#bannerCustomWidth').val('');
        }
        if (banner.customHeight !== undefined && banner.customHeight !== null) {
            $('#bannerCustomHeight').val(banner.customHeight);
        } else {
            $('#bannerCustomHeight').val('');
        }
        
        // Show/hide custom dimensions based on current size
        if (banner.size === 'custom') {
            $('#customBannerDimensions').show();
        } else {
            $('#customBannerDimensions').hide();
        }
        
        // Check if banner is a YouTube/Vimeo video and show embed preview
        const imageUrl = resolveItemImage(banner) || banner.image || '';
        const videoType = banner.video_type || detectVideoTypeFromUrl(imageUrl);
        if (videoType === 'youtube' || videoType === 'vimeo') {
            showVideoEmbedPreview('#bannerImagePreview', imageUrl, videoType);
        } else {
            setImagePreview('#bannerImagePreview', imageUrl);
        }

        $('#bannerModalTitle').text('Edit Banner');
        $('#bannerModal').modal('show');
    } catch (error) {
        console.error('Error loading banner', error);
        showAlert('Error loading banner', 'danger');
    }
}

// LEGACY SECTIONS - NO LONGER USED
/*
async function editSection(id) {
    try {
        console.log('Loading section for edit:', id);
        const section = await $.get(`/api/admin/sections/${id}`);
        console.log('Section loaded:', section);
        
        if (!section) {
            showAlert('Section not found', 'danger');
            return;
        }

        // Reset form first to clear any previous values
        resetSectionForm();
        
        // Populate form fields
        $('#sectionId').val(section._id || '');
        $('#sectionName').val(section.name || '');
        $('#sectionType').val(section.type || '');
        $('#sectionTitle').val(section.title || '');
        $('#sectionSubtitle').val(section.subtitle || '');
        $('#sectionDescription').val(section.description || '');
        $('#sectionOrdering').val(section.ordering !== undefined ? section.ordering : 0);
        $('#sectionActive').prop('checked', section.isActive !== undefined ? section.isActive : true);
        $('#sectionPublished').prop('checked', section.isPublished !== undefined ? section.isPublished : false);
        
        // Handle config - ensure it's valid JSON
        let configValue = '{}';
        if (section.config) {
            if (typeof section.config === 'string') {
                configValue = section.config;
            } else {
                configValue = JSON.stringify(section.config, null, 2);
            }
        }
        $('#sectionConfig').val(configValue);

        $('#sectionModalTitle').text('Edit Section');
        $('#sectionModal').modal('show');
        
        console.log('Section form populated successfully');
    } catch (error) {
        console.error('Error loading section', error);
        const errorMsg = error?.responseJSON?.message || error?.message || 'Error loading section';
        showAlert(errorMsg, 'danger');
    }
}
*/

function editUser(id) {
    // This would be implemented in a real application
    showAlert('Edit user functionality not implemented', 'info');
}


// Delete functions
function deleteDepartment(id) {
    if (confirm('Are you sure you want to delete this department?')) {
        $.ajax({
            url: `/api/departments/${id}`,
            method: 'DELETE',
            success: function() {
                showAlert('Department deleted successfully', 'success');
                loadAdminDepartments();
                loadDashboardData();
            },
            error: function() {
                showAlert('Error deleting department', 'danger');
            }
        });
    }
}

function deleteCategory(id) {
    if (confirm('Are you sure you want to delete this category?')) {
        $.ajax({
            url: `/api/categories/${id}`,
            method: 'DELETE',
            success: function() {
                showAlert('Category deleted successfully', 'success');
                loadCategories();
                loadDashboardData();
            },
            error: function() {
                showAlert('Error deleting category', 'danger');
            }
        });
    }
}

function deleteProduct(id) {
    if (confirm('Are you sure you want to delete this product?')) {
        $.ajax({
            url: `/api/products/${id}`,
            method: 'DELETE',
            success: function() {
                showAlert('Product deleted successfully', 'success');
                loadProducts(1);
                loadDashboardData();
            },
            error: function() {
                showAlert('Error deleting product', 'danger');
            }
        });
    }
}

function deleteSlider(id) {
    if (confirm('Are you sure you want to delete this slider?')) {
        $.ajax({
            url: `/api/sliders/${id}`,
            method: 'DELETE',
            success: function() {
                showAlert('Slider deleted successfully', 'success');
                loadSliders();
            },
            error: function() {
                showAlert('Error deleting slider', 'danger');
            }
        });
    }
}

function deleteBanner(id) {
    if (confirm('Are you sure you want to delete this banner?')) {
        $.ajax({
            url: `/api/banners/${id}`,
            method: 'DELETE',
            success: function() {
                showAlert('Banner deleted successfully', 'success');
                loadBanners();
            },
            error: function() {
                showAlert('Error deleting banner', 'danger');
            }
        });
    }
}

// Brand functions
function loadBrands() {
    console.log('Loading brands from /api/admin/brands...');
    console.log('Auth token present:', !!localStorage.getItem('token'));
    
    $.ajax({
        url: '/api/admin/brands',
        method: 'GET',
        headers: {
            'x-auth-token': localStorage.getItem('token') || ''
        }
    })
        .done(function(response) {
            console.log('✅ Brands API response received:', response);
            let html = '';
            
            // Handle different response formats
            const brands = Array.isArray(response) ? response : (response.brands || response.data || []);
            
            console.log(`✅ Processed ${brands.length} brands from response`);
            
            if (!Array.isArray(brands)) {
                console.error('❌ Invalid brands response format:', response);
                showAlert('Error: Invalid response format from server', 'danger');
                html = '<tr><td colspan="7" class="text-center text-danger">Error loading brands. Please check console for details.</td></tr>';
            } else if (brands.length === 0) {
                console.log('⚠️ No brands found in database');
                html = '<tr><td colspan="7" class="text-center text-muted">No brands found. Click "Add Brand" to add your first brand logo.</td></tr>';
            } else {
                console.log(`✅ Rendering ${brands.length} brands in table`);
                brands.forEach(function(brand) {
                    console.log('Processing brand:', {
                        id: brand._id,
                        name: brand.name,
                        image: brand.image,
                        hasImageUpload: !!brand.imageUpload
                    });
                    let imageUrl = resolveItemImage(brand) || brand.image || '';
                    
                    // If no image URL, use placeholder
                    if (!imageUrl || imageUrl === 'null' || imageUrl === 'undefined') {
                        imageUrl = IMAGE_PLACEHOLDER;
                    }
                    
                    console.log('  → Resolved image URL:', imageUrl);
                    // Format discount display
                    let discountDisplay = '-';
                    if (brand.discount && brand.discount > 0) {
                        const discountText = brand.discountText || `${brand.discount}% OFF`;
                        discountDisplay = `<span class="badge bg-danger">${discountText}</span>`;
                    }
                    
                    html += `
                        <tr>
                            <td>${brand.order || 0}</td>
                            <td><img src="${imageUrl}" alt="${brand.name}" style="max-width: 80px; max-height: 50px; object-fit: contain;" onerror="console.error('Failed to load brand image:', '${imageUrl}'); this.src='${IMAGE_PLACEHOLDER}';"></td>
                            <td>${brand.name}</td>
                            <td>${discountDisplay}</td>
                            <td>${brand.link ? `<a href="${brand.link}" target="_blank">${brand.link}</a>` : '-'}</td>
                            <td><span class="badge ${brand.isActive ? 'bg-success' : 'bg-secondary'}">${brand.isActive ? 'Active' : 'Inactive'}</span></td>
                            <td>
                                <button class="btn btn-sm btn-primary edit-brand" data-id="${brand._id}">
                                    <i class="fas fa-edit"></i>
                                </button>
                                <button class="btn btn-sm btn-danger delete-brand" data-id="${brand._id}">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </td>
                        </tr>
                    `;
                });
            }
            
            $('#brands-table').html(html);
            
            // Attach event handlers
            $('.edit-brand').click(function() {
                const id = $(this).data('id');
                editBrand(id);
            });
            
            $('.delete-brand').click(function() {
                const id = $(this).data('id');
                deleteBrand(id);
            });
        })
        .fail(function(error) {
            console.error('❌ Error loading brands:', {
                status: error.status,
                statusText: error.statusText,
                responseText: error.responseText,
                responseJSON: error.responseJSON
            });
            
            let errorMessage = 'Error loading brands';
            if (error.responseJSON && error.responseJSON.message) {
                errorMessage = error.responseJSON.message;
            } else if (error.status === 401) {
                errorMessage = 'Authentication required. Please login again.';
                console.error('❌ Authentication failed - redirecting to login');
                window.location.href = '/login.html';
                return;
            } else if (error.status === 403) {
                errorMessage = 'Access denied. Admin privileges required.';
            } else if (error.status === 404) {
                errorMessage = 'Brands endpoint not found. Please check server configuration.';
            } else if (error.status === 0) {
                errorMessage = 'Network error. Please check if the server is running.';
            } else if (error.status >= 500) {
                errorMessage = 'Server error. Please check server logs.';
            }
            
            console.error('❌ Final error message:', errorMessage);
            showAlert(errorMessage, 'danger');
            $('#brands-table').html('<tr><td colspan="6" class="text-center text-danger">' + errorMessage + '</td></tr>');
        });
}

function editBrand(id) {
    $.get(`/api/admin/brands/${id}`)
        .done(function(brand) {
            $('#brandId').val(brand._id);
            $('#brandName').val(brand.name);
            $('#brandAlt').val(brand.alt || '');
            $('#brandLink').val(brand.link || '');
            $('#brandOrder').val(brand.order || 0);
            $('#brandDiscount').val(brand.discount || 0);
            $('#brandDiscountText').val(brand.discountText || '');
            $('#brandActive').prop('checked', brand.isActive !== false);
            $('#brandImage').val(brand.image || '');
            $('#brandImageFileId').val(brand.imageUpload || '');
            
            const imageUrl = resolveItemImage(brand);
            if (imageUrl) {
                setImagePreview('#brandImagePreview', imageUrl);
            } else {
                setImagePreview('#brandImagePreview', null);
            }
            
            $('#brandModalTitle').text('Edit Brand');
            $('#brandModal').modal('show');
        })
        .fail(function() {
            showAlert('Error loading brand', 'danger');
        });
}

async function saveBrand() {
    const id = $('#brandId').val();
    const method = id ? 'PUT' : 'POST';
    const url = id ? `/api/admin/brands/${id}` : '/api/admin/brands';

    try {
        // Validate required fields
        const name = $('#brandName').val()?.trim();
        if (!name) {
            showAlert('Brand name is required', 'warning');
            return;
        }

        const uploadedMedia = await uploadImageIfNeeded('#brandImageFile', 'brands');
        const imageUrl = ($('#brandImage').val() || '').trim();
        const existingFileId = normaliseFileId($('#brandImageFileId').val());

        const discountValue = parseInt($('#brandDiscount').val() || '0', 10);
        const discountTextValue = $('#brandDiscountText').val()?.trim() || '';
        
        const payload = {
            name: name,
            alt: $('#brandAlt').val()?.trim() || undefined,
            link: $('#brandLink').val()?.trim() || undefined,
            order: parseInt($('#brandOrder').val() || '0', 10),
            discount: discountValue || 0,
            discountText: discountTextValue || '',
            isActive: $('#brandActive').is(':checked')
        };

        // Image is required for new brands
        if (!id && !uploadedMedia && !imageUrl && !existingFileId) {
            showAlert('Please provide an image via URL or by uploading a file.', 'warning');
            return;
        }

        if (uploadedMedia) {
            payload.image = uploadedMedia.url;
            payload.imageFileId = uploadedMedia._id;
            $('#brandImageFileId').val(uploadedMedia._id);
            $('#brandImage').val(uploadedMedia.url);
            setImagePreview('#brandImagePreview', uploadedMedia.url);
        } else {
            if (imageUrl) {
                payload.image = imageUrl;
            }
            // Only include imageFileId if it's a valid non-empty value
            if (existingFileId && existingFileId !== '' && existingFileId !== 'null' && existingFileId !== 'undefined') {
                payload.imageFileId = existingFileId;
            } else if (id) {
                // When editing, if no fileId is provided, don't send it (or send null to clear it)
                // This prevents sending empty string which causes ObjectId cast error
                payload.imageFileId = null;
            }
        }

        const response = await $.ajax({
            url,
            method,
            contentType: 'application/json',
            data: JSON.stringify(payload)
        });

        console.log('Brand save response:', response);
        console.log('Brand image in response:', response.image);
        console.log('Brand imageUpload in response:', response.imageUpload);

        // Verify the brand was saved with image
        if (!response.image && !response.imageUpload) {
            console.warn('Warning: Brand saved but no image found in response');
        }

        $('#brandModal').modal('hide');
        showAlert(id ? 'Brand updated successfully' : 'Brand added successfully', 'success');
        
        // Reload brands list after a short delay to ensure database is updated
        setTimeout(function() {
            console.log('Reloading brands list...');
            loadBrands();
        }, 500);
    } catch (error) {
        console.error('Error saving brand', error);
        
        let errorMessage = 'Error saving brand';
        if (error.responseJSON && error.responseJSON.message) {
            errorMessage = error.responseJSON.message;
        } else if (error.responseText) {
            try {
                const errorData = JSON.parse(error.responseText);
                errorMessage = errorData.message || errorMessage;
            } catch (e) {
                errorMessage = error.responseText || errorMessage;
            }
        } else if (error.message) {
            errorMessage = error.message;
        }
        
        showAlert(errorMessage, 'danger');
    }
}

function deleteBrand(id) {
    if (confirm('Are you sure you want to delete this brand?')) {
        $.ajax({
            url: `/api/admin/brands/${id}`,
            method: 'DELETE',
            success: function() {
                showAlert('Brand deleted successfully', 'success');
                loadBrands();
            },
            error: function() {
                showAlert('Error deleting brand', 'danger');
            }
        });
    }
}

// Video Banner functions
function loadVideoBanners() {
    $.get('/api/admin/video-banners')
        .done(function(response) {
            console.log('Video banners API response:', response);
            
            // Handle different response formats
            const videoBanners = Array.isArray(response) ? response : (response.videoBanners || response.data || []);
            
            console.log('Processed video banners array:', videoBanners);
            
            let html = '';
            
            if (!Array.isArray(videoBanners) || videoBanners.length === 0) {
                console.log('No video banners found or invalid response format');
                html = '<tr><td colspan="7" class="text-center text-muted">No video banners found. Click "Add Video Banner" to add your first video banner.</td></tr>';
            } else {
                videoBanners.forEach(function(videoBanner) {
                    const videoUrl = videoBanner.videoUpload?.url || videoBanner.videoUrl || 'N/A';
                    const posterUrl = resolveItemImage(videoBanner) || videoBanner.posterImage || IMAGE_PLACEHOLDER;
                    
                    html += `
                        <tr>
                            <td>${videoBanner.order || 0}</td>
                            <td>${videoBanner.title}</td>
                            <td><span class="badge bg-info">${videoBanner.videoType || 'youtube'}</span></td>
                            <td><small>${videoUrl.length > 40 ? videoUrl.substring(0, 40) + '...' : videoUrl}</small></td>
                            <td><img src="${posterUrl}" alt="Poster" style="max-width: 60px; max-height: 40px; object-fit: cover;" onerror="this.src='${IMAGE_PLACEHOLDER}';"></td>
                            <td><span class="badge ${videoBanner.isActive ? 'bg-success' : 'bg-secondary'}">${videoBanner.isActive ? 'Active' : 'Inactive'}</span></td>
                            <td>
                                <button class="btn btn-sm btn-primary edit-video-banner" data-id="${videoBanner._id}">
                                    <i class="fas fa-edit"></i>
                                </button>
                                <button class="btn btn-sm btn-danger delete-video-banner" data-id="${videoBanner._id}">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </td>
                        </tr>
                    `;
                });
            }
            
            $('#video-banners-table').html(html);
            
            // Attach event handlers
            $('.edit-video-banner').click(function() {
                const id = $(this).data('id');
                editVideoBanner(id);
            });
            
            $('.delete-video-banner').click(function() {
                const id = $(this).data('id');
                deleteVideoBanner(id);
            });
        })
        .fail(function(error) {
            console.error('Error loading video banners:', error);
            let errorMessage = 'Error loading video banners';
            if (error.responseJSON && error.responseJSON.message) {
                errorMessage = error.responseJSON.message;
            }
            showAlert(errorMessage, 'danger');
            $('#video-banners-table').html('<tr><td colspan="7" class="text-center text-danger">' + errorMessage + '</td></tr>');
        });
}

async function saveVideoBanner() {
    const id = $('#videoBannerId').val();
    const method = id ? 'PUT' : 'POST';
    const url = id ? `/api/admin/video-banners/${id}` : '/api/admin/video-banners';

    try {
        const title = $('#videoBannerTitle').val()?.trim();
        if (!title) {
            showAlert('Title is required', 'warning');
            return;
        }

        const videoType = $('#videoBannerType').val();
        const videoUrl = $('#videoBannerUrl').val()?.trim();
        const videoFileId = normaliseFileId($('#videoBannerFileId').val());

        if (!videoUrl && !videoFileId && videoType !== 'file') {
            showAlert('Video URL or video file is required', 'warning');
            return;
        }

        // Upload poster image if needed
        const uploadedPoster = await uploadImageIfNeeded('#videoBannerPosterFile', 'video-posters');
        const posterUrl = ($('#videoBannerPoster').val() || '').trim();
        const posterFileId = normaliseFileId($('#videoBannerPosterFileId').val());

        const payload = {
            title: title,
            description: $('#videoBannerDescription').val()?.trim() || undefined,
            videoUrl: videoUrl || undefined,
            videoFileId: videoFileId || undefined,
            videoType: videoType,
            posterImage: posterUrl || undefined,
            posterImageFileId: uploadedPoster?._id || posterFileId || undefined,
            link: $('#videoBannerLink').val()?.trim() || undefined,
            buttonText: $('#videoBannerButtonText').val()?.trim() || undefined,
            buttonLink: $('#videoBannerButtonLink').val()?.trim() || undefined,
            order: parseInt($('#videoBannerOrder').val() || '0', 10),
            autoplay: $('#videoBannerAutoplay').is(':checked'),
            loop: $('#videoBannerLoop').is(':checked'),
            muted: $('#videoBannerMuted').is(':checked'),
            controls: $('#videoBannerControls').is(':checked'),
            isActive: $('#videoBannerActive').is(':checked')
        };

        const response = await $.ajax({
            url,
            method,
            contentType: 'application/json',
            data: JSON.stringify(payload)
        });

        $('#videoBannerModal').modal('hide');
        
        const successMessage = id ? 'Video banner updated successfully' : 'Video banner added successfully';
        const infoMessage = 'To show this video on the homepage, go to "Homepage Sections" and add a section with type "Video Banner".';
        
        showAlert(successMessage, 'success');
        
        // Show additional info after a delay
        setTimeout(function() {
            showAlert(infoMessage, 'info');
        }, 2000);
        
        setTimeout(function() {
            loadVideoBanners();
        }, 500);
    } catch (error) {
        console.error('Error saving video banner', error);
        let errorMessage = 'Error saving video banner';
        if (error.responseJSON && error.responseJSON.message) {
            errorMessage = error.responseJSON.message;
        }
        showAlert(errorMessage, 'danger');
    }
}

function editVideoBanner(id) {
    $.get(`/api/admin/video-banners/${id}`)
        .done(function(videoBanner) {
            $('#videoBannerId').val(videoBanner._id);
            $('#videoBannerTitle').val(videoBanner.title);
            $('#videoBannerDescription').val(videoBanner.description || '');
            $('#videoBannerType').val(videoBanner.videoType || 'youtube');
            $('#videoBannerUrl').val(videoBanner.videoUrl || '');
            $('#videoBannerFileId').val(videoBanner.videoUpload?._id || '');
            $('#videoBannerPoster').val(videoBanner.posterImage || '');
            $('#videoBannerPosterFileId').val(videoBanner.posterImageUpload?._id || '');
            $('#videoBannerLink').val(videoBanner.link || '');
            $('#videoBannerButtonText').val(videoBanner.buttonText || '');
            $('#videoBannerButtonLink').val(videoBanner.buttonLink || '');
            $('#videoBannerOrder').val(videoBanner.order || 0);
            $('#videoBannerAutoplay').prop('checked', videoBanner.autoplay !== false);
            $('#videoBannerLoop').prop('checked', videoBanner.loop !== false);
            $('#videoBannerMuted').prop('checked', videoBanner.muted !== false);
            $('#videoBannerControls').prop('checked', videoBanner.controls === true);
            $('#videoBannerActive').prop('checked', videoBanner.isActive !== false);
            
            const posterUrl = resolveItemImage(videoBanner) || videoBanner.posterImage;
            if (posterUrl) {
                setImagePreview('#videoBannerPosterPreview', posterUrl);
            }
            
            const videoType = videoBanner.videoType || 'youtube';
            if (videoType === 'file') {
                $('#videoBannerFileUploadDiv').show();
                $('#videoBannerUrl').prop('required', false);
            } else {
                $('#videoBannerFileUploadDiv').hide();
                $('#videoBannerUrl').prop('required', true);
            }
            
            $('#videoBannerModalTitle').text('Edit Video Banner');
            $('#videoBannerModal').modal('show');
        })
        .fail(function(error) {
            console.error('Error loading video banner:', error);
            showAlert('Error loading video banner', 'danger');
        });
}

function deleteVideoBanner(id) {
    if (!confirm('Are you sure you want to delete this video banner?')) {
        return;
    }
    
    $.ajax({
        url: `/api/admin/video-banners/${id}`,
        method: 'DELETE'
    })
        .done(function() {
            showAlert('Video banner deleted successfully', 'success');
            loadVideoBanners();
        })
        .fail(function(error) {
            console.error('Error deleting video banner:', error);
            showAlert('Error deleting video banner', 'danger');
        });
}

function resetVideoBannerForm() {
    $('#videoBannerForm')[0].reset();
    $('#videoBannerId').val('');
    $('#videoBannerType').val('youtube');
    $('#videoBannerOrder').val('0');
    $('#videoBannerAutoplay').prop('checked', true);
    $('#videoBannerLoop').prop('checked', true);
    $('#videoBannerMuted').prop('checked', true);
    $('#videoBannerControls').prop('checked', false);
    $('#videoBannerActive').prop('checked', true);
    $('#videoBannerFileId').val('');
    $('#videoBannerPosterFileId').val('');
    $('#videoBannerFileUploadDiv').hide();
    $('#videoBannerUrl').prop('required', true);
    setImagePreview('#videoBannerPosterPreview', null);
}

function resetBrandForm() {
    $('#brandForm')[0].reset();
    $('#brandId').val('');
    $('#brandOrder').val('0');
    $('#brandDiscount').val('0');
    $('#brandDiscountText').val('');
    $('#brandActive').prop('checked', true);
    $('#brandImageFileId').val('');
    setImagePreview('#brandImagePreview', null);
}

// LEGACY SECTIONS - NO LONGER USED
/*
function deleteSection(id) {
    if (confirm('Are you sure you want to delete this section? It will be removed from the main page.')) {
        $.ajax({
            url: `/api/admin/sections/${id}`,
            method: 'DELETE',
            success: function() {
                showAlert('Section deleted successfully. The main page will be updated on refresh.', 'success');
                loadSections();
                // Note: Main page will automatically reflect the deletion on next page load or refresh
            },
            error: function() {
                showAlert('Error deleting section', 'danger');
            }
        });
    }
}
*/

// Homepage Sections Functions
function loadHomepageSections() {
    $.get('/api/homepage-sections')
        .done(function(sections) {
            if (!sections || sections.length === 0) {
                $('#homepage-sections-table').html('<tr><td colspan="7" class="text-center">No homepage sections found</td></tr>');
                $('#homepage-sections-empty').show();
                return;
            }
            
            $('#homepage-sections-empty').hide();
            let html = '';
            
            sections.forEach(function(section) {
                const sectionId = section._id || section.id;
                const typeLabel = getSectionTypeLabel(section.type);
                const typeBadge = getSectionTypeBadge(section.type);
                
                html += `
                    <tr data-section-id="${sectionId}" data-ordering="${section.ordering}">
                        <td class="text-center">${section.ordering}</td>
                        <td><strong>${section.name || 'Unnamed'}</strong></td>
                        <td><span class="badge ${typeBadge}">${typeLabel}</span></td>
                        <td>${section.title || '-'}</td>
                        <td class="text-center">
                            <span class="badge ${section.isActive ? 'bg-success' : 'bg-danger'}">
                                ${section.isActive ? 'Active' : 'Inactive'}
                            </span>
                        </td>
                        <td class="text-center">
                            <span class="badge ${section.isPublished ? 'bg-primary' : 'bg-secondary'}">
                                ${section.isPublished ? 'Published' : 'Draft'}
                            </span>
                        </td>
                        <td>
                            <button class="btn btn-sm btn-primary btn-action edit-homepage-section" data-id="${sectionId}" title="Edit">
                                <i class="fas fa-edit"></i>
                            </button>
                            <button class="btn btn-sm btn-danger btn-action delete-homepage-section" data-id="${sectionId}" title="Delete">
                                <i class="fas fa-trash"></i>
                            </button>
                        </td>
                    </tr>
                `;
            });
            
            $('#homepage-sections-table').html(html);
            
            // Add event handlers
            $('.edit-homepage-section').click(function() {
                const id = $(this).data('id');
                editHomepageSection(id);
            });
            
            $('.delete-homepage-section').click(function() {
                const id = $(this).data('id');
                deleteHomepageSection(id);
            });
        })
        .fail(function(error) {
            console.error('Error loading homepage sections:', error);
            const errorMsg = error?.responseJSON?.message || 'Error loading homepage sections';
            showAlert(errorMsg, 'danger');
            $('#homepage-sections-table').html('<tr><td colspan="7" class="text-center text-danger">Error loading sections</td></tr>');
        });
}

function getSectionTypeLabel(type) {
    const labels = {
        'heroSlider': 'Hero Slider',
        'scrollingText': 'Scrolling Text',
        'categoryFeatured': 'Category Featured',
        'categoryGrid': 'Category Grid',
        'categoryCircles': 'Category Circles',
        'departmentGrid': 'Department Grid',
        'productTabs': 'Product Tabs',
        'productCarousel': 'Product Carousel',
        'bannerFullWidth': 'Full-Width Banner',
        'videoBanner': 'Video Banner',
        'collectionLinks': 'Collection Links',
        'newsletterSocial': 'Newsletter & Social',
        'brandGrid': 'Brand Grid',
        'customHTML': 'Custom HTML'
    };
    return labels[type] || type;
}

function getSectionTypeBadge(type) {
    const badges = {
        'heroSlider': 'bg-primary',
        'scrollingText': 'bg-info',
        'categoryFeatured': 'bg-success',
        'categoryGrid': 'bg-success',
        'categoryCircles': 'bg-success',
        'departmentGrid': 'bg-info',
        'productTabs': 'bg-warning',
        'productCarousel': 'bg-warning',
        'bannerFullWidth': 'bg-secondary',
        'videoBanner': 'bg-danger',
        'collectionLinks': 'bg-info',
        'newsletterSocial': 'bg-dark',
        'brandGrid': 'bg-success',
        'customHTML': 'bg-dark'
    };
    return badges[type] || 'bg-secondary';
}

function resetHomepageSectionForm() {
    $('#homepageSectionForm')[0].reset();
    $('#homepageSectionId').val('');
    $('#homepageSectionOrdering').val('0');
    $('#homepageSectionActive').prop('checked', true);
    $('#homepageSectionPublished').prop('checked', false);
    $('#homepageSectionDisplayDesktop').prop('checked', true);
    // Clear brand section brands array
    window.brandSectionBrands = [];
    $('#homepageSectionDisplayTablet').prop('checked', true);
    $('#homepageSectionDisplayMobile').prop('checked', true);
    $('#homepageSectionConfigArea').html('');
    // Clear banner image fields
    $('#configBannerImageUrl').val('');
    $('#configBannerImageFile').val('');
    $('#configBannerImagePreview').html('<span class="text-muted">No image selected</span>');
    window.bannerImageMediaId = {};
    // DON'T clear brand section brands array here - it will be loaded from config when needed
    // Only clear when explicitly resetting the form for a NEW section
}

function loadHomepageSectionConfig(sectionType) {
    let configHtml = '';
    
    switch(sectionType) {
        case 'heroSlider':
            configHtml = `
                <div class="card border-primary">
                    <div class="card-header bg-primary text-white">
                        <strong>Hero Slider Configuration</strong>
                    </div>
                    <div class="card-body">
                        <div class="mb-3">
                            <label class="form-label">Select Sliders (will be loaded from Sliders section)</label>
                            <div id="heroSliderList" class="border rounded p-3">
                                <p class="text-muted">Sliders will be listed here after section is created</p>
                            </div>
                        </div>
                        <div class="row g-3">
                            <div class="col-md-6">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" id="configAutoplay" checked>
                                    <label class="form-check-label" for="configAutoplay">Auto-play</label>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Auto-play Speed (ms)</label>
                                <input type="number" class="form-control" id="configAutoplaySpeed" value="3000" min="1000" step="1000">
                                <div class="form-text">Default: 3000ms (3 seconds)</div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" id="configShowArrows" checked>
                                    <label class="form-check-label" for="configShowArrows">Show Navigation Arrows</label>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" id="configShowDots" checked>
                                    <label class="form-check-label" for="configShowDots">Show Dots Indicator</label>
                                </div>
                            </div>
                        </div>
                        <div class="mb-3 mt-3">
                            <label class="form-label fw-bold">Location <span class="text-danger">*</span></label>
                            <select class="form-select" id="configHeroSliderLocation">
                                <option value="top">Top (Before all sections)</option>
                                <option value="bottom">Bottom (After all sections)</option>
                            </select>
                            <div class="form-text">Hero slider will be placed based on location</div>
                        </div>
                    </div>
                </div>
            `;
            setTimeout(() => {
                const existingLocation = $('#configHeroSliderLocation').val() || 'top';
                loadSectionsForLocationHeroSlider(existingLocation);
            }, 100);
            break;
            
        case 'scrollingText':
            configHtml = `
                <div class="card border-info">
                    <div class="card-header bg-info text-white">
                        <strong>Announcement Bar Configuration</strong>
                    </div>
                    <div class="card-body">
                        <div class="mb-3">
                            <label class="form-label">Text Items (one per line)</label>
                            <textarea class="form-control" id="configTextItems" rows="3" placeholder="11.11 Sale is Live&#10;Get Upto 50% OFF&#10;Free Shipping on Orders Above Rs. 2000"></textarea>
                        </div>
                        <div class="row g-3">
                            <div class="col-md-4">
                                <label class="form-label">Scroll Speed (seconds)</label>
                                <input type="number" class="form-control" id="configScrollSpeed" value="20" min="5" max="30">
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">Background Color</label>
                                <input type="color" class="form-control form-control-color" id="configBgColor" value="#c42525">
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">Text Color</label>
                                <input type="color" class="form-control form-control-color" id="configTextColor" value="#ffffff">
                            </div>
                        </div>
                        <div class="mb-3 mt-3">
                            <label class="form-label fw-bold">Location <span class="text-danger">*</span></label>
                            <select class="form-select" id="configAnnouncementLocation">
                                <option value="top">Top (Before all sections)</option>
                                <option value="bottom">Bottom (After all sections)</option>
                            </select>
                            <div class="form-text">Announcement bar will be placed based on location</div>
                        </div>
                    </div>
                </div>
            `;
            setTimeout(() => {
                const existingLocation = $('#configAnnouncementLocation').val() || 'top';
                loadSectionsForLocationAnnouncement(existingLocation);
            }, 100);
            break;
            
        case 'categoryFeatured':
        case 'categoryGrid':
            configHtml = `
                <div class="card border-success">
                    <div class="card-header bg-success text-white">
                        <strong>Category Grid Configuration</strong>
                    </div>
                    <div class="card-body">
                        <div class="mb-3">
                            <label class="form-label">Select Categories (will be loaded from Categories section)</label>
                            <div id="categoryList" class="border rounded p-3">
                                <p class="text-muted">Categories will be listed here after section is created</p>
                            </div>
                        </div>
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label">Grid Columns</label>
                                <select class="form-select" id="configGridColumns">
                                    <option value="2">2 Columns</option>
                                    <option value="3">3 Columns</option>
                                    <option value="4" selected>4 Columns</option>
                                    <option value="6">6 Columns</option>
                                    <option value="8">8 Columns</option>
                                </select>
                            </div>
                            <div class="col-md-6">
                                <div class="form-check mt-4">
                                    <input class="form-check-input" type="checkbox" id="configShowTitle" checked>
                                    <label class="form-check-label" for="configShowTitle">Show Category Titles</label>
                                </div>
                            </div>
                        </div>
                        <div class="mb-3 mt-3">
                            <label class="form-label fw-bold">Location <span class="text-danger">*</span></label>
                            <select class="form-select" id="configCategoryGridLocation">
                                <option value="top">Top (Before all sections)</option>
                                <option value="bottom">Bottom (After all sections)</option>
                            </select>
                            <div class="form-text">Section will be placed based on location</div>
                        </div>
                    </div>
                </div>
            `;
            setTimeout(() => {
                const existingLocation = $('#configCategoryGridLocation').val() || 'bottom';
                loadSectionsForLocationGeneric('#configCategoryGridLocation', existingLocation);
            }, 100);
            break;
            
        case 'categoryCircles':
            configHtml = `
                <div class="card border-success">
                    <div class="card-header bg-success text-white">
                        <strong>Category Circles Configuration</strong>
                    </div>
                    <div class="card-body">
                        <div class="mb-3">
                            <label class="form-label">Select Categories to Display (will be loaded from Categories section)</label>
                            <div id="categoryList" class="border rounded p-3" style="max-height: 300px; overflow-y: auto;">
                                <p class="text-muted">Categories will be listed here after section is created</p>
                            </div>
                            <div class="form-text">Select the categories you want to display in the circles section. If none selected, featured categories will be shown.</div>
                        </div>
                        <div class="mb-3 mt-3">
                            <label class="form-label fw-bold">Location <span class="text-danger">*</span></label>
                            <select class="form-select" id="configCategoryCirclesLocation">
                                <option value="top">Top (Before all sections)</option>
                                <option value="bottom">Bottom (After all sections)</option>
                            </select>
                            <div class="form-text">Section will be placed based on location</div>
                        </div>
                    </div>
                </div>
            `;
            setTimeout(() => {
                const existingLocation = $('#configCategoryCirclesLocation').val() || 'bottom';
                loadSectionsForLocationGeneric('#configCategoryCirclesLocation', existingLocation);
            }, 100);
            break;
            
        case 'departmentGrid':
            configHtml = `
                <div class="card border-info">
                    <div class="card-header bg-info text-white">
                        <strong>Department Grid Configuration</strong>
                    </div>
                    <div class="card-body">
                        <div class="mb-3">
                            <label class="form-label">Select Departments (will be loaded from Departments section)</label>
                            <div id="departmentList" class="border rounded p-3">
                                <p class="text-muted">Departments will be listed here after section is created</p>
                            </div>
                        </div>
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label">Grid Columns</label>
                                <select class="form-select" id="configGridColumns">
                                    <option value="2">2 Columns</option>
                                    <option value="3">3 Columns</option>
                                    <option value="4" selected>4 Columns</option>
                                    <option value="6">6 Columns</option>
                                    <option value="8">8 Columns</option>
                                </select>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Limit (max departments to show)</label>
                                <input type="number" class="form-control" id="configLimit" value="8" min="1" max="20">
                            </div>
                            <div class="col-md-6">
                                <div class="form-check mt-4">
                                    <input class="form-check-input" type="checkbox" id="configShowTitle" checked>
                                    <label class="form-check-label" for="configShowTitle">Show Department Titles</label>
                                </div>
                            </div>
                        </div>
                        <div class="mb-3 mt-3">
                            <label class="form-label fw-bold">Location <span class="text-danger">*</span></label>
                            <select class="form-select" id="configDepartmentGridLocation">
                                <option value="top">Top (Before all sections)</option>
                                <option value="bottom">Bottom (After all sections)</option>
                            </select>
                            <div class="form-text">Section will be placed based on location</div>
                        </div>
                    </div>
                </div>
            `;
            setTimeout(() => {
                const existingLocation = $('#configDepartmentGridLocation').val() || 'bottom';
                loadSectionsForLocationGeneric('#configDepartmentGridLocation', existingLocation);
            }, 100);
            break;
            
        case 'productTabs':
            configHtml = `
                <div class="card border-warning">
                    <div class="card-header bg-warning text-white">
                        <strong>Product Tabs Configuration</strong>
                    </div>
                    <div class="card-body">
                        <div class="mb-3">
                            <label class="form-label">Tabs (JSON format)</label>
                            <textarea class="form-control" id="configTabs" rows="5" placeholder='[{"label": "New Arrivals", "filter": {"isNewArrival": true}, "limit": 8}, {"label": "Featured", "filter": {"isFeatured": true}, "limit": 8}]'></textarea>
                            <div class="form-text">Each tab should have: label, filter (optional), limit (optional)</div>
                        </div>
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label">Category Filter (Optional)</label>
                                <select class="form-select" id="configCategoryId">
                                    <option value="">All Categories</option>
                                </select>
                            </div>
                            <div class="col-md-6">
                                <div class="form-check mt-4">
                                    <input class="form-check-input" type="checkbox" id="configShowViewAll">
                                    <label class="form-check-label" for="configShowViewAll">Show "View All" Link</label>
                                </div>
                            </div>
                        </div>
                        <div class="mb-3 mt-3">
                            <label class="form-label fw-bold">Location <span class="text-danger">*</span></label>
                            <select class="form-select" id="configProductTabsLocation">
                                <option value="top">Top (Before all sections)</option>
                                <option value="bottom">Bottom (After all sections)</option>
                            </select>
                            <div class="form-text">Section will be placed based on location</div>
                        </div>
                    </div>
                </div>
            `;
            setTimeout(() => {
                const existingLocation = $('#configProductTabsLocation').val() || 'bottom';
                loadSectionsForLocationGeneric('#configProductTabsLocation', existingLocation);
            }, 100);
            break;
            
        case 'productCarousel':
            configHtml = `
                <div class="card border-warning">
                    <div class="card-header bg-warning text-white">
                        <strong>Product Carousel Configuration</strong>
                    </div>
                    <div class="card-body">
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label">Category (Optional)</label>
                                <select class="form-select" id="configCategoryId">
                                    <option value="">All Categories</option>
                                </select>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Product Limit</label>
                                <input type="number" class="form-control" id="configLimit" value="10" min="1" max="50">
                            </div>
                            <div class="col-md-12">
                                <label class="form-label">Filter By</label>
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" id="configIsFeatured">
                                            <label class="form-check-label" for="configIsFeatured">Featured Products</label>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" id="configIsNewArrival">
                                            <label class="form-check-label" for="configIsNewArrival">New Arrivals</label>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" id="configIsTrending">
                                            <label class="form-check-label" for="configIsTrending">Trending</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" id="configAutoplay" checked>
                                    <label class="form-check-label" for="configAutoplay">Auto-play Carousel</label>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            `;
            break;
            
        case 'newArrivals':
            configHtml = `
                <div class="card border-success">
                    <div class="card-header bg-success text-white">
                        <strong>New Arrivals Configuration</strong>
                    </div>
                    <div class="card-body">
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label">Category (Optional)</label>
                                <select class="form-select" id="configCategoryId">
                                    <option value="">All Categories</option>
                                </select>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Product Limit</label>
                                <input type="number" class="form-control" id="configLimit" value="20" min="1" max="50">
                            </div>
                        </div>
                        <div class="alert alert-info mt-3">
                            <strong>Note:</strong> This section will automatically display products with "New Arrival" flag enabled.
                        </div>
                        <div class="mb-3 mt-3">
                            <label class="form-label fw-bold">Location <span class="text-danger">*</span></label>
                            <select class="form-select" id="configNewArrivalsLocation">
                                <option value="top">Top (Before all sections)</option>
                                <option value="bottom">Bottom (After all sections)</option>
                            </select>
                            <div class="form-text">Section will be placed based on location</div>
                        </div>
                    </div>
                </div>
            `;
            loadCategoriesForConfig();
            setTimeout(() => {
                const existingLocation = $('#configNewArrivalsLocation').val() || 'bottom';
                loadSectionsForLocationGeneric('#configNewArrivalsLocation', existingLocation);
            }, 100);
            break;
            
        case 'topSelling':
            configHtml = `
                <div class="card border-danger">
                    <div class="card-header bg-danger text-white">
                        <strong>Top Selling Products Configuration</strong>
                    </div>
                    <div class="card-body">
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label">Category (Optional)</label>
                                <select class="form-select" id="configCategoryId">
                                    <option value="">All Categories</option>
                                </select>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Product Limit</label>
                                <input type="number" class="form-control" id="configLimit" value="20" min="1" max="50">
                            </div>
                        </div>
                        <div class="alert alert-info mt-3">
                            <strong>Note:</strong> This section will automatically display products with "Top Selling" flag enabled.
                        </div>
                        <div class="mb-3 mt-3">
                            <label class="form-label fw-bold">Location <span class="text-danger">*</span></label>
                            <select class="form-select" id="configTopSellingLocation">
                                <option value="top">Top (Before all sections)</option>
                                <option value="bottom">Bottom (After all sections)</option>
                            </select>
                            <div class="form-text">Section will be placed based on location</div>
                        </div>
                    </div>
                </div>
            `;
            loadCategoriesForConfig();
            setTimeout(() => {
                const existingLocation = $('#configTopSellingLocation').val() || 'bottom';
                loadSectionsForLocationGeneric('#configTopSellingLocation', existingLocation);
            }, 100);
            break;
            
        case 'featuredCollections':
            configHtml = `
                <div class="card border-primary">
                    <div class="card-header bg-primary text-white">
                        <strong>Featured Collections Configuration</strong>
                    </div>
                    <div class="card-body">
                        <div class="alert alert-info">
                            <strong>Note:</strong> This section will automatically display all active subcategories in circles.
                            <br>• 8 subcategories per row
                            <br>• 3 rows visible at a time
                            <br>• Auto-slides every 3 seconds
                        </div>
                        <div class="mb-3 mt-3">
                            <label class="form-label fw-bold">Location <span class="text-danger">*</span></label>
                            <select class="form-select" id="configFeaturedCollectionsLocation">
                                <option value="top">Top (Before all sections)</option>
                                <option value="bottom">Bottom (After all sections)</option>
                            </select>
                            <div class="form-text">Section will be placed based on location</div>
                        </div>
                    </div>
                </div>
            `;
            setTimeout(() => {
                const existingLocation = $('#configFeaturedCollectionsLocation').val() || 'bottom';
                loadSectionsForLocationGeneric('#configFeaturedCollectionsLocation', existingLocation);
            }, 100);
            break;
            
        case 'subcategoryGrid':
            configHtml = `
                <div class="card border-info">
                    <div class="card-header bg-info text-white">
                        <strong>Subcategory Grid Configuration</strong>
                    </div>
                    <div class="card-body">
                        <div class="mb-3">
                            <label class="form-label">Select Subcategories for Grid (6 boxes - 2 rows × 3 columns)</label>
                            <div id="gridSubcategoriesList" class="border p-3" style="max-height: 200px; overflow-y: auto;">
                                <p class="text-muted">Loading subcategories...</p>
                            </div>
                            <div class="form-text">Select up to 6 subcategories to display in the grid boxes</div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Select Subcategories for Button Strip (Red buttons below grid)</label>
                            <div id="buttonSubcategoriesList" class="border p-3" style="max-height: 200px; overflow-y: auto;">
                                <p class="text-muted">Loading subcategories...</p>
                            </div>
                            <div class="form-text">Select subcategories to display in the auto-sliding red button strip. Leave empty to show all active subcategories.</div>
                        </div>
                        <div class="alert alert-info">
                            <strong>Note:</strong> This section displays 6 big boxes in a 2×3 grid with gradient backgrounds.
                            <br>• Each box shows a subcategory with its image and description
                            <br>• Red button strip below auto-slides every 3 seconds
                        </div>
                        <div class="mb-3 mt-3">
                            <label class="form-label fw-bold">Location <span class="text-danger">*</span></label>
                            <select class="form-select" id="configSubcategoryGridLocation">
                                <option value="top">Top (Before all sections)</option>
                                <option value="bottom">Bottom (After all sections)</option>
                            </select>
                            <div class="form-text">Section will be placed based on location</div>
                        </div>
                    </div>
                </div>
            `;
            // Store config for later use when loading subcategories
            window.pendingSubcategoryGridConfig = null;
            loadSubcategoriesForConfig();
            setTimeout(() => {
                const existingLocation = $('#configSubcategoryGridLocation').val() || 'bottom';
                loadSectionsForLocationGeneric('#configSubcategoryGridLocation', existingLocation);
            }, 100);
            break;
            
        case 'bannerFullWidth':
            configHtml = `
                <div class="card border-secondary">
                    <div class="card-header bg-secondary text-white">
                        <strong>Banner Section Configuration</strong>
                        <div class="form-text text-white-50 mt-1">Mobile-first responsive banner</div>
                    </div>
                    <div class="card-body">
                        <!-- Image Upload Section -->
                        <div class="mb-4">
                            <label class="form-label fw-bold">Banner Image <span class="text-danger">*</span></label>
                            <div class="row g-3">
                                <div class="col-md-6">
                                    <label class="form-label">Image URL</label>
                                    <input type="text" class="form-control" id="configBannerImageUrl" placeholder="https://example.com/image.jpg or Cloudinary URL">
                                    <div class="form-text">Enter image URL directly or upload below</div>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Upload Image File</label>
                                    <input type="file" class="form-control" id="configBannerImageFile" accept="image/*">
                                    <div class="form-text">Max size: 20MB (JPG, PNG, GIF, WebP) - Uploads to Cloudinary</div>
                                </div>
                            </div>
                            <div class="mt-3">
                                <label class="form-label">Image Preview</label>
                                <div id="configBannerImagePreview" class="border rounded p-2" style="min-height: 150px; background: #f8f9fa; display: flex; align-items: center; justify-content: center;">
                                    <span class="text-muted">No image selected</span>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Location Dropdown -->
                        <div class="mb-3">
                            <label class="form-label fw-bold">Location <span class="text-danger">*</span></label>
                            <select class="form-select" id="configBannerLocation">
                                <option value="top">Top (Before all sections)</option>
                                <option value="bottom">Bottom (After all sections)</option>
                            </select>
                            <div class="form-text">Banner will be placed based on location, not custom sequence</div>
                        </div>
                        
                        <!-- Link URL -->
                        <div class="mb-3">
                            <label class="form-label fw-bold">Banner Link (Optional)</label>
                            <input type="url" class="form-control" id="configBannerLink" placeholder="https://example.com/page">
                            <div class="form-text">URL to navigate when banner is clicked</div>
                        </div>
                        
                        <!-- Size Mode -->
                        <div class="mb-3">
                            <label class="form-label fw-bold">Size Mode <span class="text-danger">*</span></label>
                            <select class="form-select" id="configBannerSizeMode">
                                <option value="auto">Auto (100% Width, Auto Height)</option>
                                <option value="custom">Custom Size</option>
                            </select>
                            <div class="form-text">Choose how the banner should be sized</div>
                        </div>
                        
                        <!-- Custom Dimensions (shown when custom is selected) -->
                        <div id="configBannerCustomDimensions" style="display: none;">
                            <div class="row g-3 mb-3">
                                <div class="col-md-6">
                                    <label class="form-label fw-bold">Custom Width (px)</label>
                                    <input type="number" class="form-control" id="configBannerCustomWidth" placeholder="e.g., 1200" min="100" max="5000">
                                    <div class="form-text">Leave empty for 100% width (responsive)</div>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label fw-bold">Custom Height (px)</label>
                                    <input type="number" class="form-control" id="configBannerCustomHeight" placeholder="e.g., 400" min="50" max="2000">
                                    <div class="form-text">Height in pixels</div>
                                </div>
                            </div>
                            <div class="row g-3 mb-3">
                                <div class="col-md-4">
                                    <label class="form-label">Mobile Height (px)</label>
                                    <input type="number" class="form-control" id="configBannerMobileHeight" placeholder="e.g., 200" min="50" max="1000">
                                    <div class="form-text">Height on mobile devices</div>
                                </div>
                                <div class="col-md-4">
                                    <label class="form-label">Tablet Height (px)</label>
                                    <input type="number" class="form-control" id="configBannerTabletHeight" placeholder="e.g., 300" min="50" max="1500">
                                    <div class="form-text">Height on tablet devices</div>
                                </div>
                                <div class="col-md-4">
                                    <label class="form-label">Desktop Height (px)</label>
                                    <input type="number" class="form-control" id="configBannerDesktopHeight" placeholder="e.g., 400" min="50" max="2000">
                                    <div class="form-text">Height on desktop devices</div>
                                </div>
                            </div>
                            <div class="alert alert-warning">
                                <i class="fas fa-exclamation-triangle"></i> <strong>Mobile-First Responsive:</strong> Custom sizes will still be responsive. Mobile/Tablet/Desktop heights override the main custom height on respective devices.
                            </div>
                        </div>
                        
                        <div class="alert alert-info">
                            <i class="fas fa-info-circle"></i> <strong>Mobile-First Design:</strong> Banner is fully responsive and optimized for mobile devices. Images are automatically optimized for different screen sizes.
                        </div>
                    </div>
                </div>
            `;
            // Initialize image field and load banners
            setTimeout(() => {
                initImageField({ 
                    urlInput: '#configBannerImageUrl', 
                    fileInput: '#configBannerImageFile', 
                    preview: '#configBannerImagePreview' 
                });
                loadBannersForConfig();
                // Preserve existing location value if editing, otherwise default to 'bottom'
                const existingLocation = $('#configBannerLocation').val() || 'bottom';
                loadSectionsForLocationGeneric('#configBannerLocation', existingLocation);
                
                // Show/hide custom dimensions based on size mode selection
                $('#configBannerSizeMode').change(function() {
                    if ($(this).val() === 'custom') {
                        $('#configBannerCustomDimensions').slideDown();
                    } else {
                        $('#configBannerCustomDimensions').slideUp();
                    }
                });
                
                // Trigger change event to set initial state
                $('#configBannerSizeMode').trigger('change');
            }, 100);
            break;
            
        case 'videoBanner':
            configHtml = `
                <div class="card border-danger">
                    <div class="card-header bg-danger text-white">
                        <strong>Video Banner Configuration</strong>
                    </div>
                    <div class="card-body">
                        <!-- Video Source -->
                        <div class="mb-3">
                            <label class="form-label fw-bold">Video Source <span class="text-danger">*</span></label>
                            <select class="form-select" id="configVideoType">
                                <option value="youtube">YouTube</option>
                                <option value="vimeo">Vimeo</option>
                                <option value="direct">Direct Video URL</option>
                                <option value="file">Upload Video File</option>
                            </select>
                            <div class="form-text">Choose how you want to provide the video</div>
                        </div>

                        <!-- Video URL (for YouTube, Vimeo, or Direct) -->
                        <div class="mb-3" id="configVideoUrlGroup">
                            <label class="form-label">Video URL <span class="text-danger">*</span></label>
                            <input type="url" class="form-control" id="configVideoUrl" placeholder="Enter YouTube, Vimeo, or direct video URL">
                            <div class="form-text" id="configVideoUrlHelp">
                                For YouTube: https://www.youtube.com/watch?v=... or https://youtu.be/...<br>
                                For Vimeo: https://vimeo.com/...<br>
                                For Direct: https://example.com/video.mp4
                            </div>
                            <div id="configVideoUrlPreview" class="mt-2"></div>
                        </div>

                        <!-- Video File Upload -->
                        <div class="mb-3" id="configVideoFileGroup" style="display: none;">
                            <label class="form-label">Upload Video File <span class="text-danger">*</span></label>
                            <input type="file" class="form-control" id="configVideoFile" accept="video/*">
                            <div class="form-text">Maximum file size: 500MB. Supported formats: MP4, WebM, OGG, MOV, AVI</div>
                            <div id="configVideoFileSize" class="mt-1"></div>
                            <div id="configVideoFilePreview" class="mt-2"></div>
                            <input type="hidden" id="configVideoFileId">
                        </div>

                        <!-- Poster Image -->
                        <div class="mb-3">
                            <label class="form-label">Poster Image (Optional)</label>
                            <div class="row">
                                <div class="col-md-6">
                                    <input type="url" class="form-control" id="configVideoPosterUrl" placeholder="Poster image URL">
                                </div>
                                <div class="col-md-6">
                                    <input type="file" class="form-control" id="configVideoPosterFile" accept="image/*">
                                </div>
                            </div>
                            <div class="form-text">Image shown before video plays (recommended for direct video files)</div>
                            <div id="configVideoPosterPreview" class="mt-2"></div>
                            <input type="hidden" id="configVideoPosterFileId">
                        </div>

                        <!-- Video Settings -->
                        <div class="mb-3">
                            <label class="form-label fw-bold">Video Settings</label>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="configVideoAutoplay" checked>
                                <label class="form-check-label" for="configVideoAutoplay">Autoplay</label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="configVideoLoop" checked>
                                <label class="form-check-label" for="configVideoLoop">Loop</label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="configVideoMuted" checked>
                                <label class="form-check-label" for="configVideoMuted">Muted (required for autoplay)</label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="configVideoControls">
                                <label class="form-check-label" for="configVideoControls">Show Controls</label>
                            </div>
                        </div>

                        <!-- Overlay Content -->
                        <div class="mb-3">
                            <label class="form-label fw-bold">Overlay Content (Optional)</label>
                            <div class="mb-2">
                                <input type="text" class="form-control" id="configOverlayText" placeholder="Overlay title text">
                            </div>
                            <div class="mb-2">
                                <textarea class="form-control" id="configOverlayDescription" rows="2" placeholder="Overlay description text"></textarea>
                            </div>
                            <div class="mb-2">
                                <input type="text" class="form-control" id="configCtaText" placeholder="CTA Button Text">
                            </div>
                            <div>
                                <input type="url" class="form-control" id="configCtaLink" placeholder="CTA Button Link (URL)">
                            </div>
                        </div>

                        <!-- Location -->
                        <div class="mb-3 mt-3">
                            <label class="form-label fw-bold">Location <span class="text-danger">*</span></label>
                            <select class="form-select" id="configVideoBannerLocation">
                                <option value="top">Top (Before all sections)</option>
                                <option value="bottom">Bottom (After all sections)</option>
                            </select>
                            <div class="form-text">Section will be placed based on location</div>
                        </div>
                    </div>
                </div>
            `;
            // Initialize video type change handler
            setTimeout(() => {
                // Initialize image field for poster
                initImageField({ 
                    urlInput: '#configVideoPosterUrl', 
                    fileInput: '#configVideoPosterFile', 
                    preview: '#configVideoPosterPreview' 
                });

                // Video type change handler
                $('#configVideoType').change(function() {
                    const videoType = $(this).val();
                    if (videoType === 'file') {
                        $('#configVideoUrlGroup').hide();
                        $('#configVideoFileGroup').show();
                        $('#configVideoUrl').removeAttr('required');
                        $('#configVideoFile').attr('required', 'required');
                    } else {
                        $('#configVideoUrlGroup').show();
                        $('#configVideoFileGroup').hide();
                        $('#configVideoFile').removeAttr('required');
                        $('#configVideoUrl').attr('required', 'required');
                        
                        // Update help text based on type
                        const helpText = $('#configVideoUrlHelp');
                        if (videoType === 'youtube') {
                            helpText.html('For YouTube: https://www.youtube.com/watch?v=... or https://youtu.be/...');
                        } else if (videoType === 'vimeo') {
                            helpText.html('For Vimeo: https://vimeo.com/...');
                        } else {
                            helpText.html('For Direct: https://example.com/video.mp4');
                        }
                    }
                });

                // Video URL preview handler
                $('#configVideoUrl').on('input', function() {
                    const url = $(this).val().trim();
                    const videoType = $('#configVideoType').val();
                    if (url && (videoType === 'youtube' || videoType === 'vimeo')) {
                        const detectedType = detectVideoTypeFromUrl(url);
                        if (detectedType === 'youtube' || detectedType === 'vimeo') {
                            showVideoEmbedPreview('#configVideoUrlPreview', url, detectedType);
                        }
                    } else {
                        $('#configVideoUrlPreview').empty();
                    }
                });

                // Video file upload handler
                $('#configVideoFile').on('change', function() {
                    const file = this.files && this.files[0];
                    if (file) {
                        const fileSizeMB = (file.size / (1024 * 1024)).toFixed(2);
                        const maxSizeMB = 500;
                        const sizeClass = file.size > (maxSizeMB * 1024 * 1024) ? 'text-danger' : 'text-success';
                        $('#configVideoFileSize').html(`<span class="${sizeClass}">Video size: ${fileSizeMB} MB</span>`);
                        if (file.size > (maxSizeMB * 1024 * 1024)) {
                            $('#configVideoFileSize').append(` <span class="text-danger">(Exceeds ${maxSizeMB} MB limit!)</span>`);
                        }
                        
                        // Show video preview
                        const reader = new FileReader();
                        reader.onload = function(event) {
                            $('#configVideoFilePreview').html(`<video src="${event.target.result}" controls style="max-width: 100%; max-height: 200px;" class="border rounded"></video>`);
                        };
                        reader.readAsDataURL(file);
                    } else {
                        $('#configVideoFileSize').empty();
                        $('#configVideoFilePreview').empty();
                    }
                });

                // Load location dropdown
                const existingLocation = $('#configVideoBannerLocation').val() || 'bottom';
                loadSectionsForLocationGeneric('#configVideoBannerLocation', existingLocation);

                // Trigger initial state
                $('#configVideoType').trigger('change');
            }, 100);
            break;
            
        case 'newsletterSocial':
            configHtml = `
                <div class="card border-dark">
                    <div class="card-header bg-dark text-white">
                        <strong>Newsletter & Social Configuration</strong>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6">
                                <h6 class="mb-3">Social Media Section (Left Side)</h6>
                                <div class="mb-3">
                                    <label class="form-label">Social Title</label>
                                    <input type="text" class="form-control" id="configSocialTitle" placeholder="LET'S CONNECT ON SOCIAL MEDIA">
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Social Description</label>
                                    <textarea class="form-control" id="configSocialDesc" rows="2" placeholder="Follow us to stay updated on latest looks."></textarea>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label"><i class="fab fa-facebook-f"></i> Facebook URL</label>
                                    <input type="url" class="form-control" id="configFacebookUrl" placeholder="https://facebook.com/yourpage">
                                </div>
                                <div class="mb-3">
                                    <label class="form-label"><i class="fab fa-instagram"></i> Instagram URL</label>
                                    <input type="url" class="form-control" id="configInstagramUrl" placeholder="https://instagram.com/yourpage">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <h6 class="mb-3">Newsletter Section (Right Side)</h6>
                                <div class="mb-3">
                                    <label class="form-label">Newsletter Title</label>
                                    <input type="text" class="form-control" id="configNewsletterTitle" placeholder="SIGN UP FOR EXCLUSIVE OFFERS & DISCOUNTS">
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Newsletter Description</label>
                                    <textarea class="form-control" id="configNewsletterDesc" rows="2" placeholder="Stay updated on new deals and news."></textarea>
                                </div>
                            </div>
                        </div>
                        <div class="mb-3 mt-3">
                            <label class="form-label fw-bold">Location <span class="text-danger">*</span></label>
                            <select class="form-select" id="configNewsletterSocialLocation">
                                <option value="top">Top (Before all sections)</option>
                                <option value="bottom">Bottom (After all sections)</option>
                            </select>
                            <div class="form-text">Section will be placed based on location</div>
                        </div>
                    </div>
                </div>
            `;
            setTimeout(() => {
                const existingLocation = $('#configNewsletterSocialLocation').val() || 'bottom';
                loadSectionsForLocationGeneric('#configNewsletterSocialLocation', existingLocation);
            }, 100);
            break;
            
        case 'brandGrid':
            configHtml = `
                <div class="card border-success">
                    <div class="card-header bg-success text-white">
                        <strong>Brand Grid Configuration</strong>
                    </div>
                    <div class="card-body">
                        <div class="mb-3">
                            <label class="form-label">Limit (Number of brands to display)</label>
                            <input type="number" class="form-control" id="configBrandGridLimit" min="1" max="20" value="10">
                            <div class="form-text">Maximum number of brands to display in the grid (default: 10). Brands are automatically loaded from the database.</div>
                        </div>
                        <div class="alert alert-info">
                            <strong>Note:</strong> Brands are automatically loaded from the database. Make sure you have active brands with images and discount information set up in the "Brand Logos" section.
                        </div>
                        <div class="mb-3 mt-3">
                            <label class="form-label fw-bold">Location <span class="text-danger">*</span></label>
                            <select class="form-select" id="configBrandGridLocation">
                                <option value="top">Top (Before all sections)</option>
                                <option value="bottom">Bottom (After all sections)</option>
                            </select>
                            <div class="form-text">Section will be placed based on location</div>
                        </div>
                    </div>
                </div>
            `;
            setTimeout(() => {
                const existingLocation = $('#configBrandGridLocation').val() || 'bottom';
                loadSectionsForLocationGeneric('#configBrandGridLocation', existingLocation);
            }, 100);
            break;
            
        case 'brandSection':
            configHtml = `
                <div class="card border-secondary">
                    <div class="card-header bg-secondary text-white">
                        <strong>Brand Section Configuration</strong>
                    </div>
                    <div class="card-body">
                        <div class="alert alert-info">
                            <i class="fas fa-info-circle"></i> <strong>Brand Section:</strong> Add multiple brands with images. Images will be uploaded to Cloudinary and URLs saved in database.
                        </div>
                        
                        <!-- Add Brand Form (Inline) -->
                        <div class="mb-4 border rounded p-3" id="brandSectionAddForm" style="background: #f8f9fa; display: none;">
                            <h6 class="mb-3"><i class="fas fa-plus-circle"></i> Add New Brand</h6>
                            <form id="brandSectionInlineForm" onsubmit="return false;">
                                <input type="hidden" id="brandSectionEditIndex" value="">
                                
                                <div class="row mb-3">
                                    <div class="col-md-6">
                                        <label class="form-label">Brand Name <span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" id="brandSectionName" autocomplete="off" placeholder="Enter brand name">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label">Display Order</label>
                                        <input type="number" class="form-control" id="brandSectionOrder" value="0">
                                    </div>
                                </div>
                                
                                <div class="mb-3">
                                    <label class="form-label">Brand Link (Optional)</label>
                                    <input type="url" class="form-control" id="brandSectionLink" placeholder="https://example.com">
                                </div>
                                
                                <div class="row mb-3">
                                    <div class="col-md-6">
                                        <label class="form-label">Discount (%)</label>
                                        <input type="number" class="form-control" id="brandSectionDiscount" value="0" min="0" max="100">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label">Discount Text</label>
                                        <input type="text" class="form-control" id="brandSectionDiscountText" placeholder="e.g., Flat 50% OFF">
                                    </div>
                                </div>
                                
                                <div class="mb-3">
                                    <label class="form-label">Brand Logo <span class="text-danger">*</span></label>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <input type="file" class="form-control" id="brandSectionImageFile" accept="image/*">
                                            <div class="form-text">Upload to Cloudinary (Max 20MB)</div>
                                        </div>
                                        <div class="col-md-6">
                                            <input type="text" class="form-control" id="brandSectionImageUrl" placeholder="Or enter image URL">
                                        </div>
                                    </div>
                                    <div class="mt-3">
                                        <div id="brandSectionImagePreview" class="border rounded p-2" style="min-height: 150px; background: #ffffff; display: flex; align-items: center; justify-content: center;">
                                            <span class="text-muted">No image selected</span>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="d-flex gap-2">
                                    <button type="button" class="btn btn-primary" id="saveBrandSectionInline">
                                        <i class="fas fa-save"></i> <span id="saveBrandSectionInlineText">Add Brand</span>
                                    </button>
                                    <button type="button" class="btn btn-secondary" id="cancelBrandSectionInline">
                                        <i class="fas fa-times"></i> Cancel
                                    </button>
                                </div>
                            </form>
                        </div>
                        
                        <!-- Brands List -->
                        <div class="mb-4">
                            <div class="d-flex justify-content-between align-items-center mb-3">
                                <label class="form-label fw-bold mb-0">Brands <span class="text-danger">*</span></label>
                                <button type="button" class="btn btn-sm btn-success" id="addBrandToSectionBtn">
                                    <i class="fas fa-plus"></i> Add Brand
                                </button>
                            </div>
                            <div id="brandSectionBrandsList" class="border rounded p-3" style="min-height: 150px; background: #f8f9fa;">
                                <p class="text-muted text-center mb-0">No brands added yet. Click "Add Brand" to start.</p>
                            </div>
                        </div>
                        
                        <div class="mb-3 mt-3">
                            <label class="form-label fw-bold">Location <span class="text-danger">*</span></label>
                            <select class="form-select" id="configBrandSectionLocation">
                                <option value="top">Top (Before all sections)</option>
                                <option value="bottom">Bottom (After all sections)</option>
                            </select>
                            <div class="form-text">Section will be placed based on location</div>
                        </div>
                    </div>
                </div>
            `;
            setTimeout(() => {
                // Initialize brands array if not exists
                if (typeof window.brandSectionBrands === 'undefined') {
                    window.brandSectionBrands = [];
                }
                updateBrandSectionBrandsList();
                
                // Add brand button handler - show inline form
                $('#addBrandToSectionBtn').off('click').on('click', function() {
                    const addForm = $('#brandSectionAddForm');
                    if (addForm.length === 0) {
                        console.error('Brand Section Add Form not found');
                        return;
                    }
                    
                    addForm.slideDown(300);
                    
                    // Reset form fields individually to avoid form.reset() issues
                    $('#brandSectionName').val('');
                    $('#brandSectionLink').val('');
                    $('#brandSectionDiscount').val('0');
                    $('#brandSectionDiscountText').val('');
                    $('#brandSectionOrder').val('0');
                    $('#brandSectionImageFile').val('');
                    $('#brandSectionImageUrl').val('');
                    $('#brandSectionEditIndex').val('');
                    $('#brandSectionImagePreview').html('<span class="text-muted">No image selected</span>');
                    $('#saveBrandSectionInlineText').text('Add Brand');
                    
                    setTimeout(() => {
                        $('#brandSectionName').focus();
                        // Scroll to form
                        $('html, body').animate({
                            scrollTop: addForm.offset().top - 100
                        }, 300);
                    }, 100);
                });
                
                // Cancel button handler
                $('#cancelBrandSectionInline').off('click').on('click', function() {
                    $('#brandSectionAddForm').slideUp(300);
                    // Reset form fields individually
                    $('#brandSectionName').val('');
                    $('#brandSectionLink').val('');
                    $('#brandSectionDiscount').val('0');
                    $('#brandSectionDiscountText').val('');
                    $('#brandSectionOrder').val('0');
                    $('#brandSectionImageFile').val('');
                    $('#brandSectionImageUrl').val('');
                    $('#brandSectionEditIndex').val('');
                    $('#brandSectionImagePreview').html('<span class="text-muted">No image selected</span>');
                    $('#saveBrandSectionInlineText').text('Add Brand');
                });
                
                // Handle image file change
                $('#brandSectionImageFile').off('change').on('change', function() {
                    const file = this.files[0];
                    const preview = $('#brandSectionImagePreview');
                    if (file && file.type.startsWith('image/')) {
                        const reader = new FileReader();
                        reader.onload = function(e) {
                            preview.html(`<img src="${e.target.result}" class="img-thumbnail" style="max-width: 100%; max-height: 200px;">`);
                        };
                        reader.readAsDataURL(file);
                    } else {
                        preview.html('<span class="text-danger">Please select an image file</span>');
                    }
                });
                
                // Handle image URL change
                $('#brandSectionImageUrl').off('input').on('input', function() {
                    const url = $(this).val()?.trim();
                    if (url) {
                        setImagePreview('#brandSectionImagePreview', url);
                    } else {
                        $('#brandSectionImagePreview').html('<span class="text-muted">No image selected</span>');
                    }
                });
                
                // Save brand inline handler
                $('#saveBrandSectionInline').off('click').on('click', function(e) {
                    e.preventDefault();
                    e.stopPropagation();
                    console.log('Save button clicked');
                    
                    // Capture values SYNCHRONOUSLY - no async, no delays
                    const nameInput = document.getElementById('brandSectionName');
                    if (!nameInput) {
                        console.error('Brand name input not found!');
                        showAlert('Brand name field not found. Please refresh the page.', 'danger');
                        return false;
                    }
                    
                    // Try multiple ways to get the value SYNCHRONOUSLY
                    let nameValue = '';
                    
                    // Method 1: Direct DOM value property
                    if (nameInput.value) {
                        nameValue = nameInput.value;
                        console.log('Got value from nameInput.value:', nameValue);
                    }
                    
                    // Method 2: jQuery val() if DOM value is empty
                    if (!nameValue) {
                        const jqVal = $('#brandSectionName').val();
                        if (jqVal) {
                            nameValue = jqVal;
                            console.log('Got value from jQuery val():', nameValue);
                        }
                    }
                    
                    // Method 3: Check all possible properties
                    console.log('=== DEBUGGING FIELD VALUE ===');
                    console.log('nameInput:', nameInput);
                    console.log('nameInput.value:', nameInput.value);
                    console.log('nameInput.defaultValue:', nameInput.defaultValue);
                    console.log('nameInput.getAttribute("value"):', nameInput.getAttribute('value'));
                    console.log('$("#brandSectionName").val():', $('#brandSectionName').val());
                    console.log('nameInput.textContent:', nameInput.textContent);
                    console.log('nameInput.innerText:', nameInput.innerText);
                    console.log('nameInput.outerHTML:', nameInput.outerHTML);
                    console.log('=== END DEBUGGING ===');
                    
                    if (!nameValue || nameValue.trim() === '') {
                        console.error('Brand name is empty! User needs to enter a value.');
                        showAlert('Please enter a brand name before saving.', 'warning');
                        nameInput.focus();
                        return false;
                    }
                    
                    console.log('Brand name captured successfully:', nameValue);
                    
                    // Store in data attribute as backup
                    nameInput.setAttribute('data-captured-value', nameValue);
                    
                    // Call async function with captured value
                    saveBrandSectionInline(e, nameValue);
                    return false;
                });
                
                // Also prevent form submission
                $('#brandSectionInlineForm').off('submit').on('submit', function(e) {
                    e.preventDefault();
                    e.stopPropagation();
                    console.log('Form submit prevented, calling saveBrandSectionInline');
                    saveBrandSectionInline(e);
                    return false;
                });
                
                const existingLocation = $('#configBrandSectionLocation').val() || 'bottom';
                loadSectionsForLocationGeneric('#configBrandSectionLocation', existingLocation);
            }, 100);
            break;
            
        case 'customHTML':
            configHtml = `
                <div class="card border-dark">
                    <div class="card-header bg-dark text-white">
                        <strong>Custom HTML Configuration</strong>
                    </div>
                    <div class="card-body">
                        <div class="mb-3">
                            <label class="form-label">Custom HTML</label>
                            <textarea class="form-control font-monospace" id="configCustomHTML" rows="10" placeholder="<div>Your custom HTML here</div>"></textarea>
                            <div class="form-text">Enter custom HTML code. This will be rendered directly on the homepage.</div>
                        </div>
                        <div class="mb-3 mt-3">
                            <label class="form-label fw-bold">Location <span class="text-danger">*</span></label>
                            <select class="form-select" id="configCustomHTMLLocation">
                                <option value="top">Top (Before all sections)</option>
                                <option value="bottom">Bottom (After all sections)</option>
                            </select>
                            <div class="form-text">Section will be placed based on location</div>
                        </div>
                    </div>
                </div>
            `;
            setTimeout(() => {
                const existingLocation = $('#configCustomHTMLLocation').val() || 'bottom';
                loadSectionsForLocationGeneric('#configCustomHTMLLocation', existingLocation);
            }, 100);
            break;
            
        default:
            configHtml = '<div class="alert alert-info">No special configuration needed for this section type.</div>';
    }
    
    $('#homepageSectionConfigArea').html(configHtml);
    
    // Load data for specific types
    if (sectionType === 'heroSlider') {
        loadSlidersForConfig();
    }
    if (sectionType === 'categoryFeatured' || sectionType === 'categoryGrid' || sectionType === 'categoryCircles') {
        loadCategoriesListForConfig();
    }
    if (sectionType === 'categoryFeatured' || sectionType === 'categoryGrid' || sectionType === 'categoryCircles' || sectionType === 'productTabs' || sectionType === 'productCarousel') {
        loadCategoriesForConfig();
    }
    if (sectionType === 'bannerFullWidth') {
        loadBannersForConfig();
    }
    // Brand Marquee now uses Brand Logos automatically - no need to load brands dropdown
}

// Load brands for Brand Marquee dropdown
async function loadBrandsForMarquee() {
    try {
        const brands = await $.get('/api/admin/brands', {
            headers: {
                'x-auth-token': localStorage.getItem('token') || ''
            }
        });
        
        const brandsArray = Array.isArray(brands) ? brands : (brands.brands || brands.data || []);
        const select = $('#configBrandMarqueeBrandSelect');
        select.html('<option value="">-- Select Brand --</option>');
        
        brandsArray.forEach(brand => {
            if (brand.isActive !== false) {
                select.append(`<option value="${brand._id}">${brand.name}</option>`);
            }
        });
    } catch (error) {
        console.error('Error loading brands for marquee:', error);
        $('#configBrandMarqueeBrandSelect').html('<option value="">Error loading brands</option>');
    }
}

async function loadSlidersForConfig() {
    try {
        const sliders = await $.get('/api/sliders');
        let html = '';
        sliders.forEach(slider => {
            if (slider.isActive) {
                html += `
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" name="sliderIds" value="${slider._id}" id="slider_${slider._id}">
                        <label class="form-check-label" for="slider_${slider._id}">${slider.title}</label>
                    </div>
                `;
            }
        });
        if (html) {
            $('#heroSliderList').html(html);
        } else {
            $('#heroSliderList').html('<p class="text-muted">No active sliders found. Create sliders first.</p>');
        }
    } catch (error) {
        console.error('Error loading sliders:', error);
    }
}

async function loadCategoriesForConfig() {
    try {
        const categories = await $.get('/api/categories');
        let html = '<option value="">All Categories</option>';
        categories.forEach(cat => {
            if (cat.isActive) {
                html += `<option value="${cat._id}">${cat.name}</option>`;
            }
        });
        if ($('#configCategoryId').length) {
            $('#configCategoryId').html(html);
        }
    } catch (error) {
        console.error('Error loading categories:', error);
    }
}

async function loadSubcategoriesForConfig(selectedGridIds = [], selectedButtonIds = []) {
    try {
        const subcategories = await $.get('/api/admin/subcategories');
        let gridHtml = '';
        let buttonHtml = '';
        
        subcategories.forEach(subcat => {
            if (subcat.isActive) {
                const isGridChecked = selectedGridIds.includes(subcat._id.toString()) || selectedGridIds.includes(subcat._id);
                const isButtonChecked = selectedButtonIds.includes(subcat._id.toString()) || selectedButtonIds.includes(subcat._id);
                
                const gridChecked = isGridChecked ? 'checked' : '';
                const buttonChecked = isButtonChecked ? 'checked' : '';
                
                const checkbox = `
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" name="gridSubcategoryIds" value="${subcat._id}" id="gridSubcat_${subcat._id}" ${gridChecked}>
                        <label class="form-check-label" for="gridSubcat_${subcat._id}">${subcat.name}</label>
                    </div>
                `;
                gridHtml += checkbox;
                
                const buttonCheckbox = `
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" name="buttonSubcategoryIds" value="${subcat._id}" id="buttonSubcat_${subcat._id}" ${buttonChecked}>
                        <label class="form-check-label" for="buttonSubcat_${subcat._id}">${subcat.name}</label>
                    </div>
                `;
                buttonHtml += buttonCheckbox;
            }
        });
        
        if (gridHtml === '') {
            gridHtml = '<p class="text-muted">No active subcategories found</p>';
        }
        if (buttonHtml === '') {
            buttonHtml = '<p class="text-muted">No active subcategories found</p>';
        }
        
        $('#gridSubcategoriesList').html(gridHtml);
        $('#buttonSubcategoriesList').html(buttonHtml);
    } catch (error) {
        console.error('Error loading subcategories:', error);
        $('#gridSubcategoriesList').html('<p class="text-danger">Error loading subcategories</p>');
        $('#buttonSubcategoriesList').html('<p class="text-danger">Error loading subcategories</p>');
    }
}

async function loadCategoriesListForConfig() {
    try {
        const categories = await $.get('/api/categories');
        let html = '';
        categories.forEach(cat => {
            if (cat.isActive) {
                html += `
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" name="categoryIds" value="${cat._id}" id="category_${cat._id}">
                        <label class="form-check-label" for="category_${cat._id}">${cat.name}</label>
                    </div>
                `;
            }
        });
        if (html) {
            $('#categoryList').html(html);
        } else {
            $('#categoryList').html('<p class="text-muted">No active categories found. Create categories first.</p>');
        }
    } catch (error) {
        console.error('Error loading categories:', error);
    }
}

async function loadDepartmentsListForConfig() {
    try {
        const departments = await $.get('/api/departments');
        let html = '';
        departments.forEach(dept => {
            if (dept.isActive) {
                html += `
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" name="departmentIds" value="${dept._id}" id="department_${dept._id}">
                        <label class="form-check-label" for="department_${dept._id}">${dept.name}</label>
                    </div>
                `;
            }
        });
        if (html) {
            $('#departmentList').html(html);
        } else {
            $('#departmentList').html('<p class="text-muted">No active departments found. Create departments first.</p>');
        }
    } catch (error) {
        console.error('Error loading departments:', error);
    }
}

async function loadBannersForConfig() {
    try {
        const banners = await $.get('/api/banners');
        let html = '<option value="">Use uploaded image above</option>';
        banners.forEach(banner => {
            if (banner.isActive) {
                html += `<option value="${banner._id}">${banner.title || 'Untitled Banner'}</option>`;
            }
        });
        $('#configBannerId').html(html);
    } catch (error) {
        console.error('Error loading banners:', error);
    }
}

// Brand Section Brands Management - Inline Form
async function saveBrandSectionInline(e, capturedName = null) {
    if (e) {
        e.preventDefault();
        e.stopPropagation();
    }
    
    console.log('saveBrandSectionInline called');
    console.log('Captured name parameter:', capturedName);
    
    const nameField = $('#brandSectionName');
    if (nameField.length === 0) {
        console.error('Brand name field not found in DOM');
        showAlert('Brand name field not found. Please refresh and try again.', 'danger');
        return;
    }
    
    // Get value directly from DOM element to avoid jQuery caching issues
    const nameInput = document.getElementById('brandSectionName');
    
    // Use captured value if provided, otherwise try to get from field
    let rawValue = capturedName || '';
    if (!rawValue && nameInput) {
        // Try multiple sources
        rawValue = nameInput.getAttribute('data-captured-value') || 
                   nameInput.value || 
                   nameField.val() || 
                   '';
    } else if (!rawValue) {
        rawValue = nameField.val() || '';
    }
    
    const name = rawValue ? String(rawValue).trim() : '';
    
    console.log('Brand name field exists:', nameField.length > 0);
    console.log('Brand name DOM element:', nameInput);
    console.log('Brand name raw value (from DOM .value):', nameInput ? nameInput.value : 'N/A');
    console.log('Brand name raw value (from data-captured-value):', nameInput ? nameInput.getAttribute('data-captured-value') : 'N/A');
    console.log('Brand name raw value (from jQuery):', nameField.val());
    console.log('Brand name raw value (final):', rawValue);
    console.log('Brand name after trim:', name);
    console.log('Brand name length:', name.length);
    
    if (!name || name === '' || name.length === 0) {
        console.error('Brand name validation failed - empty or whitespace only');
        console.error('Field element:', nameInput);
        console.error('Field value attribute:', nameInput ? nameInput.value : 'N/A');
        console.error('All field attributes:', nameInput ? Array.from(nameInput.attributes).map(a => `${a.name}="${a.value}"`).join(', ') : 'N/A');
        showAlert('Brand name is required. Please enter a brand name.', 'warning');
        if (nameInput) {
            nameInput.focus();
        } else {
            nameField.focus();
        }
        return;
    }
    
    console.log('Brand name validated successfully:', name);
    
    const imageFile = $('#brandSectionImageFile')[0].files[0];
    const imageUrl = $('#brandSectionImageUrl').val()?.trim();
    const editIndex = $('#brandSectionEditIndex').val();
    const isEdit = editIndex !== '' && editIndex !== null;
    
    // If editing and no new image/file provided, use existing imageUrl
    let finalImageUrl = imageUrl;
    let imageFileId = null;
    
    if (isEdit && window.brandSectionBrands && window.brandSectionBrands[editIndex]) {
        // If editing and no new image provided, keep existing
        if (!imageFile && !imageUrl) {
            finalImageUrl = window.brandSectionBrands[editIndex].imageUrl || '';
        }
    }
    
    // Validate image
    if (!imageFile && !finalImageUrl) {
        showAlert('Please upload an image or provide an image URL', 'warning');
        return;
    }
    
    // Upload image if file is provided
    if (imageFile) {
        try {
            const formData = new FormData();
            formData.append('file', imageFile);
            formData.append('folder', 'brand-sections');
            
            const uploadResponse = await $.ajax({
                url: '/api/admin/media',
                method: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                headers: {
                    'x-auth-token': localStorage.getItem('token')
                }
            });
            
            finalImageUrl = uploadResponse.url;
            imageFileId = uploadResponse._id;
        } catch (error) {
            console.error('Error uploading image:', error);
            showAlert('Error uploading image. Please try again.', 'danger');
            return;
        }
    }
    
    const brandData = {
        name: name,
        imageUrl: finalImageUrl,
        imageFileId: imageFileId,
        link: $('#brandSectionLink').val()?.trim() || '',
        discount: parseFloat($('#brandSectionDiscount').val()) || 0,
        discountText: $('#brandSectionDiscountText').val()?.trim() || '',
        order: parseInt($('#brandSectionOrder').val()) || 0
    };
    
    // Initialize array if needed
    if (typeof window.brandSectionBrands === 'undefined') {
        window.brandSectionBrands = [];
    }
    
    // Add or update brand
    if (isEdit) {
        // Keep existing imageFileId if not uploading new image
        if (!imageFileId && window.brandSectionBrands[editIndex]) {
            brandData.imageFileId = window.brandSectionBrands[editIndex].imageFileId;
        }
        window.brandSectionBrands[editIndex] = brandData;
        console.log('Brand updated at index', editIndex, brandData);
        showAlert('Brand updated successfully', 'success');
    } else {
        window.brandSectionBrands.push(brandData);
        console.log('Brand added. Total brands:', window.brandSectionBrands.length, brandData);
        showAlert('Brand added successfully', 'success');
    }
    
    console.log('Calling updateBrandSectionBrandsList...');
    updateBrandSectionBrandsList();
    console.log('Brand list updated');
    
    // Reset form and hide - reset fields individually
    $('#brandSectionName').val('');
    $('#brandSectionLink').val('');
    $('#brandSectionDiscount').val('0');
    $('#brandSectionDiscountText').val('');
    $('#brandSectionOrder').val('0');
    $('#brandSectionImageFile').val('');
    $('#brandSectionImageUrl').val('');
    $('#brandSectionEditIndex').val('');
    $('#brandSectionImagePreview').html('<span class="text-muted">No image selected</span>');
    $('#brandSectionAddForm').slideUp(300);
    $('#saveBrandSectionInlineText').text('Add Brand');
}

function editBrandSectionInline(index) {
    if (!window.brandSectionBrands || !window.brandSectionBrands[index]) {
        return;
    }
    
    const brand = window.brandSectionBrands[index];
    
    // Populate form
    $('#brandSectionName').val(brand.name || '');
    $('#brandSectionLink').val(brand.link || '');
    $('#brandSectionDiscount').val(brand.discount || 0);
    $('#brandSectionDiscountText').val(brand.discountText || '');
    $('#brandSectionOrder').val(brand.order || 0);
    $('#brandSectionImageUrl').val(brand.imageUrl || '');
    $('#brandSectionImageFile').val(''); // Clear file input
    $('#brandSectionEditIndex').val(index);
    $('#saveBrandSectionInlineText').text('Update Brand');
    
    // Show image preview
    if (brand.imageUrl) {
        setImagePreview('#brandSectionImagePreview', brand.imageUrl);
    } else {
        $('#brandSectionImagePreview').html('<span class="text-muted">No image selected</span>');
    }
    
    // Show form
    $('#brandSectionAddForm').slideDown(300);
    $('#brandSectionName').focus();
    
    // Scroll to form
    $('html, body').animate({
        scrollTop: $('#brandSectionAddForm').offset().top - 100
    }, 300);
}

function updateBrandSectionBrandsList() {
    const listContainer = $('#brandSectionBrandsList');
    if (!listContainer.length) {
        console.warn('Brand Section Brands List container not found');
        return;
    }
    
    // Ensure brands array exists
    if (typeof window.brandSectionBrands === 'undefined') {
        window.brandSectionBrands = [];
    }
    
    if (!window.brandSectionBrands || window.brandSectionBrands.length === 0) {
        listContainer.html('<p class="text-muted text-center mb-0">No brands added yet. Click "Add Brand" to start.</p>');
        return;
    }
    
    console.log('Updating brand list with', window.brandSectionBrands.length, 'brands');
    
    let html = '<div class="table-responsive"><table class="table table-bordered table-hover mb-0">';
    html += '<thead class="table-light"><tr><th style="width: 60px;">Image</th><th>Brand Name</th><th>Link</th><th>Discount</th><th>Order</th><th style="width: 120px;">Actions</th></tr></thead>';
    html += '<tbody>';
    
    window.brandSectionBrands.forEach((brand, index) => {
        html += `
            <tr>
                <td>
                    <img src="${brand.imageUrl || '/images/placeholder-brand.jpg'}" 
                         alt="${brand.name || 'Brand'}" 
                         class="img-thumbnail" 
                         style="width: 50px; height: 50px; object-fit: contain;">
                </td>
                <td><strong>${brand.name || 'Unnamed Brand'}</strong></td>
                <td><small>${brand.link || '-'}</small></td>
                <td>
                    ${brand.discountText ? `<span class="badge bg-danger">${brand.discountText}</span>` : 
                      (brand.discount > 0 ? `<span class="badge bg-warning">${brand.discount}%</span>` : '-')}
                </td>
                <td>${brand.order || 0}</td>
                <td>
                    <div class="btn-group btn-group-sm">
                        <button type="button" class="btn btn-outline-primary edit-brand-section-item" data-index="${index}" title="Edit">
                            <i class="fas fa-edit"></i>
                        </button>
                        <button type="button" class="btn btn-outline-danger remove-brand-section-item" data-index="${index}" title="Remove">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </td>
            </tr>
        `;
    });
    
    html += '</tbody></table></div>';
    html += `<div class="mt-2"><small class="text-muted">Total: ${window.brandSectionBrands.length} brand(s)</small></div>`;
    listContainer.html(html);
    
    // Attach event handlers
    $('.edit-brand-section-item').off('click').on('click', function() {
        const index = $(this).data('index');
        editBrandSectionInline(index);
    });
    
    $('.remove-brand-section-item').off('click').on('click', function() {
        const index = $(this).data('index');
        if (confirm('Are you sure you want to remove this brand?')) {
            window.brandSectionBrands.splice(index, 1);
            updateBrandSectionBrandsList();
            showAlert('Brand removed successfully', 'success');
        }
    });
    
    console.log('Brand list updated successfully');
}

// Brand Item Modal handlers REMOVED - Using inline form instead

// Helper function to set image preview
function setImagePreview(selector, imageUrl) {
    const preview = $(selector);
    if (imageUrl && imageUrl.trim() !== '') {
        preview.html(`<img src="${imageUrl}" class="img-thumbnail" style="max-width: 100%; max-height: 200px;" onerror="this.parentElement.innerHTML='<span class=\\'text-danger\\'>Failed to load image</span>'">`);
    } else {
        preview.html('<span class="text-muted">No image selected</span>');
    }
}

// Generic function to load sections for location dropdown
async function loadSectionsForLocationGeneric(selectId, preserveValue = null, excludeSectionId = null) {
    try {
        const sections = await $.get('/api/homepage-sections');
        const $locationSelect = $(selectId);
        
        if (!$locationSelect.length) {
            console.warn(`Location select element not found: ${selectId}`);
            return;
        }
        
        // Store current value or use provided value
        const currentValue = preserveValue !== null ? preserveValue : $locationSelect.val();
        
        // Clear and add base options
        $locationSelect.empty();
        $locationSelect.append('<option value="top">Top (Before all sections)</option>');
        
        // Add options for after each section
        if (Array.isArray(sections) && sections.length > 0) {
            const sortedSections = sections
                .filter(s => s.isActive && s.isPublished)
                .sort((a, b) => (a.ordering || 0) - (b.ordering || 0));
            
            sortedSections.forEach((section, index) => {
                const sectionName = section.name || `Section ${index + 1}`;
                const sectionType = getSectionTypeLabel(section.type);
                // Use format "after-section-{id}" to match findBannerTargetElement() expectations
                $locationSelect.append(`<option value="after-section-${section._id}">After "${sectionName}" (${sectionType})</option>`);
            });
        }
        
        $locationSelect.append('<option value="bottom">Bottom (After all sections)</option>');
        
        // Restore previous value if it exists, otherwise default to 'bottom'
        if (currentValue) {
            $locationSelect.val(currentValue);
            // If value doesn't exist in options (e.g., section was deleted), add it as a disabled option
            if (!$locationSelect.val() && currentValue) {
                const optionText = currentValue.startsWith('after-') 
                    ? `After Section (ID: ${currentValue.replace('after-', '')}) - Section may have been deleted`
                    : currentValue;
                $locationSelect.append(`<option value="${currentValue}" selected disabled>${optionText} (Section may have been deleted)</option>`);
            }
        } else {
            $locationSelect.val('bottom');
        }
        
        console.log('Banner location dropdown loaded. Current value:', $locationSelect.val());
    } catch (error) {
        console.error('Error loading sections for location:', error);
        // Fallback to default options if API fails
        const $locationSelect = $('#configBannerLocation');
        if ($locationSelect.children().length === 0) {
            $locationSelect.html(`
                <option value="top">Top (Before all sections)</option>
                <option value="bottom" selected>Bottom (After all sections)</option>
            `);
        }
    }
}

async function loadSectionsForLocationAnnouncement(preserveValue = null) {
    try {
        const sections = await $.get('/api/homepage-sections');
        const $locationSelect = $('#configAnnouncementLocation');
        
        // Store current value or use provided value
        const currentValue = preserveValue !== null ? preserveValue : $locationSelect.val();
        
        // Clear and add base options
        $locationSelect.empty();
        $locationSelect.append('<option value="top">Top (Before all sections)</option>');
        
        // Add options for after each section
        if (Array.isArray(sections) && sections.length > 0) {
            const sortedSections = sections
                .filter(s => s.isActive && s.isPublished)
                .sort((a, b) => (a.ordering || 0) - (b.ordering || 0));
            
            sortedSections.forEach((section, index) => {
                const sectionName = section.name || `Section ${index + 1}`;
                const sectionType = getSectionTypeLabel(section.type);
                $locationSelect.append(`<option value="after-section-${section._id}">After "${sectionName}" (${sectionType})</option>`);
            });
        }
        
        $locationSelect.append('<option value="bottom">Bottom (After all sections)</option>');
        
        // Restore previous value if it exists, otherwise default to 'top'
        if (currentValue) {
            $locationSelect.val(currentValue);
            if (!$locationSelect.val() && currentValue) {
                const optionText = currentValue.startsWith('after-') 
                    ? `After Section (ID: ${currentValue.replace('after-', '')}) - Section may have been deleted`
                    : currentValue;
                $locationSelect.append(`<option value="${currentValue}" selected disabled>${optionText} (Section may have been deleted)</option>`);
            }
        } else {
            $locationSelect.val('top');
        }
    } catch (error) {
        console.error('Error loading sections for announcement location:', error);
        // Fallback to default options if API fails
        const $locationSelect = $('#configAnnouncementLocation');
        if ($locationSelect && $locationSelect.children().length === 0) {
            $locationSelect.html(`
                <option value="top" selected>Top (Before all sections)</option>
                <option value="bottom">Bottom (After all sections)</option>
            `);
        }
    }
}

async function loadSectionsForLocationHeroSlider(preserveValue = null) {
    try {
        const sections = await $.get('/api/homepage-sections');
        const $locationSelect = $('#configHeroSliderLocation');
        
        // Store current value or use provided value
        const currentValue = preserveValue !== null ? preserveValue : $locationSelect.val();
        
        // Clear and add base options
        $locationSelect.empty();
        $locationSelect.append('<option value="top">Top (Before all sections)</option>');
        
        // Add options for after each section
        if (Array.isArray(sections) && sections.length > 0) {
            const sortedSections = sections
                .filter(s => s.isActive && s.isPublished)
                .sort((a, b) => (a.ordering || 0) - (b.ordering || 0));
            
            sortedSections.forEach((section, index) => {
                const sectionName = section.name || `Section ${index + 1}`;
                const sectionType = getSectionTypeLabel(section.type);
                $locationSelect.append(`<option value="after-section-${section._id}">After "${sectionName}" (${sectionType})</option>`);
            });
        }
        
        $locationSelect.append('<option value="bottom">Bottom (After all sections)</option>');
        
        // Restore previous value if it exists, otherwise default to 'top'
        if (currentValue) {
            $locationSelect.val(currentValue);
            if (!$locationSelect.val() && currentValue) {
                const optionText = currentValue.startsWith('after-') 
                    ? `After Section (ID: ${currentValue.replace('after-', '')}) - Section may have been deleted`
                    : currentValue;
                $locationSelect.append(`<option value="${currentValue}" selected disabled>${optionText} (Section may have been deleted)</option>`);
            }
        } else {
            $locationSelect.val('top');
        }
    } catch (error) {
        console.error('Error loading sections for hero slider location:', error);
        // Fallback to default options if API fails
        const $locationSelect = $('#configHeroSliderLocation');
        if ($locationSelect && $locationSelect.children().length === 0) {
            $locationSelect.html(`
                <option value="top" selected>Top (Before all sections)</option>
                <option value="bottom">Bottom (After all sections)</option>
            `);
        }
    }
}

async function loadVideoBannersForConfig() {
    try {
        const videoBanners = await $.get('/api/admin/video-banners');
        let html = '<option value="">Auto (First Active Video Banner)</option>';
        videoBanners.forEach(videoBanner => {
            if (videoBanner.isActive) {
                html += `<option value="${videoBanner._id}">${videoBanner.title} (${videoBanner.videoType || 'youtube'})</option>`;
            }
        });
        $('#configVideoBannerId').html(html);
    } catch (error) {
        console.error('Error loading video banners for config:', error);
    }
}

// Load homepage sections and populate banner position dropdown dynamically
async function loadBannerPositions(preserveValue = null) {
    try {
        const sections = await $.get('/api/homepage-sections');
        const $positionSelect = $('#bannerPosition');
        
        // Store current value or use provided value
        const currentValue = preserveValue !== null ? preserveValue : $positionSelect.val();
        
        // Clear existing options
        $positionSelect.empty();
        
        // Add standard positions
        $positionSelect.append('<option value="top">Top Section (Near top of page)</option>');
        $positionSelect.append('<option value="after-hero">After Hero Slider (Immediately after main slider)</option>');
        
        // Add dynamic positions based on homepage sections
        if (Array.isArray(sections) && sections.length > 0) {
            // Sort sections by ordering
            const sortedSections = sections
                .filter(s => s.isActive && s.isPublished)
                .sort((a, b) => (a.ordering || 0) - (b.ordering || 0));
            
            // Add option for each section
            sortedSections.forEach(section => {
                const sectionName = section.name || `Section ${section.ordering || 0}`;
                const sectionType = section.type || 'unknown';
                const positionValue = `after-section-${section._id}`;
                $positionSelect.append(`<option value="${positionValue}">After "${sectionName}" (${getSectionTypeLabel(sectionType)})</option>`);
            });
        }
        
        // Add remaining standard positions
        $positionSelect.append('<option value="after-categories">After Category Sections</option>');
        $positionSelect.append('<option value="middle">Middle Section (Between product sections)</option>');
        $positionSelect.append('<option value="before-footer">Before Footer Section</option>');
        $positionSelect.append('<option value="bottom">Bottom Section (At end of page)</option>');
        
        // Restore previous value if it exists, otherwise default to 'middle'
        if (currentValue) {
            $positionSelect.val(currentValue);
        } else {
            $positionSelect.val('middle');
        }
    } catch (error) {
        console.error('Error loading banner positions:', error);
        // Fallback to default options if API fails
        const $positionSelect = $('#bannerPosition');
        if ($positionSelect.children().length === 0) {
            $positionSelect.html(`
                <option value="top">Top Section (Near top of page)</option>
                <option value="after-hero">After Hero Slider (Immediately after main slider)</option>
                <option value="after-categories">After Category Sections</option>
                <option value="middle" selected>Middle Section (Between product sections)</option>
                <option value="before-footer">Before Footer Section</option>
                <option value="bottom">Bottom Section (At end of page)</option>
            `);
        }
    }
}

async function saveHomepageSection() {
    const id = $('#homepageSectionId').val();
    const method = id ? 'PUT' : 'POST';
    const url = id ? `/api/homepage-sections/${id}` : '/api/homepage-sections';
    let payload = null; // Declare payload outside try block for error handling
    
    try {
        // Show loading state
        const saveBtn = $('#saveHomepageSection');
        const originalText = saveBtn.html();
        saveBtn.prop('disabled', true).html('<i class="fas fa-spinner fa-spin"></i> Saving...');
        const sectionType = $('#homepageSectionType').val();
        
        // Handle banner image upload BEFORE building config (if file is selected)
        if (sectionType === 'bannerFullWidth') {
            const bannerImageFile = $('#configBannerImageFile')[0]?.files?.[0];
            const imageUrl = $('#configBannerImageUrl').val()?.trim();
            const sizeMode = $('#configBannerSizeMode').val() || 'auto';
            
            // Validate that at least image URL or file is provided
            if (!bannerImageFile && !imageUrl) {
                showAlert('Banner image is required. Please upload an image file or enter an image URL.', 'warning');
                saveBtn.prop('disabled', false).html(originalText);
                return;
            }
            
            // Upload image if file is provided
            if (bannerImageFile) {
                try {
                    console.log('Uploading banner image to Cloudinary...');
                    const uploadResult = await uploadImageIfNeeded('#configBannerImageFile', 'banners');
                    if (uploadResult && uploadResult.url) {
                        $('#configBannerImageUrl').val(uploadResult.url); // Update URL field with Cloudinary URL
                        console.log('Banner image uploaded successfully:', uploadResult.url);
                    } else {
                        showAlert('Failed to upload banner image. Please try again.', 'danger');
                        saveBtn.prop('disabled', false).html(originalText);
                        return;
                    }
                } catch (error) {
                    console.error('Error uploading banner image:', error);
                    showAlert('Error uploading banner image: ' + (error.message || 'Unknown error'), 'danger');
                    saveBtn.prop('disabled', false).html(originalText);
                    return;
                }
            }
        }

        // Handle video banner upload BEFORE building config (if file is selected)
        if (sectionType === 'videoBanner') {
            const videoType = $('#configVideoType').val();
            const videoFile = $('#configVideoFile')[0]?.files?.[0];
            const videoUrl = $('#configVideoUrl').val()?.trim();
            
            // Validate that at least video URL or file is provided
            if (videoType === 'file') {
                if (!videoFile) {
                    showAlert('Video file is required. Please upload a video file.', 'warning');
                    saveBtn.prop('disabled', false).html(originalText);
                    return;
                }
                
                // Upload video if file is provided
                try {
                    console.log('Uploading video to Cloudinary...');
                    const uploadResult = await uploadVideoIfNeeded('#configVideoFile', 'videos');
                    if (uploadResult && uploadResult.url) {
                        $('#configVideoUrl').val(uploadResult.url); // Update URL field with Cloudinary URL
                        $('#configVideoFileId').val(uploadResult._id || ''); // Store media ID
                        console.log('Video uploaded successfully:', uploadResult.url);
                    } else {
                        showAlert('Failed to upload video. Please try again.', 'danger');
                        saveBtn.prop('disabled', false).html(originalText);
                        return;
                    }
                } catch (error) {
                    console.error('Error uploading video:', error);
                    showAlert('Error uploading video: ' + (error.message || 'Unknown error'), 'danger');
                    saveBtn.prop('disabled', false).html(originalText);
                    return;
                }
            } else {
                // For URL-based videos, validate URL is provided
                if (!videoUrl) {
                    showAlert('Video URL is required. Please enter a YouTube, Vimeo, or direct video URL.', 'warning');
                    saveBtn.prop('disabled', false).html(originalText);
                    return;
                }
            }

            // Handle poster image upload if file is provided
            const posterFile = $('#configVideoPosterFile')[0]?.files?.[0];
            if (posterFile) {
                try {
                    console.log('Uploading poster image to Cloudinary...');
                    const uploadResult = await uploadImageIfNeeded('#configVideoPosterFile', 'video-posters');
                    if (uploadResult && uploadResult.url) {
                        $('#configVideoPosterUrl').val(uploadResult.url); // Update URL field with Cloudinary URL
                        $('#configVideoPosterFileId').val(uploadResult._id || ''); // Store media ID
                        console.log('Poster image uploaded successfully:', uploadResult.url);
                    }
                } catch (error) {
                    console.error('Error uploading poster image:', error);
                    // Don't block save if poster upload fails, just log it
                }
            }
        }
        
        const config = buildHomepageSectionConfig(sectionType);
        
        // Brand Marquee now uses Brand Logos automatically - no image upload needed
        // Brands are fetched from /api/brands/public endpoint
        
        // Validate required fields
        const sectionName = $('#homepageSectionName').val()?.trim();
        if (!sectionName) {
            showAlert('Section name is required', 'warning');
            return;
        }
        
        if (!sectionType) {
            showAlert('Section type is required', 'warning');
            return;
        }
        
        payload = {
            name: sectionName,
            type: sectionType,
            title: $('#homepageSectionTitle').val()?.trim() || undefined,
            subtitle: $('#homepageSectionSubtitle').val()?.trim() || undefined,
            description: $('#homepageSectionDescription').val()?.trim() || undefined,
            config: config,
            ordering: parseInt($('#homepageSectionOrdering').val(), 10) || 0,
            isActive: $('#homepageSectionActive').is(':checked'),
            isPublished: $('#homepageSectionPublished').is(':checked'),
            displayOn: {
                desktop: $('#homepageSectionDisplayDesktop').is(':checked'),
                tablet: $('#homepageSectionDisplayTablet').is(':checked'),
                mobile: $('#homepageSectionDisplayMobile').is(':checked')
            }
        };
        
        // Remove undefined values to avoid sending them
        Object.keys(payload).forEach(key => {
            if (payload[key] === undefined) {
                delete payload[key];
            }
        });
        
        console.log('Saving homepage section with payload:', JSON.stringify(payload, null, 2));
        
        const savedSection = await $.ajax({
            url,
            method,
            contentType: 'application/json',
            data: JSON.stringify(payload)
        });
        
        // Restore button state
        saveBtn.prop('disabled', false).html(originalText);
        
        $('#homepageSectionModal').modal('hide');
        showAlert(id ? 'Homepage section updated successfully' : 'Homepage section added successfully', 'success');
        
        // DON'T clear brand section brands array after save - keep them for potential re-edit
        // The array will be properly loaded from config when editing
        
        loadHomepageSections();
        
        // Force reload homepage if on homepage
        if (window.location.pathname === '/' || window.location.pathname === '/index.html') {
            console.log('Reloading homepage to show updated brand marquee...');
            setTimeout(() => {
                window.location.reload();
            }, 1000);
        }
    } catch (error) {
        console.error('Error saving homepage section', error);
        console.error('Error details:', {
            status: error.status,
            statusText: error.statusText,
            responseJSON: error.responseJSON,
            responseText: error.responseText
        });
        
        // Restore button state on error
        const saveBtn = $('#saveHomepageSection');
        saveBtn.prop('disabled', false).html('<i class="fas fa-save"></i> Save Section');
        
        // Extract detailed error message
        let message = 'Error saving homepage section';
        let fullErrorDetails = '';
        
        if (error.responseJSON) {
            if (error.responseJSON.message) {
                message = error.responseJSON.message;
            } else if (error.responseJSON.error) {
                message = error.responseJSON.error;
            } else {
                message = JSON.stringify(error.responseJSON);
            }
            
            // Include validation errors if present
            if (error.responseJSON.errors) {
                const errorList = Object.entries(error.responseJSON.errors)
                    .map(([field, msg]) => `${field}: ${msg}`)
                    .join(', ');
                message += ` (${errorList})`;
            }
            
            // Include details if present
            if (error.responseJSON.details) {
                fullErrorDetails = error.responseJSON.details;
            }
        } else if (error.responseText) {
            try {
                const parsed = JSON.parse(error.responseText);
                message = parsed.message || parsed.error || error.responseText;
                if (parsed.errors) {
                    const errorList = Object.entries(parsed.errors)
                        .map(([field, msg]) => `${field}: ${msg}`)
                        .join(', ');
                    message += ` (${errorList})`;
                }
                if (parsed.details) {
                    fullErrorDetails = parsed.details;
                }
            } catch (e) {
                message = error.responseText;
            }
        } else if (error.message) {
            message = error.message;
        }
        
        // Log full error for debugging
        console.error('Full error response:', {
            status: error.status,
            statusText: error.statusText,
            responseJSON: error.responseJSON,
            responseText: error.responseText,
            payload: payload,
            message: message,
            details: fullErrorDetails
        });
        
        showAlert(message, 'danger');
    }
}

function buildHomepageSectionConfig(sectionType) {
    const config = {};
    
    switch(sectionType) {
        case 'heroSlider':
            const sliderIds = [];
            $('input[name="sliderIds"]:checked').each(function() {
                sliderIds.push($(this).val());
            });
            config.sliderIds = sliderIds;
            config.autoplay = $('#configAutoplay').is(':checked');
            config.autoplayInterval = parseInt($('#configAutoplaySpeed').val(), 10) || 3000;
            config.autoplaySpeed = parseInt($('#configAutoplaySpeed').val(), 10) || 3000; // Keep for backward compatibility
            config.showArrows = $('#configShowArrows').is(':checked');
            config.showDots = $('#configShowDots').is(':checked');
            // Location
            const heroSliderLocation = $('#configHeroSliderLocation').val() || 'top';
            config.location = heroSliderLocation;
            break;
            
        case 'scrollingText':
            const textItems = $('#configTextItems').val().split('\n').filter(item => item.trim());
            config.items = textItems;
            config.scrollSpeed = parseInt($('#configScrollSpeed').val(), 10) || 20;
            config.backgroundColor = $('#configBgColor').val() || '#c42525';
            config.textColor = $('#configTextColor').val() || '#ffffff';
            // Location
            const announcementLocation = $('#configAnnouncementLocation').val() || 'top';
            config.location = announcementLocation;
            break;
            
        case 'categoryFeatured':
        case 'categoryGrid':
            const categoryIds = [];
            $('input[name="categoryIds"]:checked').each(function() {
                categoryIds.push($(this).val());
            });
            config.categoryIds = categoryIds;
            config.gridColumns = parseInt($('#configGridColumns').val(), 10) || 4;
            config.showTitle = $('#configShowTitle').is(':checked');
            // Location
            const categoryGridLocation = $('#configCategoryGridLocation').val() || 'bottom';
            config.location = categoryGridLocation;
            break;
            
        case 'categoryCircles':
            const categoryCircleIds = [];
            $('input[name="categoryIds"]:checked').each(function() {
                categoryCircleIds.push($(this).val());
            });
            config.categoryIds = categoryCircleIds;
            config.showTitle = $('#configShowTitle')?.is(':checked') !== undefined ? $('#configShowTitle').is(':checked') : true;
            // Location
            const categoryCirclesLocation = $('#configCategoryCirclesLocation').val() || 'bottom';
            config.location = categoryCirclesLocation;
            break;
            
        case 'departmentGrid':
            const departmentIds = [];
            $('input[name="departmentIds"]:checked').each(function() {
                departmentIds.push($(this).val());
            });
            config.departmentIds = departmentIds;
            config.gridColumns = parseInt($('#configGridColumns').val(), 10) || 4;
            config.limit = parseInt($('#configLimit').val(), 10) || 8;
            config.showTitle = $('#configShowTitle').is(':checked');
            // Location
            const departmentGridLocation = $('#configDepartmentGridLocation').val() || 'bottom';
            config.location = departmentGridLocation;
            break;
            
        case 'productTabs':
            try {
                const tabsText = $('#configTabs').val().trim();
                if (tabsText) {
                    config.tabs = JSON.parse(tabsText);
                }
            } catch (e) {
                // Default tabs if invalid JSON
                config.tabs = [
                    {label: 'New Arrivals', filter: {isNewArrival: true}, limit: 8},
                    {label: 'Featured', filter: {isFeatured: true}, limit: 8}
                ];
            }
            config.categoryId = $('#configCategoryId').val() || null;
            config.showViewAll = $('#configShowViewAll').is(':checked');
            // Location
            const productTabsLocation = $('#configProductTabsLocation').val() || 'bottom';
            config.location = productTabsLocation;
            break;
            
        case 'productCarousel':
            config.categoryId = $('#configCategoryId').val() || null;
            config.limit = parseInt($('#configLimit').val(), 10) || 10;
            if ($('#configIsFeatured').is(':checked')) config.isFeatured = true;
            if ($('#configIsNewArrival').is(':checked')) config.isNewArrival = true;
            if ($('#configIsTrending').is(':checked')) config.isTrending = true;
            config.autoplay = $('#configAutoplay').is(':checked');
            // Location
            const productCarouselLocation = $('#configProductCarouselLocation').val() || 'bottom';
            config.location = productCarouselLocation;
            break;
            
        case 'newArrivals':
            config.categoryId = $('#configCategoryId').val() || null;
            config.limit = parseInt($('#configLimit').val(), 10) || 20;
            // Location
            const newArrivalsLocation = $('#configNewArrivalsLocation').val() || 'bottom';
            config.location = newArrivalsLocation;
            break;
            
        case 'topSelling':
            config.categoryId = $('#configCategoryId').val() || null;
            config.limit = parseInt($('#configLimit').val(), 10) || 20;
            // Location
            const topSellingLocation = $('#configTopSellingLocation').val() || 'bottom';
            config.location = topSellingLocation;
            break;
            
        case 'featuredCollections':
            // No configuration needed - displays all active subcategories
            // Location
            const featuredCollectionsLocation = $('#configFeaturedCollectionsLocation').val() || 'bottom';
            config.location = featuredCollectionsLocation;
            break;
            
        case 'subcategoryGrid':
            const gridSubcategoryIds = [];
            $('input[name="gridSubcategoryIds"]:checked').each(function() {
                gridSubcategoryIds.push($(this).val());
            });
            // Always include subcategoryIds and buttonSubcategoryIds, even if empty
            config.subcategoryIds = gridSubcategoryIds.slice(0, 6); // Limit to 6
            
            const buttonSubcategoryIds = [];
            $('input[name="buttonSubcategoryIds"]:checked').each(function() {
                buttonSubcategoryIds.push($(this).val());
            });
            config.buttonSubcategoryIds = buttonSubcategoryIds.length > 0 ? buttonSubcategoryIds : [];
            // Location
            const subcategoryGridLocation = $('#configSubcategoryGridLocation').val() || 'bottom';
            config.location = subcategoryGridLocation;
            break;
            
        case 'bannerFullWidth':
            // Image URL or uploaded image
            const bannerImageUrl = $('#configBannerImageUrl').val()?.trim();
            if (bannerImageUrl) {
                config.imageUrl = bannerImageUrl;
            }
            // Banner ID (legacy support)
            const bannerId = $('#configBannerId').val();
            if (bannerId) {
                config.bannerId = bannerId;
            }
            // Location/Position - Always save location, default to 'bottom' if not set
            const location = $('#configBannerLocation').val() || 'bottom';
            config.location = location;
            console.log('Saving banner location:', location);
            
            // Size Mode
            const sizeMode = $('#configBannerSizeMode').val() || 'auto';
            config.sizingMode = sizeMode;
            
            // Custom dimensions (only if size mode is 'custom')
            if (sizeMode === 'custom') {
                const customWidth = $('#configBannerCustomWidth').val()?.trim();
                if (customWidth) {
                    config.customWidth = parseInt(customWidth, 10);
                }
                const customHeight = $('#configBannerCustomHeight').val()?.trim();
                if (customHeight) {
                    config.customHeight = parseInt(customHeight, 10);
                }
                // Responsive heights
                const mobileHeight = $('#configBannerMobileHeight').val()?.trim();
                if (mobileHeight) {
                    config.mobileHeight = parseInt(mobileHeight, 10);
                }
                const tabletHeight = $('#configBannerTabletHeight').val()?.trim();
                if (tabletHeight) {
                    config.tabletHeight = parseInt(tabletHeight, 10);
                }
                const desktopHeight = $('#configBannerDesktopHeight').val()?.trim();
                if (desktopHeight) {
                    config.desktopHeight = parseInt(desktopHeight, 10);
                }
            }
            
            // Link
            const bannerLink = $('#configBannerLink').val()?.trim();
            if (bannerLink) {
                config.link = bannerLink;
            }
            break;
            
        case 'videoBanner':
            // Video source
            const videoType = $('#configVideoType').val() || 'direct';
            config.videoType = videoType;

            // Video URL (from upload or direct input) - always save URL to database
            const videoUrl = $('#configVideoUrl').val()?.trim();
            if (videoUrl) {
                config.videoUrl = videoUrl; // Save URL to database
            }

            // Store file ID if uploaded (for reference)
            const videoFileId = $('#configVideoFileId').val();
            if (videoFileId) {
                config.videoFileId = videoFileId;
            }

            // Poster image URL (from upload or direct input) - always save URL to database
            const posterUrl = $('#configVideoPosterUrl').val()?.trim();
            if (posterUrl) {
                config.posterImage = posterUrl; // Save URL to database
            }

            // Store poster file ID if uploaded (for reference)
            const posterFileId = $('#configVideoPosterFileId').val();
            if (posterFileId) {
                config.posterFileId = posterFileId;
            }

            // Video settings
            config.autoplay = $('#configVideoAutoplay').is(':checked');
            config.loop = $('#configVideoLoop').is(':checked');
            config.muted = $('#configVideoMuted').is(':checked');
            config.controls = $('#configVideoControls').is(':checked');

            // Overlay content
            const overlayText = $('#configOverlayText').val()?.trim();
            if (overlayText) {
                config.overlayText = overlayText;
            }
            const overlayDescription = $('#configOverlayDescription').val()?.trim();
            if (overlayDescription) {
                config.overlayDescription = overlayDescription;
            }
            const ctaText = $('#configCtaText').val()?.trim();
            if (ctaText) {
                config.ctaText = ctaText;
            }
            const ctaLink = $('#configCtaLink').val()?.trim();
            if (ctaLink) {
                config.ctaLink = ctaLink;
            }

            // Location
            const videoBannerLocation = $('#configVideoBannerLocation').val() || 'bottom';
            config.location = videoBannerLocation;
            break;
            
        case 'newsletterSocial':
            config.socialTitle = $('#configSocialTitle').val() || '';
            config.socialDesc = $('#configSocialDesc').val() || '';
            config.newsletterTitle = $('#configNewsletterTitle').val() || '';
            config.newsletterDesc = $('#configNewsletterDesc').val() || '';
            const fbUrl = ($('#configFacebookUrl').val() || '').trim();
            const igUrl = ($('#configInstagramUrl').val() || '').trim();
            const links = [];
            if (fbUrl) {
                links.push({ platform: 'Facebook', url: fbUrl, iconClass: 'fab fa-facebook-f' });
            }
            if (igUrl) {
                links.push({ platform: 'Instagram', url: igUrl, iconClass: 'fab fa-instagram' });
            }
            if (links.length > 0) {
                config.socialLinks = links;
            }
            // Location
            const newsletterSocialLocation = $('#configNewsletterSocialLocation').val() || 'bottom';
            config.location = newsletterSocialLocation;
            break;
            
        case 'customHTML':
            config.html = $('#configCustomHTML').val() || '';
            // Location
            const customHTMLLocation = $('#configCustomHTMLLocation').val() || 'bottom';
            config.location = customHTMLLocation;
            break;
            
        case 'brandGrid':
            config.limit = parseInt($('#configBrandGridLimit').val(), 10) || 10;
            // Location
            const brandGridLocation = $('#configBrandGridLocation').val() || 'bottom';
            config.location = brandGridLocation;
            break;
            
        case 'brandSection':
            // Validate brands array
            console.log('Building config for brandSection. Current brands:', window.brandSectionBrands);
            if (!window.brandSectionBrands || window.brandSectionBrands.length === 0) {
                showAlert('Please add at least one brand', 'warning');
                return null;
            }
            
            // Validate each brand has required fields
            for (let i = 0; i < window.brandSectionBrands.length; i++) {
                const brand = window.brandSectionBrands[i];
                if (!brand.name || !brand.name.trim()) {
                    showAlert(`Brand ${i + 1}: Name is required`, 'warning');
                    return null;
                }
                if (!brand.imageUrl || !brand.imageUrl.trim()) {
                    showAlert(`Brand ${i + 1}: Image is required`, 'warning');
                    return null;
                }
            }
            
            config.brands = window.brandSectionBrands.map(b => ({
                name: b.name.trim(),
                imageUrl: b.imageUrl.trim(),
                imageFileId: b.imageFileId || undefined,
                link: b.link ? b.link.trim() : undefined,
                discount: b.discount ? parseFloat(b.discount) : 0,
                discountText: b.discountText ? b.discountText.trim() : '',
                order: b.order ? parseInt(b.order, 10) : 0
            }));
            
            console.log('Brands being saved to config:', config.brands);
            
            // Location
            const brandSectionLocation = $('#configBrandSectionLocation').val() || 'bottom';
            config.location = brandSectionLocation;
            break;
            
        case 'collectionLinks':
        case 'categoryCircles':
            // These section types may not have specific config fields yet
            // Return empty config object - they can be configured later
            break;
            
        default:
            console.warn(`No config builder for section type: ${sectionType}`);
            // Return empty config for unknown types
            break;
    }
    
    return config;
}

async function editHomepageSection(id) {
    try {
        console.log(`📝 Loading section ${id} for editing...`);
        const section = await $.get(`/api/homepage-sections/${id}`);
        
        console.log('Section loaded:', {
            id: section._id,
            name: section.name,
            type: section.type,
            hasConfig: !!section.config,
            brandImagesCount: section.config?.brandImages?.length || 0
        });
        
        $('#homepageSectionId').val(section._id);
        $('#homepageSectionName').val(section.name || '');
        $('#homepageSectionType').val(section.type || '');
        $('#homepageSectionTitle').val(section.title || '');
        $('#homepageSectionSubtitle').val(section.subtitle || '');
        $('#homepageSectionDescription').val(section.description || '');
        $('#homepageSectionOrdering').val(section.ordering !== undefined ? section.ordering : 0);
        $('#homepageSectionActive').prop('checked', section.isActive !== undefined ? section.isActive : true);
        $('#homepageSectionPublished').prop('checked', section.isPublished !== undefined ? section.isPublished : false);
        
        if (section.displayOn) {
            $('#homepageSectionDisplayDesktop').prop('checked', section.displayOn.desktop !== false);
            $('#homepageSectionDisplayTablet').prop('checked', section.displayOn.tablet !== false);
            $('#homepageSectionDisplayMobile').prop('checked', section.displayOn.mobile !== false);
        }
        
        // Load config for this section type
        loadHomepageSectionConfig(section.type);
        
        // Populate config fields (with longer delay for brandSection to ensure DOM is ready)
        if (section.config) {
            const delay = section.type === 'brandSection' ? 1000 : 500;
            console.log(`⏳ Will populate config for ${section.type} after ${delay}ms delay...`);
            setTimeout(async () => {
                console.log(`✅ Now populating config for ${section.type}...`);
                console.log('Config to populate:', JSON.stringify(section.config, null, 2));
                await populateHomepageSectionConfig(section.type, section.config);
            }, delay);
        } else {
            // For new sections or sections without config, initialize empty config
            console.log(`ℹ️ No config found in section (new section or empty config). Initializing...`);
            if (section.type === 'brandSection') {
                // Initialize brand section with empty brands array
                setTimeout(async () => {
                    await populateHomepageSectionConfig(section.type, { brands: [], location: 'bottom' });
                }, 1000);
            }
        }
        
        $('#homepageSectionModalTitle').text('Edit Homepage Section');
        $('#homepageSectionModal').modal('show');
    } catch (error) {
        console.error('❌ Error loading homepage section', error);
        showAlert('Error loading homepage section', 'danger');
    }
}

async function populateHomepageSectionConfig(sectionType, config) {
    switch(sectionType) {
        case 'heroSlider':
            if (config.sliderIds) {
                config.sliderIds.forEach(id => {
                    $(`#slider_${id}`).prop('checked', true);
                });
            }
            if (config.autoplay !== undefined) $('#configAutoplay').prop('checked', config.autoplay);
            // Support both autoplaySpeed and autoplayInterval for backward compatibility
            const autoplaySpeed = config.autoplayInterval || config.autoplaySpeed || 3000;
            $('#configAutoplaySpeed').val(autoplaySpeed);
            if (config.showArrows !== undefined) $('#configShowArrows').prop('checked', config.showArrows);
            if (config.showDots !== undefined) $('#configShowDots').prop('checked', config.showDots);
            // Load location dropdown and restore saved location
            const savedHeroSliderLocation = config.location || 'top';
            await loadSectionsForLocationHeroSlider(savedHeroSliderLocation);
            break;
            
        case 'scrollingText':
            if (config.items) $('#configTextItems').val(config.items.join('\n'));
            if (config.scrollSpeed) $('#configScrollSpeed').val(config.scrollSpeed);
            if (config.backgroundColor) $('#configBgColor').val(config.backgroundColor);
            if (config.textColor) $('#configTextColor').val(config.textColor);
            // Load location dropdown and restore saved location
            const savedAnnouncementLocation = config.location || 'top';
            await loadSectionsForLocationAnnouncement(savedAnnouncementLocation);
            break;
            
        case 'categoryFeatured':
        case 'categoryGrid':
            if (config.categoryIds) {
                config.categoryIds.forEach(id => {
                    $(`#category_${id}`).prop('checked', true);
                });
            }
            if (config.gridColumns) $('#configGridColumns').val(config.gridColumns);
            if (config.showTitle !== undefined) $('#configShowTitle').prop('checked', config.showTitle);
            // Load location dropdown and restore saved location
            const savedCategoryGridLocation = config.location || 'bottom';
            await loadSectionsForLocationGeneric('#configCategoryGridLocation', savedCategoryGridLocation);
            break;
            
        case 'categoryCircles':
            if (config.categoryIds) {
                config.categoryIds.forEach(id => {
                    $(`#category_${id}`).prop('checked', true);
                });
            }
            if (config.showTitle !== undefined && $('#configShowTitle').length) {
                $('#configShowTitle').prop('checked', config.showTitle);
            }
            // Load location dropdown and restore saved location
            const savedCategoryCirclesLocation = config.location || 'bottom';
            await loadSectionsForLocationGeneric('#configCategoryCirclesLocation', savedCategoryCirclesLocation);
            break;
            
        case 'departmentGrid':
            if (config.departmentIds) {
                config.departmentIds.forEach(id => {
                    $(`#department_${id}`).prop('checked', true);
                });
            }
            if (config.gridColumns) $('#configGridColumns').val(config.gridColumns);
            if (config.limit) $('#configLimit').val(config.limit);
            if (config.showTitle !== undefined) $('#configShowTitle').prop('checked', config.showTitle);
            // Load location dropdown and restore saved location
            const savedDepartmentGridLocation = config.location || 'bottom';
            await loadSectionsForLocationGeneric('#configDepartmentGridLocation', savedDepartmentGridLocation);
            break;
            
        case 'productTabs':
            if (config.tabs) $('#configTabs').val(JSON.stringify(config.tabs, null, 2));
            if (config.categoryId) $('#configCategoryId').val(config.categoryId);
            if (config.showViewAll !== undefined) $('#configShowViewAll').prop('checked', config.showViewAll);
            // Load location dropdown and restore saved location
            const savedProductTabsLocation = config.location || 'bottom';
            await loadSectionsForLocationGeneric('#configProductTabsLocation', savedProductTabsLocation);
            break;
            
        case 'productCarousel':
            if (config.categoryId) $('#configCategoryId').val(config.categoryId);
            if (config.limit) $('#configLimit').val(config.limit);
            if (config.isFeatured) $('#configIsFeatured').prop('checked', true);
            if (config.isNewArrival) $('#configIsNewArrival').prop('checked', true);
            if (config.isTrending) $('#configIsTrending').prop('checked', true);
            if (config.autoplay !== undefined) $('#configAutoplay').prop('checked', config.autoplay);
            // Load location dropdown and restore saved location
            const savedProductCarouselLocation = config.location || 'bottom';
            await loadSectionsForLocationGeneric('#configProductCarouselLocation', savedProductCarouselLocation);
            break;
            
        case 'newArrivals':
            if (config.categoryId) $('#configCategoryId').val(config.categoryId);
            if (config.limit) $('#configLimit').val(config.limit);
            // Load location dropdown and restore saved location
            const savedNewArrivalsLocation = config.location || 'bottom';
            await loadSectionsForLocationGeneric('#configNewArrivalsLocation', savedNewArrivalsLocation);
            break;
            
        case 'topSelling':
            if (config.categoryId) $('#configCategoryId').val(config.categoryId);
            if (config.limit) $('#configLimit').val(config.limit);
            // Load location dropdown and restore saved location
            const savedTopSellingLocation = config.location || 'bottom';
            await loadSectionsForLocationGeneric('#configTopSellingLocation', savedTopSellingLocation);
            break;
            
        case 'featuredCollections':
            // No configuration to populate
            // Load location dropdown and restore saved location
            const savedFeaturedCollectionsLocation = config.location || 'bottom';
            await loadSectionsForLocationGeneric('#configFeaturedCollectionsLocation', savedFeaturedCollectionsLocation);
            break;
            
        case 'subcategoryGrid':
            // Store config and reload subcategories with selected IDs
            const gridIds = config.subcategoryIds && Array.isArray(config.subcategoryIds) ? config.subcategoryIds : [];
            const buttonIds = config.buttonSubcategoryIds && Array.isArray(config.buttonSubcategoryIds) ? config.buttonSubcategoryIds : [];
            
            // Reload subcategories with pre-selected IDs
            loadSubcategoriesForConfig(gridIds, buttonIds);
            console.log(`Loading subcategories with ${gridIds.length} grid and ${buttonIds.length} button selections`);
            // Load location dropdown and restore saved location
            const savedSubcategoryGridLocation = config.location || 'bottom';
            await loadSectionsForLocationGeneric('#configSubcategoryGridLocation', savedSubcategoryGridLocation);
            break;
            
        case 'bannerFullWidth':
            // Load sections for location dropdown FIRST, preserving the saved location
            const savedLocation = config.location || 'bottom';
            await loadSectionsForLocationGeneric('#configBannerLocation', savedLocation);
            
            // Image URL
            if (config.imageUrl) {
                $('#configBannerImageUrl').val(config.imageUrl);
                setImagePreview('#configBannerImagePreview', config.imageUrl);
            }
            
            // Location is already set by loadSectionsForLocationGeneric above
            console.log('Banner location restored:', savedLocation, 'Current dropdown value:', $('#configBannerLocation').val());
            
            // Size Mode
            const savedSizeMode = config.sizingMode || 'auto';
            $('#configBannerSizeMode').val(savedSizeMode);
            
            // Custom dimensions (only if size mode is 'custom')
            if (savedSizeMode === 'custom') {
                if (config.customWidth) {
                    $('#configBannerCustomWidth').val(config.customWidth);
                }
                if (config.customHeight) {
                    $('#configBannerCustomHeight').val(config.customHeight);
                }
                if (config.mobileHeight) {
                    $('#configBannerMobileHeight').val(config.mobileHeight);
                }
                if (config.tabletHeight) {
                    $('#configBannerTabletHeight').val(config.tabletHeight);
                }
                if (config.desktopHeight) {
                    $('#configBannerDesktopHeight').val(config.desktopHeight);
                }
                // Show custom dimensions section
                $('#configBannerCustomDimensions').show();
            } else {
                // Hide custom dimensions section
                $('#configBannerCustomDimensions').hide();
            }
            
            // Link
            if (config.link) {
                $('#configBannerLink').val(config.link);
            }
            break;
            
        case 'videoBanner':
            // Video type
            if (config.videoType) {
                $('#configVideoType').val(config.videoType);
            }
            
            // Video URL (from database)
            if (config.videoUrl) {
                $('#configVideoUrl').val(config.videoUrl);
            }
            
            // Video file ID (if uploaded)
            if (config.videoFileId) {
                $('#configVideoFileId').val(config.videoFileId);
            }
            
            // Poster image URL (from database)
            if (config.posterImage) {
                $('#configVideoPosterUrl').val(config.posterImage);
            }
            
            // Poster file ID (if uploaded)
            if (config.posterFileId) {
                $('#configVideoPosterFileId').val(config.posterFileId);
            }
            
            // Video settings
            if (config.autoplay !== undefined) {
                $('#configVideoAutoplay').prop('checked', config.autoplay);
            }
            if (config.loop !== undefined) {
                $('#configVideoLoop').prop('checked', config.loop);
            }
            if (config.muted !== undefined) {
                $('#configVideoMuted').prop('checked', config.muted);
            }
            if (config.controls !== undefined) {
                $('#configVideoControls').prop('checked', config.controls);
            }
            
            // Overlay content
            if (config.overlayText) {
                $('#configOverlayText').val(config.overlayText);
            }
            if (config.overlayDescription) {
                $('#configOverlayDescription').val(config.overlayDescription);
            }
            if (config.ctaText) {
                $('#configCtaText').val(config.ctaText);
            }
            if (config.ctaLink) {
                $('#configCtaLink').val(config.ctaLink);
            }
            
            // Load location dropdown and restore saved location
            const savedVideoBannerLocation = config.location || 'bottom';
            await loadSectionsForLocationGeneric('#configVideoBannerLocation', savedVideoBannerLocation);
            
            // Trigger video type change to show/hide appropriate fields
            setTimeout(() => {
                $('#configVideoType').trigger('change');
                // Show preview if URL exists
                if (config.videoUrl) {
                    const videoType = config.videoType || 'direct';
                    const detectedType = detectVideoTypeFromUrl(config.videoUrl);
                    if (detectedType === 'youtube' || detectedType === 'vimeo') {
                        showVideoEmbedPreview('#configVideoUrlPreview', config.videoUrl, detectedType);
                    }
                }
                // Show poster preview if exists
                if (config.posterImage) {
                    setImagePreview('#configVideoPosterPreview', config.posterImage);
                }
            }, 100);
            break;
            
        case 'newsletterSocial':
            if (config.socialTitle) $('#configSocialTitle').val(config.socialTitle);
            if (config.socialDesc) $('#configSocialDesc').val(config.socialDesc);
            if (config.newsletterTitle) $('#configNewsletterTitle').val(config.newsletterTitle);
            if (config.newsletterDesc) $('#configNewsletterDesc').val(config.newsletterDesc);
            if (config.socialLinks) {
                if (Array.isArray(config.socialLinks)) {
                    const fb = config.socialLinks.find(l => (l.platform||'').toLowerCase()==='facebook');
                    const ig = config.socialLinks.find(l => (l.platform||'').toLowerCase()==='instagram');
                    if (fb && fb.url) $('#configFacebookUrl').val(fb.url);
                    if (ig && ig.url) $('#configInstagramUrl').val(ig.url);
                } else if (typeof config.socialLinks === 'object' && config.socialLinks !== null) {
                    if (config.socialLinks.facebook) $('#configFacebookUrl').val(config.socialLinks.facebook);
                    if (config.socialLinks.instagram) $('#configInstagramUrl').val(config.socialLinks.instagram);
                }
            }
            // Load location dropdown and restore saved location
            const savedNewsletterSocialLocation = config.location || 'bottom';
            await loadSectionsForLocationGeneric('#configNewsletterSocialLocation', savedNewsletterSocialLocation);
            break;
            
        case 'brandSection':
            console.log('Populating Brand Section config:', config);
            // Initialize brands array
            if (typeof window.brandSectionBrands === 'undefined') {
                window.brandSectionBrands = [];
            }
            
            // Load brands from config
            if (config && config.brands && Array.isArray(config.brands) && config.brands.length > 0) {
                console.log('Loading', config.brands.length, 'brands from config');
                window.brandSectionBrands = config.brands.map(b => ({
                    name: b.name || '',
                    imageUrl: b.imageUrl || '',
                    imageFileId: b.imageFileId || null,
                    link: b.link || '',
                    discount: b.discount || 0,
                    discountText: b.discountText || '',
                    order: b.order || 0
                }));
                console.log('Brands loaded:', window.brandSectionBrands);
            } else {
                console.log('No brands found in config, initializing empty array');
                window.brandSectionBrands = [];
            }
            
            // Wait a bit for DOM to be ready, then update the list
            setTimeout(() => {
                updateBrandSectionBrandsList();
            }, 300);
            
            // Load location dropdown and restore saved location
            const savedBrandSectionLocation = config.location || 'bottom';
            await loadSectionsForLocationGeneric('#configBrandSectionLocation', savedBrandSectionLocation);
            break;
            
        case 'brandGrid':
            if (config.limit) $('#configBrandGridLimit').val(config.limit);
            // Load location dropdown and restore saved location
            const savedBrandGridLocation = config.location || 'bottom';
            await loadSectionsForLocationGeneric('#configBrandGridLocation', savedBrandGridLocation);
            break;
            
        case 'customHTML':
            if (config.html) $('#configCustomHTML').val(config.html);
            // Load location dropdown and restore saved location
            const savedCustomHTMLLocation = config.location || 'bottom';
            await loadSectionsForLocationGeneric('#configCustomHTMLLocation', savedCustomHTMLLocation);
            break;
    }
}

function deleteHomepageSection(id) {
    if (confirm('Are you sure you want to delete this homepage section? It will be removed from the homepage.')) {
        $.ajax({
            url: `/api/homepage-sections/${id}`,
            method: 'DELETE',
            success: function() {
                showAlert('Homepage section deleted successfully', 'success');
                loadHomepageSections();
            },
            error: function() {
                showAlert('Error deleting homepage section', 'danger');
            }
        });
    }
}

function toggleHomepageSectionReorder() {
    const btn = $('#reorder-homepage-sections-btn');
    const isReorderMode = btn.hasClass('active');
    
    if (isReorderMode) {
        // Save order
        const order = [];
        $('#homepage-sections-table tr').each(function(index) {
            const sectionId = $(this).data('section-id');
            if (sectionId) {
                order.push({ id: sectionId, ordering: index });
            }
        });
        
        $.ajax({
            url: '/api/homepage-sections/reorder',
            method: 'PATCH',
            contentType: 'application/json',
            data: JSON.stringify({ order }),
            success: function() {
                showAlert('Section order saved successfully', 'success');
                btn.removeClass('active btn-success').addClass('btn-secondary');
                btn.html('<i class="fas fa-sort"></i> Reorder Sections');
                loadHomepageSections();
            },
            error: function() {
                showAlert('Error saving section order', 'danger');
            }
        });
    } else {
        // Enable reorder mode (simplified - could add drag & drop here)
        btn.addClass('active').removeClass('btn-secondary').addClass('btn-success');
        btn.html('<i class="fas fa-save"></i> Save Order');
        showAlert('Reorder mode enabled. Adjust ordering numbers and click "Save Order" when done.', 'info');
    }
}

function deleteUser(id) {
    if (confirm('Are you sure you want to delete this user?')) {
        // This would be implemented in a real application
        showAlert('Delete user functionality not implemented', 'info');
    }
}

// Alert function
function showAlert(message, type) {
    const alertHtml = `
        <div class="alert alert-${type} alert-dismissible fade show" role="alert">
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    `;
    
    $('.content').prepend(alertHtml);
    
    // Auto-dismiss after 5 seconds
    setTimeout(function() {
        $('.alert').alert('close');
    }, 5000);
}

const IMAGE_PLACEHOLDER = 'data:image/svg+xml;utf8,' + encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" width="400" height="260"><rect width="100%" height="100%" fill="#f1f5f9" rx="16"/><text x="50%" y="52%" font-family="Arial, sans-serif" font-size="20" fill="#94a3b8" text-anchor="middle">No image selected</text></svg>`);

function resolveItemImage(item) {
    if (!item) return null;
    
    // First check imageUpload (if populated)
    if (item.imageUpload) {
        if (typeof item.imageUpload === 'object' && item.imageUpload.url) {
        return item.imageUpload.url;
    }
        // If imageUpload is just an ID, we can't use it directly
    }
    
    // Then check image field
    if (item.image) {
        const imageUrl = String(item.image).trim();
        // Return null for invalid values
        if (imageUrl && imageUrl !== 'null' && imageUrl !== 'undefined' && imageUrl !== '') {
            return imageUrl;
    }
    }
    
    return null;
}

// Helper to detect video type from URL
function detectVideoTypeFromUrl(url) {
    if (!url) return null;
    if (url.includes('youtube.com/watch') || url.includes('youtu.be/') || url.includes('youtube.com/embed')) {
        return 'youtube';
    }
    if (url.includes('vimeo.com/')) {
        return 'vimeo';
    }
    if (url.match(/\.(mp4|webm|ogg|mov|avi|wmv|m4v|flv)$/i)) {
        return 'direct';
    }
    if (url.includes('/video/upload') || url.includes('resource_type=video')) {
        return 'file';
    }
    return null;
}

// Helper to extract YouTube video ID
function extractYouTubeId(url) {
    const regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|&v=)([^#&?]*).*/;
    const match = url.match(regExp);
    return (match && match[2].length === 11) ? match[2] : null;
}

// Helper to extract Vimeo video ID
function extractVimeoId(url) {
    const match = url.match(/vimeo.com\/(\d+)/);
    return match ? match[1] : null;
}

// Show YouTube/Vimeo embed preview
function showVideoEmbedPreview(selector, url, videoType) {
    const $preview = $(selector);
    if (!$preview.length) {
        console.warn('Preview element not found:', selector);
        return;
    }
    
    let embedHtml = '';
    
    if (videoType === 'youtube') {
        const youtubeId = extractYouTubeId(url);
        if (youtubeId) {
            const embedUrl = `https://www.youtube.com/embed/${youtubeId}`;
            embedHtml = `
                <div class="video-preview-wrapper" style="position: relative; padding-bottom: 56.25%; height: 0; overflow: hidden; max-width: 100%; background: #000; border-radius: 4px;">
                    <iframe src="${embedUrl}" 
                            style="position: absolute; top: 0; left: 0; width: 100%; height: 100%;" 
                            frameborder="0" 
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
                            allowfullscreen>
                    </iframe>
                </div>
            `;
        } else {
            embedHtml = '<div class="alert alert-warning">Invalid YouTube URL. Please check the URL format.</div>';
        }
    } else if (videoType === 'vimeo') {
        const vimeoId = extractVimeoId(url);
        if (vimeoId) {
            const embedUrl = `https://player.vimeo.com/video/${vimeoId}`;
            embedHtml = `
                <div class="video-preview-wrapper" style="position: relative; padding-bottom: 56.25%; height: 0; overflow: hidden; max-width: 100%; background: #000; border-radius: 4px;">
                    <iframe src="${embedUrl}" 
                            style="position: absolute; top: 0; left: 0; width: 100%; height: 100%;" 
                            frameborder="0" 
                            allow="autoplay; fullscreen; picture-in-picture" 
                            allowfullscreen>
                    </iframe>
                </div>
            `;
        } else {
            embedHtml = '<div class="alert alert-warning">Invalid Vimeo URL. Please check the URL format.</div>';
        }
    }
    
    if (embedHtml) {
        // Clear preview first - handle both img and div cases
        if ($preview.is('img')) {
            // If img is inside a parent container (image-preview), replace the img with the embed div
            const $parent = $preview.parent();
            if ($parent.hasClass('image-preview') || $parent.hasClass('image-preview--wide')) {
                // Replace img with div containing embed inside the parent
                const $newDiv = $('<div>').html(embedHtml);
                $preview.replaceWith($newDiv);
            } else {
                // Direct replacement
                const $newDiv = $('<div>').html(embedHtml);
                $preview.replaceWith($newDiv);
            }
        } else {
            // Clear and set content for div/container
            $preview.empty().html(embedHtml);
        }
        console.log('✅ Set YouTube/Vimeo embed preview for:', url, 'Type:', videoType);
    } else {
        console.warn('⚠️ No embed HTML generated for:', url, 'Video Type:', videoType);
    }
}

function setImagePreview(selector, url) {
    const $preview = $(selector);
    if (!$preview.length) {
        console.warn('Preview element not found:', selector);
        return;
    }
    
    const safeUrl = url || IMAGE_PLACEHOLDER;
    
    // Check if URL is a video (by extension or Cloudinary video URL)
    // Cloudinary video URLs: https://res.cloudinary.com/cloud_name/video/upload/...
    const isVideo = url && (
        url.match(/\.(mp4|webm|ogg|mov|avi|wmv|m4v|flv)$/i) || 
        url.includes('/video/upload/') || 
        url.includes('/video/upload') ||
        url.includes('resource_type=video') ||
        url.match(/\/v\d+\/.*\.(mp4|webm|ogg|mov|avi|wmv|m4v|flv)/i) // Cloudinary format
    );
    
    console.log('Setting preview:', { selector, url, isVideo, elementType: $preview[0]?.tagName });
    
    // Check if it's an img element or a div
    if ($preview.is('img')) {
        if (isVideo) {
            // Convert img to video element
            // If img is inside a parent container, replace within that context
            const $parent = $preview.parent();
            if ($parent.hasClass('image-preview') || $parent.hasClass('image-preview--wide')) {
                // Replace img with video inside the parent container
                const $video = $('<video>').attr({
                    src: safeUrl,
                    controls: true,
                    preload: 'metadata',
                    style: 'max-width: 100%; max-height: 100%; object-fit: contain; display: block; width: 100%;'
                });
                $preview.replaceWith($video);
                console.log('Replaced img with video element inside parent container');
            } else {
                // Direct replacement
                const $video = $('<video>').attr({
                    src: safeUrl,
                    controls: true,
                    preload: 'metadata',
                    style: 'max-width: 100%; max-height: 100%; object-fit: contain; display: block;'
                });
                $preview.replaceWith($video);
                console.log('Replaced img with video element');
            }
        } else {
            $preview.attr('src', safeUrl);
        }
    } else {
        // For div elements, clear first and set as video or image
        $preview.empty();
        if (url) {
            if (isVideo) {
                const videoHtml = `<video src="${safeUrl}" controls preload="metadata" style="max-width: 100%; max-height: 100%; object-fit: contain; display: block;" alt="Video preview"></video>`;
                $preview.html(videoHtml);
                console.log('Set video preview in div');
            } else {
                const imgHtml = `<img src="${safeUrl}" style="max-width: 100%; max-height: 100%; object-fit: contain; display: block;" alt="Preview">`;
                $preview.html(imgHtml);
            }
        } else {
            $preview.html('<span class="text-muted">No image/video selected</span>');
        }
    }
}

function initImageField({ urlInput, fileInput, preview }) {
    const $urlInput = $(urlInput);
    const $fileInput = $(fileInput);

    $urlInput.on('input paste', function () {
        // Use setTimeout to ensure pasted value is captured
        setTimeout(() => {
            const value = $(this).val().trim();
            console.log('URL input changed:', value);
            if (value) {
                // Check if it's a YouTube/Vimeo URL and show embed preview
                const videoType = detectVideoTypeFromUrl(value);
                console.log('Detected video type:', videoType, 'for URL:', value);
                if (videoType === 'youtube' || videoType === 'vimeo') {
                    showVideoEmbedPreview(preview, value, videoType);
                } else {
                    setImagePreview(preview, value);
                }
            } else if (!$fileInput[0]?.files?.length) {
                setImagePreview(preview, null);
            }
        }, 100);
    });

    $fileInput.on('change', function () {
        const file = this.files && this.files[0];
        if (!file) {
            const value = $urlInput.val();
            setImagePreview(preview, value || null);
            // Clear file size display
            const fileSizeDisplay = $(this).closest('.mb-3').find('[id$="FileSize"]');
            if (fileSizeDisplay.length) {
                fileSizeDisplay.text('');
            }
            return;
        }
        
        // Check if file is a video
        const isVideo = file.type && file.type.startsWith('video/');
        
        // Display file size (different limits for images vs videos)
        const fileSizeMB = (file.size / (1024 * 1024)).toFixed(2);
        const maxSizeMB = isVideo ? 100 : 20; // 100MB for videos, 20MB for images
        const fileSizeDisplay = $(this).closest('.mb-3').find('[id$="FileSize"]');
        if (fileSizeDisplay.length) {
            const sizeClass = file.size > (maxSizeMB * 1024 * 1024) ? 'text-danger' : 'text-success';
            const fileType = isVideo ? 'Video' : 'Image';
            fileSizeDisplay.html(`<span class="${sizeClass}">${fileType} size: ${fileSizeMB} MB</span>`);
            if (file.size > (maxSizeMB * 1024 * 1024)) {
                fileSizeDisplay.append(` <span class="text-danger">(Exceeds ${maxSizeMB} MB limit!)</span>`);
            }
        }
        
        const reader = new FileReader();
        reader.onload = function (event) {
            // For videos, show video preview; for images, show image preview
            if (isVideo) {
                const $preview = $(preview);
                if ($preview.is('img')) {
                    const $video = $('<video>').attr({
                        src: event.target.result,
                        controls: true,
                        style: 'max-width: 100%; max-height: 100%; object-fit: contain;'
                    });
                    $preview.replaceWith($video);
                } else {
                    $preview.html(`<video src="${event.target.result}" controls style="max-width: 100%; max-height: 100%; object-fit: contain;" alt="Video preview"></video>`);
                }
            } else {
                setImagePreview(preview, event.target.result);
            }
        };
        reader.readAsDataURL(file);
    });
}

async function uploadImageIfNeeded(fileInputSelector, folder) {
    const input = $(fileInputSelector)[0];
    if (!input || !input.files || !input.files.length) {
        return null;
    }

    const file = input.files[0];
    const maxSize = 20 * 1024 * 1024; // 20MB
    const fileSizeMB = (file.size / (1024 * 1024)).toFixed(2);
    
    // Client-side file size validation
    if (file.size > maxSize) {
        const errorMsg = `Image file size (${fileSizeMB} MB) exceeds maximum limit of 20 MB. Please compress the image or use a smaller file.`;
        throw new Error(errorMsg);
    }

    try {
    const formData = new FormData();
    formData.append('file', file);
    if (folder) {
        formData.append('folder', folder);
    }

        console.log('Uploading image:', {
            filename: file.name,
            size: file.size,
            sizeMB: fileSizeMB,
            type: file.type,
            folder: folder
        });

    const response = await $.ajax({
        url: '/api/admin/media',
        method: 'POST',
        data: formData,
        processData: false,
            contentType: false,
            headers: {
                'x-auth-token': localStorage.getItem('token')
            }
    });

        console.log('Image uploaded successfully:', response);

    // Clear the file input so future saves do not re-upload
    input.value = '';
    return response;
    } catch (error) {
        console.error('Image upload error:', error);
        
        let errorMessage = 'Error uploading image';
        if (error.responseJSON && error.responseJSON.message) {
            errorMessage = error.responseJSON.message;
        } else if (error.responseText) {
            try {
                const errorData = JSON.parse(error.responseText);
                errorMessage = errorData.message || errorMessage;
            } catch (e) {
                errorMessage = error.responseText || errorMessage;
            }
        } else if (error.message) {
            errorMessage = error.message;
        }
        
        throw new Error(errorMessage);
    }
}

async function uploadVideoIfNeeded(fileInputSelector, folder) {
    const input = $(fileInputSelector)[0];
    if (!input || !input.files || !input.files.length) {
        return null;
    }

    const file = input.files[0];
    const maxSize = 500 * 1024 * 1024; // 500MB for videos
    const fileSizeMB = (file.size / (1024 * 1024)).toFixed(2);
    
    // Client-side file size validation
    if (file.size > maxSize) {
        const errorMsg = `Video file size (${fileSizeMB} MB) exceeds maximum limit of 500 MB. Please compress the video or use a smaller file.`;
        throw new Error(errorMsg);
    }

    try {
        const formData = new FormData();
        formData.append('file', file);
        if (folder) {
            formData.append('folder', folder);
        }

        console.log('Uploading video:', {
            filename: file.name,
            size: file.size,
            sizeMB: fileSizeMB,
            type: file.type,
            folder: folder
        });

        const response = await $.ajax({
            url: '/api/admin/media',
            method: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            headers: {
                'x-auth-token': localStorage.getItem('token')
            }
        });

        console.log('Video uploaded successfully:', response);

        // Clear the file input so future saves do not re-upload
        input.value = '';
        return response;
    } catch (error) {
        console.error('Video upload error:', error);
        
        let errorMessage = 'Error uploading video';
        if (error.responseJSON && error.responseJSON.message) {
            errorMessage = error.responseJSON.message;
        } else if (error.responseText) {
            try {
                const errorData = JSON.parse(error.responseText);
                errorMessage = errorData.message || errorMessage;
            } catch (e) {
                errorMessage = error.responseText || errorMessage;
            }
        } else if (error.message) {
            errorMessage = error.message;
        }
        
        throw new Error(errorMessage);
    }
}

function normaliseFileId(value) {
    if (!value || value === 'null' || value === 'undefined') {
        return '';
    }
    return value;
}

// Footer Management
function loadFooter() {
    console.log('Loading footer data from database...');
    
    // Check if form elements exist
    if (!$('#footerLogo').length) {
        console.error('Footer form elements not found in DOM, retrying...');
        setTimeout(loadFooter, 200);
        return;
    }
    
    $.ajax({
        url: '/api/admin/footer',
        method: 'GET',
        headers: {
            'x-auth-token': localStorage.getItem('token')
        }
    })
    .done(function(footer) {
        console.log('Footer data received from database:', footer);
        
        if (!footer) {
            console.warn('Footer data is null or undefined');
            footer = {};
        }
        
        // Populate all footer fields from database (use database values, fallback to defaults only if undefined or empty)
        const logoUrl = footer.logo || '/images/logo-white.png';
        $('#footerLogo').val(logoUrl);
        setImagePreview('#footerLogoPreview', logoUrl);
        
        $('#footerAddress').val(footer.address || 'multiple branches in islamabad');
        $('#footerPhone').val(footer.phone || '+92 300 1234567');
        $('#footerEmail').val(footer.email || 'dwatsonconsultation@gmail.com');
        $('#contactInfoTitle').val(footer.contactInfoTitle || 'Contact Info');
        $('#quickLinksTitle').val(footer.quickLinksTitle || 'Quick Links');
        
        // Social media links (allow empty strings)
        $('#socialFacebook').val(footer.socialMedia?.facebook || '');
        $('#socialTwitter').val(footer.socialMedia?.twitter || '');
        $('#socialInstagram').val(footer.socialMedia?.instagram || '');
        $('#socialLinkedin').val(footer.socialMedia?.linkedin || '');
        $('#socialYoutube').val(footer.socialMedia?.youtube || '');
        $('#socialWhatsapp').val(footer.socialMedia?.whatsapp || '');
        
        // About text
        $('#footerAboutText').val(footer.aboutText || 'D. Watson Group is the supplier of home medical and health related products designed with the needs of the user in mind. D. Watson Group was founded by its chairman, Mr. Zafar Bakhtawari in 1975. We provide a wide variety of local and imported allopathic and homeopathic medicines, drugs, cosmetics, herbal products, optical products, surgical supplies and toiletries.');
        
        // Payment methods image
        const paymentMethodsUrl = footer.paymentMethodsImage || '/images/payment-methods.png';
        $('#footerPaymentMethodsImage').val(paymentMethodsUrl);
        setImagePreview('#footerPaymentMethodsImagePreview', paymentMethodsUrl);
        
        // Copyright text
        $('#footerCopyright').val(footer.copyrightText || '© 2025 D.Watson Pharmacy. All Rights Reserved. Website built and designed by Bilal Shah. All rights reserved by D.Watson.');
        
        // Load quick links from database
        if (footer.quickLinks && Array.isArray(footer.quickLinks) && footer.quickLinks.length > 0) {
            console.log('Loading quick links from database:', footer.quickLinks.length, 'links');
            loadQuickLinks(footer.quickLinks);
        } else {
            console.log('No quick links in database, showing defaults');
            loadQuickLinks([]);
        }
        
        console.log('Footer data loaded and displayed successfully from database');
    })
    .fail(function(xhr) {
        console.error('Error loading footer from database:', xhr);
        console.error('Status:', xhr.status);
        console.error('Response:', xhr.responseJSON);
        
        const errorMsg = xhr.responseJSON?.message || 'Error loading footer data from database';
        showAlert(errorMsg, 'danger');
    });
}

function loadQuickLinks(links) {
    const container = $('#quickLinksContainer');
    if (!container.length) {
        console.error('Quick links container not found!');
        return;
    }
    
    container.empty();
    
    // Always show default links if empty
    if (!links || links.length === 0) {
        links = [
            { title: 'About Us', url: '#' },
            { title: 'Contact Us', url: '#' },
            { title: 'Terms & Conditions', url: '#' },
            { title: 'Privacy Policy', url: '#' },
            { title: 'Returns & Refunds', url: '#' }
        ];
    }
    
    links.forEach((link, index) => {
        const title = (link.title || '').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
        const url = (link.url || '').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
        const linkHtml = `
            <div class="card mb-2 quick-link-item" data-index="${index}">
                <div class="card-body">
                    <div class="row align-items-center">
                        <div class="col-md-5">
                            <label class="form-label small">Link Title</label>
                            <input type="text" class="form-control form-control-sm quick-link-title" value="${title}" placeholder="Link Title">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label small">Link URL</label>
                            <input type="text" class="form-control form-control-sm quick-link-url" value="${url}" placeholder="URL">
                        </div>
                        <div class="col-md-1">
                            <button type="button" class="btn btn-sm btn-danger remove-quick-link" title="Remove">
                                <i class="fas fa-trash"></i>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        `;
        container.append(linkHtml);
    });
    
    console.log('Quick links loaded:', links.length);
}

async function updateFooter() {
    console.log('updateFooter function called');
    console.log('Starting to update footer data...');
    
    // Validate required fields
    if (!$('#footerLogo').length) {
        console.error('Footer form elements not found!');
        showAlert('Footer form not found. Please refresh the page.', 'danger');
        return;
    }
    
    console.log('Footer form elements found, proceeding with save...');
    
    // Show loading indicator
    const updateBtn = $('#updateFooter');
    if (!updateBtn.length) {
        console.error('Update button not found!');
        showAlert('Update button not found. Please refresh the page.', 'danger');
        return;
    }
    
    const originalText = updateBtn.html();
    updateBtn.prop('disabled', true).html('<i class="fas fa-spinner fa-spin"></i> Updating...');
    console.log('Update button disabled, starting image uploads...');
    
    try {
        // Upload footer logo image if provided
        let logoUrl = ($('#footerLogo').val() || '').trim();
        const uploadedLogo = await uploadImageIfNeeded('#footerLogoFile', 'footer');
        if (uploadedLogo) {
            logoUrl = uploadedLogo.url;
            $('#footerLogo').val(logoUrl);
            setImagePreview('#footerLogoPreview', logoUrl);
        }
        
        // Upload payment methods image if provided
        let paymentMethodsUrl = ($('#footerPaymentMethodsImage').val() || '').trim();
        const uploadedPaymentMethods = await uploadImageIfNeeded('#footerPaymentMethodsImageFile', 'footer');
        if (uploadedPaymentMethods) {
            paymentMethodsUrl = uploadedPaymentMethods.url;
            $('#footerPaymentMethodsImage').val(paymentMethodsUrl);
            setImagePreview('#footerPaymentMethodsImagePreview', paymentMethodsUrl);
        }
        
        // Collect quick links
        const quickLinks = [];
        $('.quick-link-item').each(function() {
            const title = $(this).find('.quick-link-title').val();
            const url = $(this).find('.quick-link-url').val();
            if (title && url) {
                quickLinks.push({ title: title.trim(), url: url.trim() });
            }
        });
        
        console.log('Collected quick links:', quickLinks.length);

        // Collect all footer data
        const footerData = {
            logo: logoUrl || '/images/logo-white.png',
            address: $('#footerAddress').val() || '',
            phone: $('#footerPhone').val() || '',
            email: $('#footerEmail').val() || '',
            contactInfoTitle: $('#contactInfoTitle').val() || 'Contact Info',
            quickLinksTitle: $('#quickLinksTitle').val() || 'Quick Links',
            quickLinks: quickLinks,
            socialMedia: {
                facebook: $('#socialFacebook').val() || '',
                twitter: $('#socialTwitter').val() || '',
                instagram: $('#socialInstagram').val() || '',
                linkedin: $('#socialLinkedin').val() || '',
                youtube: $('#socialYoutube').val() || '',
                whatsapp: $('#socialWhatsapp').val() || ''
            },
            aboutText: $('#footerAboutText').val() || '',
            paymentMethodsImage: paymentMethodsUrl || '/images/payment-methods.png',
            copyrightText: $('#footerCopyright').val() || ''
        };
        
        console.log('Footer data to save:', JSON.stringify(footerData, null, 2));
        console.log('Making AJAX request...');
        
        $.ajax({
            url: '/api/admin/footer',
            method: 'PUT',
            contentType: 'application/json',
            headers: {
                'x-auth-token': localStorage.getItem('token')
            },
            data: JSON.stringify(footerData)
        })
        .done(function(response) {
            console.log('Footer saved successfully to database:', response);
            showAlert('Footer updated successfully!', 'success');
            
            // Reload footer data to ensure sync
            setTimeout(function() {
                loadFooter();
            }, 500);
        })
        .fail(function(xhr) {
            console.error('Error saving footer:', xhr);
            console.error('Status:', xhr.status);
            console.error('Response:', xhr.responseJSON);
            
            let errorMsg = 'Error updating footer';
            if (xhr.status === 401) {
                errorMsg = 'Authentication failed. Please login again.';
            } else if (xhr.status === 403) {
                errorMsg = 'You do not have permission to update footer.';
            } else if (xhr.responseJSON && xhr.responseJSON.message) {
                errorMsg = xhr.responseJSON.message;
            }
            
            showAlert(errorMsg, 'danger');
        })
        .always(function() {
            // Re-enable update button
            updateBtn.prop('disabled', false).html(originalText);
        });
    } catch (error) {
        console.error('Error in updateFooter:', error);
        showAlert(error.message || 'Error updating footer. Please try again.', 'danger');
        updateBtn.prop('disabled', false).html(originalText);
    }
}

// Keep saveFooter as alias for backward compatibility
function saveFooter() {
    updateFooter();
}

// Quick Links Management
$(document).on('click', '#addQuickLink', function() {
    const container = $('#quickLinksContainer');
    const index = container.children().length;
    const linkHtml = `
        <div class="card mb-2 quick-link-item" data-index="${index}">
            <div class="card-body">
                <div class="row align-items-center">
                    <div class="col-md-5">
                        <label class="form-label small">Link Title</label>
                        <input type="text" class="form-control form-control-sm quick-link-title" placeholder="Link Title">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label small">Link URL</label>
                        <input type="text" class="form-control form-control-sm quick-link-url" placeholder="URL">
                    </div>
                    <div class="col-md-1">
                        <button type="button" class="btn btn-sm btn-danger remove-quick-link" title="Remove">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    `;
    container.append(linkHtml);
});

$(document).on('click', '.remove-quick-link', function() {
    $(this).closest('.quick-link-item').remove();
});
